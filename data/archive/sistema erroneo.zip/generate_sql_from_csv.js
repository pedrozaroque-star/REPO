const fs = require('fs');
const path = require('path');

const FILE_PATH = path.join(process.cwd(), 'feedback_clientes.csv');

function generateSQL() {
    try {
        if (!fs.existsSync(FILE_PATH)) {
            console.error(`-- ERROR: File not found: ${FILE_PATH}`);
            process.exit(1);
        }

        // Hardcoded Store Map
        const storeMap = {
            'LYNWOOD': '1b671a64-40d5-491e-99b0-da01ff1f3341',
            'SANTA ANA': '2779762f-492a-4106-9f74-b868da7d1b68',
            'SOUTH GATE': '5034d159-a1db-48ac-9822-5144567cb4e7'
        };

        const content = fs.readFileSync(FILE_PATH, 'utf-8');
        const lines = content.split(/\r?\n/);

        console.log(`-- SQL Import Script generated from feedback_clientes.csv`);
        console.log(`-- Generated at ${new Date().toISOString()}`);
        console.log(`TRUNCATE TABLE customer_feedback;`);
        console.log(`INSERT INTO customer_feedback (submission_date, store_id, customer_name, email, visit_frequency, service_rating, speed_rating, food_quality_rating, cleanliness_rating, nps_score, nps_category, comments, ticket_url) VALUES`);

        const values = [];
        let isHeader = true;

        for (const line of lines) {
            if (!line.trim()) continue;
            if (isHeader) {
                isHeader = false;
                continue;
            }

            const cols = line.split(',');
            // Index 3 is Sucursal
            const branchName = cols[3] ? cols[3].replace(/"/g, '').trim() : '';
            const storeId = storeMap[branchName.toUpperCase().trim()];

            if (!storeId) {
                // Skip or default? For now skip to be safe, or use Lynwood as default if unsure
                // console.log(`-- Skipping: ${branchName}`);
                continue;
            }

            const escapeSQL = (str) => {
                if (!str) return 'NULL';
                return `'${str.replace(/'/g, "''").replace(/"/g, '').trim()}'`;
            };

            const parseRating = (val) => {
                if (!val) return 0;
                const match = val.toString().match(/(\d+)/);
                return match ? parseInt(match[1]) : 0;
            };

            const determineNPS = (score) => {
                if (score >= 9) return 'promoter';
                if (score >= 7) return 'passive';
                return 'detractor';
            };

            const dateVal = new Date(cols[0]).toISOString();
            const name = escapeSQL(cols[15] || 'Anónimo'); // ClienteNick at 15
            const email = 'NULL';
            const freq = 'NULL';

            const service = parseRating(cols[5]);
            const speed = parseRating(cols[6]);
            const quality = parseRating(cols[7]);
            const clean = parseRating(cols[8]);
            const nps = parseRating(cols[9]);

            const comment = escapeSQL(cols[10]);
            const ticket = escapeSQL(cols[11]);
            const category = `'${determineNPS(nps)}'`;

            values.push(`('${dateVal}', '${storeId}', ${name}, ${email}, ${freq}, ${service}, ${speed}, ${quality}, ${clean}, ${nps}, ${category}, ${comment}, ${ticket})`);
        }

        console.log(values.join(',\n') + ';');

    } catch (err) {
        console.error('-- FATAL ERROR:', err);
    }
}

generateSQL();
