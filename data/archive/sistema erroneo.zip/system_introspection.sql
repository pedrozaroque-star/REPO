-- 📊 SYSTEM INTROSPECTION QUERY
-- Run each section separately or all together to get a full view of your Supabase project.

-- 1. 📋 TABLES & COLUMNS (Tablas y Columnas)
SELECT 
    t.table_name,
    c.column_name,
    c.data_type,
    c.column_default,
    c.is_nullable
FROM information_schema.tables t
JOIN information_schema.columns c ON t.table_name = c.table_name
WHERE t.table_schema = 'public'
ORDER BY t.table_name, c.ordinal_position;

-- 2. 🛡️ RLS POLICIES (Políticas de Seguridad)
SELECT 
    tablename,
    policyname,
    permissive,
    roles,
    cmd AS operation,
    qual AS definition,
    with_check
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY tablename, policyname;

-- 3. ⚡ TRIGGERS (Notificaciones y Automatización)
SELECT 
    event_object_table AS table_name,
    trigger_name,
    event_manipulation AS event,
    action_statement AS action
FROM information_schema.triggers
WHERE event_object_schema = 'public'
ORDER BY event_object_table, trigger_name;

-- 4. 🧩 FUNCTIONS (Funciones Personalizadas / RPC)
-- Filters out system functions to show only yours
SELECT 
    n.nspname AS schema,
    p.proname AS function_name,
    pg_get_function_arguments(p.oid) AS arguments,
    t.typname AS return_type,
    l.lanname AS language
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
JOIN pg_type t ON p.prorettype = t.oid
JOIN pg_language l ON p.prolang = l.oid
WHERE n.nspname = 'public'
ORDER BY p.proname;

-- 5. 👥 ROLES & GRANTS (Permisos básicos)
SELECT 
    grantee, 
    table_name, 
    privilege_type 
FROM information_schema.role_table_grants 
WHERE table_schema = 'public'
ORDER BY table_name, grantee;
