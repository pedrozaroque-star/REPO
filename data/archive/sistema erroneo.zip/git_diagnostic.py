import subprocess
import os

commands = [
    ["git", "status", "--short"],
    ["git", "log", "-n", "10", "--oneline"]
]

for cmd in commands:
    print(f"Running command: {' '.join(cmd)}")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        print(f"STDOUT:\n{result.stdout}")
        print(f"STDERR:\n{result.stderr}")
    except subprocess.CalledProcessError as e:
        print(f"FAILED: {' '.join(cmd)}")
        print(f"Error Code: {e.returncode}")
        print(f"STDOUT:\n{e.stdout}")
        print(f"STDERR:\n{e.stderr}")

print("Diagnostic script finished.")
