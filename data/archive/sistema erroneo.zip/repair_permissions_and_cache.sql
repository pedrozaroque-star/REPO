-- 1. Reload the Schema Cache (Fix for PGRST204 "Could not find column")
NOTIFY pgrst, 'reload config';

-- 2. Grant Permissions to 'authenticated' (Supervisors need to read/update these)
GRANT ALL ON TABLE notifications TO authenticated;
GRANT ALL ON TABLE customer_feedback TO authenticated;
GRANT ALL ON TABLE public.customer_feedback TO authenticated;

-- 3. Fix RLS (Ensure Supervisors can select ALL columns in customer_feedback)
-- We attempt to drop the restrictive policy first if it exists, then re-create a permissive one.
DO $$
BEGIN
    -- Drop old policies if they exist to start fresh
    DROP POLICY IF EXISTS "Enable read access for all users" ON "public"."customer_feedback";
    DROP POLICY IF EXISTS "Allow individual read access" ON "public"."customer_feedback";
    
    -- Create a clear PERMISSIVE policy for SELECT
    CREATE POLICY "Enable read access for all users" ON "public"."customer_feedback"
    AS PERMISSIVE FOR SELECT
    TO public
    USING (true);
    
    -- Ensure update permissions for authenticated users (for future review logic)
    DROP POLICY IF EXISTS "Enable update for authenticated users" ON "public"."customer_feedback";
    CREATE POLICY "Enable update for authenticated users" ON "public"."customer_feedback"
    AS PERMISSIVE FOR UPDATE
    TO authenticated
    USING (true)
    WITH CHECK (true);

END
$$;
