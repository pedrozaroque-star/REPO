-- PASO 1: En Supabase, importa tu CSV y llama a la tabla: feedback_temp
-- (Asegurate de que las columnas se importen como texto o numeros según detecte Supabase)

-- PASO 2: Corre este script para mover y transformar los datos:

-- Limpiar tabla destino (Opcional, quita -- si quieres borrar anteriores)
TRUNCATE TABLE customer_feedback;

INSERT INTO customer_feedback (
    submission_date,
    store_id,
    customer_name,
    visit_date,
    visit_time,
    service_rating,
    speed_rating,
    food_quality_rating,
    cleanliness_rating,
    nps_score,
    nps_category,
    comments,
    ticket_url,
    language,
    photo_urls
)
SELECT
    -- Conversión de Fechas
    -- Intentamos cast directo, a veces viene como 'MM/DD/YYYY HH:mm:ss'
    TO_TIMESTAMP("Timestamp", 'MM/DD/YYYY HH24:MI:SS'), 
    
    -- Mapeo de Tiendas
    s.id,
    
    -- Datos del Cliente
    COALESCE("ClienteNick", 'Anónimo'),

    -- Fecha y Hora de Visita
    CAST("Fecha" AS DATE),
    CAST("Hora" AS TIME),
    
    -- Ratings (Cast a entero)
    "Caja(1-5)"::int,
    "Entrega(1-5)"::int,
    "Calidad(1-5)"::int,
    "Limpieza(1-5)"::int,
    "NPS(0-10)"::int,
    
    -- Cálculo NPS
    CASE 
        WHEN "NPS(0-10)"::int >= 9 THEN 'promoter'
        WHEN "NPS(0-10)"::int >= 7 THEN 'passive'
        ELSE 'detractor'
    END,
    
    -- Contenido
    COALESCE("Comentarios", ''),
    
    -- URLs de Fotos (Mapeo directo)
    "FotosURLs",
    
    -- Idioma
    "Idioma",

    -- Array de Fotos (Convertimos string separado por saltos de línea \n o espacios)
    regexp_split_to_array(TRIM("FotosURLs"), '\s+')

FROM "feedback_temp" f
JOIN stores s ON s.name ILIKE '%' || f."Sucursal" || '%';

-- Verificación
-- SELECT count(*) FROM customer_feedback;
