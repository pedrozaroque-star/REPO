-- check policies
select * from pg_policies where tablename = 'customer_feedback';

-- check if feedback 511 has the status (bypass RLS)
SELECT id, admin_review_status, admin_review_comments FROM customer_feedback WHERE id = 511;

-- create a policy if missing for supervisor to see everything (or specific columns)
-- Assume role name is 'authenticated' or custom. We just ensure SELECT is open.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'customer_feedback' 
        AND policyname = 'Enable read access for all users'
    ) THEN
        CREATE POLICY "Enable read access for all users" ON "public"."customer_feedback"
        AS PERMISSIVE FOR SELECT
        TO public
        USING (true);
    END IF;
END
$$;
