'use client'

import { useState } from 'react'
import { supabase } from '@/lib/supabase'

interface AdminReviewModalProps {
    isOpen: boolean
    onClose: () => void
    type: 'staff_evaluation' | 'customer_feedback'
    data: any
    onUpdate: () => void
}

export default function AdminReviewModal({ isOpen, onClose, type, data, onUpdate }: AdminReviewModalProps) {
    const [status, setStatus] = useState(data?.review_status || 'pending')
    const [observation, setObservation] = useState(data?.admin_observation || '')
    const [notifyUser, setNotifyUser] = useState(false)
    const [loading, setLoading] = useState(false)

    if (!isOpen || !data) return null

    const isStaff = type === 'staff_evaluation'
    const isManagerOrSupervisor = isStaff && ['Manager', 'Supervisor'].includes(data.evaluated_role)

    const handleSubmit = async () => {
        setLoading(true)
        try {
            const table = isStaff ? 'staff_evaluations' : 'customer_feedback'

            // 1. Update the record
            const { error } = await supabase
                .from(table)
                .update({
                    review_status: status,
                    admin_observation: observation,
                    reviewed_at: new Date().toISOString(),
                    // reviewed_by should be handled if we had the user context handy, 
                    // or we can assume the backend or RLS might handle it, 
                    // but for now we'll just update the status/observation.
                })
                .eq('id', data.id)

            if (error) throw error

            // 2. Notify logic (Simplified simulation)
            if (notifyUser && !isManagerOrSupervisor) {
                // Here we would insert into a notifications table
                console.log('Sending notification for:', data.id)
            }

            onUpdate()
            onClose()
        } catch (err) {
            console.error('Error updating review:', err)
            alert('Error updating review')
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200 border border-gray-100">

                {/* Header */}
                <div className="p-8 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                    <div>
                        <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tight">
                            Revisión de {isStaff ? 'Evaluación' : 'Feedback'}
                        </h2>
                        <p className="text-sm text-gray-500 font-bold uppercase tracking-widest mt-2 flex items-center gap-3">
                            <span className="bg-white px-3 py-1 rounded-full shadow-sm">ID: {data.id}</span>
                            <span className="bg-white px-3 py-1 rounded-full shadow-sm">📅 {new Date(isStaff ? data.evaluation_date : data.submission_date).toLocaleDateString()}</span>
                        </p>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-red-500 p-3 rounded-2xl hover:bg-red-50 transition-all text-xl font-light">✕</button>
                </div>

                {/* Content - Scrollable */}
                <div className="flex-1 overflow-y-auto p-8 space-y-8">

                    {/* Details Section */}
                    <div className="grid grid-cols-2 gap-8 p-8 bg-gray-50/80 rounded-3xl border border-gray-100 shadow-inner">
                        <div>
                            <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Sucursal</p>
                            <p className="text-xl font-black text-gray-900">{data.stores?.name || 'N/A'}</p>
                        </div>
                        {isStaff ? (
                            <>
                                <div>
                                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Personal Evaluado</p>
                                    <p className="text-xl font-black text-gray-900">{data.evaluated_name}</p>
                                    <span className="text-sm text-gray-500 font-bold uppercase tracking-wider">{data.evaluated_role}</span>
                                </div>
                                <div>
                                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Evaluador</p>
                                    <p className="text-lg font-bold text-gray-700">{data.evaluator_name || 'Anónimo'}</p>
                                </div>
                                <div>
                                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Calificación</p>
                                    <div className="flex items-center gap-3">
                                        <div className={`text-4xl font-black ${data.desempeno_general >= 9 ? 'text-green-600' : data.desempeno_general >= 7 ? 'text-amber-500' : 'text-red-500'}`}>
                                            {data.desempeno_general}/10
                                        </div>
                                        <div className="h-8 w-px bg-gray-200"></div>
                                        <span className="text-sm font-bold text-gray-400 uppercase tracking-tighter">Score General</span>
                                    </div>
                                </div>
                            </>
                        ) : (
                            <>
                                <div>
                                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Cliente</p>
                                    <p className="text-xl font-black text-gray-900">{data.customer_name || 'Anónimo'}</p>
                                </div>
                                <div>
                                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">NPS Score</p>
                                    <div className="flex items-center gap-3">
                                        <div className={`text-4xl font-black ${data.nps_score >= 9 ? 'text-green-600' : data.nps_score >= 7 ? 'text-amber-500' : 'text-red-500'}`}>
                                            {data.nps_score}/10
                                        </div>
                                        <div className="h-8 w-px bg-gray-200"></div>
                                        <span className="text-sm font-bold text-gray-400 uppercase tracking-tighter">Customer Satisfaction</span>
                                    </div>
                                </div>
                            </>
                        )}
                    </div>

                    {/* Original Comments */}
                    {(data.comentarios || data.comments) && (
                        <div>
                            <p className="text-sm font-bold text-gray-900 mb-2">Comentarios Originales</p>
                            <div className="p-4 bg-white border border-gray-200 rounded-xl text-gray-600 text-sm italic">
                                "{data.comentarios || data.comments}"
                            </div>
                        </div>
                    )}

                    {/* Review Form */}
                    <div className="space-y-6 pt-6 border-t border-gray-100">
                        <div className="grid grid-cols-2 gap-8">
                            <div>
                                <label className="block text-sm font-black text-gray-900 uppercase tracking-widest mb-3">Estado de Revisión</label>
                                <select
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value)}
                                    className="w-full h-16 px-5 bg-white border border-gray-200 rounded-2xl text-lg font-black focus:ring-4 focus:ring-[#e31837]/5 outline-none transition-all shadow-sm"
                                >
                                    <option value="pending">⏳ Pendiente</option>
                                    <option value="reviewed">✅ Revisado</option>
                                    <option value="action_required">⚠️ Requiere Acción</option>
                                </select>
                            </div>

                            {/* Notification Toggle with Privacy Logic */}
                            <div className="flex flex-col justify-end">
                                <label className="flex items-center gap-3 p-3 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-50 transition-colors">
                                    <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${notifyUser ? 'bg-[#e31837] border-[#e31837]' : 'border-gray-300'}`}>
                                        {notifyUser && <span className="text-white text-xs">✓</span>}
                                    </div>
                                    <input
                                        type="checkbox"
                                        className="hidden"
                                        checked={notifyUser}
                                        onChange={(e) => setNotifyUser(e.target.checked)}
                                        disabled={isManagerOrSupervisor} // Disable if target is manager/supervisor (privacy)
                                    />
                                    <div>
                                        <span className={`text-sm font-bold ${isManagerOrSupervisor ? 'text-gray-400' : 'text-gray-900'}`}>Notificar Seguimiento</span>
                                        {isManagerOrSupervisor && (
                                            <p className="text-[10px] text-[#e31837] font-medium mt-0.5">Desactivado por privacidad (Manager/Supervisor)</p>
                                        )}
                                    </div>
                                </label>
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-black text-gray-900 uppercase tracking-widest mb-3">Observaciones del Administrador</label>
                            <textarea
                                value={observation}
                                onChange={(e) => setObservation(e.target.value)}
                                className="w-full p-6 bg-gray-50 border border-gray-200 rounded-2xl text-lg font-medium focus:ring-4 focus:ring-[#e31837]/5 outline-none min-h-[150px] resize-none shadow-inner"
                                placeholder="Escribe tus observaciones o acciones tomadas..."
                            />
                        </div>
                    </div>

                </div>

                {/* Footer */}
                <div className="p-8 border-t border-gray-100 bg-gray-50/50 flex justify-end gap-5">
                    <button
                        onClick={onClose}
                        className="px-8 py-4 text-sm font-black text-gray-400 uppercase tracking-widest hover:text-gray-900 hover:bg-white rounded-2xl transition-all"
                    >
                        Cancelar
                    </button>
                    <button
                        onClick={handleSubmit}
                        disabled={loading}
                        className="px-12 py-4 bg-[#e31837] text-white text-base font-black uppercase tracking-widest rounded-2xl hover:bg-red-700 active:scale-95 transition-all shadow-xl shadow-red-100 disabled:opacity-50"
                    >
                        {loading ? 'Guardando...' : '💾 Guardar Revisión'}
                    </button>
                </div>

            </div>
        </div>
    )
}
