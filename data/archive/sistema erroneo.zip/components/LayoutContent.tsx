'use client'

import { usePathname } from 'next/navigation'
import Sidebar from '@/components/Sidebar'
import ProtectedRoute from '@/components/ProtectedRoute'

export default function LayoutContent({
    children,
}: {
    children: React.ReactNode
}) {
    const pathname = usePathname()

    // Routes that should NOT have the sidebar or standard admin background
    const publicRoutes = ['/clientes', '/evaluacion', '/login', '/feedback-publico']
    const isPublic = publicRoutes.some(route => pathname.startsWith(route))

    if (isPublic) {
        return <>{children}</>
    }

    return (
        <div className="flex min-h-screen relative bg-gray-100">
            {/* Fondo decorativo con patrón invertido oscuro - FIJO al hacer scroll */}
            <div className="fixed inset-0 opacity-[0.35] bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]" style={{ filter: 'invert(1) brightness(0.2)' }}></div>

            <Sidebar />
            <main className="flex-1 overflow-x-hidden relative z-10">
                <ProtectedRoute>
                    {children}
                </ProtectedRoute>
            </main>
        </div>
    )
}
