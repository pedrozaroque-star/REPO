'use client'

import { useState, useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'
import { useRouter } from 'next/navigation'
import { config } from '@/lib/config'
import { supabase } from '@/lib/supabase'
import DetailsModal from './DetailsModal'
import FeedbackDetailModal, { Feedback } from './FeedbackDetailModal'

interface Notification {
  id: number
  title: string
  message: string
  link: string
  reference_id?: string | number | null
  reference_type?: string | null
  created_at: string
  read: boolean
  type: 'alert' | 'info' | 'success' | 'warning'
}

export default function NotificationBell({ light = false }: { light?: boolean }) {
  const router = useRouter()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [isOpen, setIsOpen] = useState(false)
  const [showAnimation, setShowAnimation] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const hasShownAnimation = useRef(false)

  // Estado para modal
  const [modalOpen, setModalOpen] = useState(false)
  const [modalChecklist, setModalChecklist] = useState<any>(null)
  const [modalType, setModalType] = useState<'manager' | 'assistant' | 'supervisor'>('assistant')

  // Feedback specific states
  const [feedbackModalOpen, setFeedbackModalOpen] = useState(false)
  const [selectedFeedback, setSelectedFeedback] = useState<Feedback | null>(null)

  const [userRole, setUserRole] = useState<string>('')
  const [userName, setUserName] = useState<string>('')

  // 🔊 Función para reproducir sonido de campana
  const playBellSound = () => {
    // PREVENIR ERRORES: Si el usuario no ha interactuado, no hacer nada (Bloquea warnings de Chrome)
    if (typeof navigator !== 'undefined' && (navigator as any).userActivation && !(navigator as any).userActivation.hasBeenActive) {
      return
    }

    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()

      const frequencies = [800, 1000, 1200]
      const duration = 0.5

      frequencies.forEach((freq, index) => {
        const oscillator = audioContext.createOscillator()
        const gainNode = audioContext.createGain()

        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)

        oscillator.frequency.value = freq
        oscillator.type = 'sine'

        const now = audioContext.currentTime
        gainNode.gain.setValueAtTime(0, now)
        gainNode.gain.linearRampToValueAtTime(0.3 / (index + 1), now + 0.01)
        gainNode.gain.exponentialRampToValueAtTime(0.01, now + duration)

        oscillator.start(now)
        oscillator.stop(now + duration)
      })

      setTimeout(() => {
        const oscillator2 = audioContext.createOscillator()
        const gainNode2 = audioContext.createGain()

        oscillator2.connect(gainNode2)
        gainNode2.connect(audioContext.destination)

        oscillator2.frequency.value = 1000
        oscillator2.type = 'sine'

        const now = audioContext.currentTime
        gainNode2.gain.setValueAtTime(0, now)
        gainNode2.gain.linearRampToValueAtTime(0.2, now + 0.01)
        gainNode2.gain.exponentialRampToValueAtTime(0.01, now + 0.3)

        oscillator2.start(now)
        oscillator2.stop(now + 0.3)
      }, 200)
    } catch (error) {
      console.error('Error al reproducir sonido:', error)
    }

    // 📱 Vibración si está disponible (Silent failure if blocked)
    try {
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate([200, 100, 200, 100, 400])
      }
    } catch (_) {
      // Ignore browser interventions for prohibited autoplay/vibrate
    }
  }

  useEffect(() => {
    // Obtener datos del usuario
    const userStr = localStorage.getItem('teg_user')
    if (userStr) {
      const user = JSON.parse(userStr)
      setUserRole(user.role || '')
      setUserName(user.full_name || user.email || '')
    }

    fetchNotifications()
    const interval = setInterval(fetchNotifications, 30000)
    return () => clearInterval(interval)
  }, [])

  const fetchNotifications = async () => {
    try {
      const userStr = localStorage.getItem('teg_user')
      if (!userStr) return

      const user = JSON.parse(userStr)
      const url = config.supabase.url
      const key = config.supabase.anonKey

      if (!url || !key) return

      const res = await fetch(
        `${url}/rest/v1/notifications?user_id=eq.${user.id}&order=created_at.desc&limit=20`,
        {
          headers: {
            'apikey': key,
            'Authorization': `Bearer ${key}`
          }
        }
      )

      if (res.ok) {
        const data = await res.json()
        const unread = data.filter((n: Notification) => !n.read).length

        setNotifications(data)
        setUnreadCount(unread)

        if (unread > 0 && !hasShownAnimation.current) {
          hasShownAnimation.current = true
          setShowAnimation(true)
          playBellSound()

          setTimeout(() => {
            setShowAnimation(false)
          }, 3500)
        }
      }
    } catch (error) {
      console.error('Error:', error)
    }
  }

  // Removed deprecated markAsRead batch function causing 400 errors

  const markNotificationAsRead = async (id: number) => {
    try {
      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('id', id)

      if (error) throw error

      setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n))
      setUnreadCount(prev => Math.max(0, prev - 1))
    } catch (error) {
      console.error('Error marking notification as read:', error)
    }
  }

  const toggleDropdown = () => {
    if (!isOpen) {
      setIsOpen(true)
      // No automarking as read
    } else {
      setIsOpen(false)
    }
  }

  const extractIdFromLink = (link: string): string | null => {
    try {
      const url = new URL(link, window.location.origin)
      const idFromQuery = url.searchParams.get('id')
      if (idFromQuery) return idFromQuery

      const pathSegments = url.pathname.split('/').filter(Boolean)
      const lastSegment = pathSegments[pathSegments.length - 1]
      if (lastSegment && !isNaN(parseInt(lastSegment))) {
        return lastSegment
      }
      return null
    } catch {
      return null
    }
  }

  const handleNotificationClick = async (notification: Notification) => {
    if (!notification.link) return

    try {
      console.log('🔔 Clicked notification:', notification)
      const id = notification.reference_id || extractIdFromLink(notification.link)
      const refType = notification.reference_type

      console.log('🔍 Identifier:', id, 'RefType:', refType)

      // Always try to mark as read (non-blocking)
      if (!notification.read) {
        markNotificationAsRead(notification.id)
      }

      if (!id) {
        console.warn('⚠️ No ID found, navigating to link')
        router.push(notification.link)
        setIsOpen(false)
        return
      }

      let tableName = ''
      let type: 'manager' | 'assistant' | 'supervisor' = 'assistant'

      // 1. Prioridad: Usar reference_type del Trigger
      if (refType) {
        if (refType === 'assistant') {
          tableName = 'assistant_checklists'
          type = 'assistant'
        } else if (refType === 'manager') {
          tableName = 'manager_checklists'
          type = 'manager'
        } else if (refType === 'supervisor_inspection' || refType === 'supervisor') {
          tableName = 'supervisor_inspections'
          type = 'supervisor'
        } else if (refType === 'feedback') {
          tableName = 'customer_feedback'
        }
      }

      // 2. Fallback: Parseo de URL (Legado)
      if (!tableName) {
        const url = new URL(notification.link, window.location.origin)
        const pathname = url.pathname
        console.log('📂 Fallback Pathname:', pathname)

        if (pathname.includes('checklists-manager')) {
          tableName = 'manager_checklists'
          type = 'manager'
        } else if (pathname.includes('checklists') || pathname.includes('assistant')) {
          tableName = 'assistant_checklists'
          type = 'assistant'
        } else if (pathname.includes('inspecciones') || pathname.includes('supervisor')) {
          tableName = 'supervisor_inspections'
          type = 'supervisor'
        } else if (pathname.includes('feedback')) {
          tableName = 'customer_feedback'
        }
      }

      if (!tableName) {
        router.push(notification.link)
        setIsOpen(false)
        return
      }

      console.log('Fetching table:', tableName, 'ID:', id)

      // Use Supabase client directly
      const { data, error } = await supabase
        .from(tableName)
        .select('*')
        .eq('id', id)

      if (error) {
        console.error('❌ Fetch error:', error)
        router.push(notification.link)
        setIsOpen(false)
        return
      }

      if (data && data.length > 0) {
        const record = data[0]
        console.log('📦 Data received:', record)

        if (tableName === 'customer_feedback') {
          setSelectedFeedback(record)
          setFeedbackModalOpen(true)
          setIsOpen(false)
          return
        }

        // Handle Checklists
        if (record.store_id && !record.store_name) {
          const { data: sData } = await supabase.from('stores').select('name').eq('id', record.store_id).single()
          if (sData) record.store_name = sData.name
        }

        setModalChecklist(record)
        setModalType(type)
        setModalOpen(true) // Corrected from setDetailsModalOpen
        setIsOpen(false)
      } else {
        console.warn('⚠️ Record not found')
        router.push(notification.link)
        setIsOpen(false)
      }

    } catch (error) {
      console.error('Error in handleNotificationClick:', error)
      router.push(notification.link)
      setIsOpen(false)
    }
  }

  const handleModalClose = () => {
    setModalOpen(false)
    setModalChecklist(null)
    fetchNotifications()
  }

  const getIcon = (type: string) => {
    switch (type) {
      case 'alert': return '🚨';
      case 'success': return '✅';
      case 'warning': return '⚠️';
      default: return 'ℹ️';
    }
  }

  return (
    <>
      {/* 🎬 ANIMACIÓN ESPECTACULAR DE ENTRADA */}
      {showAnimation && typeof document !== 'undefined' && createPortal(
        <div className="fixed inset-0 z-[9999] pointer-events-none flex items-center justify-center bg-indigo-900/40 backdrop-blur-md animate-in fade-in duration-500">
          <div className="bell-entrance-animation relative">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40rem] h-[40rem] bg-indigo-500/20 rounded-full blur-[100px] animate-pulse" />

            <div className="text-[20rem] animate-shake filter drop-shadow-[0_0_50px_rgba(255,255,255,0.4)]">
              🔔
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="bg-gradient-to-br from-red-500 to-rose-700 text-white rounded-full w-40 h-40 flex flex-col items-center justify-center text-6xl font-black animate-bounce border-8 border-white shadow-[0_0_50px_rgba(244,63,94,0.6)]">
                <span className="text-sm uppercase tracking-widest opacity-80 mb-1">Nuevas</span>
                {unreadCount}
              </div>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* CAMPANA NORMAL EN SIDEBAR */}
      <div className="relative" ref={dropdownRef}>
        <button
          onClick={toggleDropdown}
          className={`relative p-2 transition-all rounded-full hover:bg-white/10 focus:outline-none focus:ring-2 ${light ? 'text-white focus:ring-white/20' : 'text-indigo-100 focus:ring-indigo-500/50'}`}
        >
          <span className="text-2xl filter drop-shadow-sm">🔔</span>

          {unreadCount > 0 && (
            <span className={`absolute top-0 right-0 inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] font-black leading-none text-white transform translate-x-1/4 -translate-y-1/4 bg-red-600 rounded-full border-2 ${light ? 'border-red-600' : 'border-indigo-900'} animate-pulse shadow-lg`}>
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </button>

        {isOpen && (
          <>
            <div
              className="fixed inset-0 z-40 bg-black/10 backdrop-blur-[2px] md:bg-transparent md:backdrop-blur-none"
              onClick={() => setIsOpen(false)}
            />

            <div className="fixed z-50 bottom-0 left-0 right-0 mx-4 mb-4 max-h-[70vh] flex flex-col md:left-64 md:bottom-20 md:w-96 md:mx-0 bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/20 overflow-hidden ring-1 ring-black/5 animate-in slide-in-from-bottom-4 fade-in duration-300">

              <div className="px-5 py-4 bg-gradient-to-r from-indigo-50/50 to-purple-50/50 border-b border-gray-100 flex justify-between items-center">
                <h3 className="text-sm font-black text-indigo-900 uppercase tracking-widest">Notificaciones</h3>
                <span className="bg-indigo-600 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">{unreadCount} nuevas</span>
                <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-red-500 md:hidden">✕</button>
              </div>

              <div className="overflow-y-auto overscroll-contain max-h-[60vh] md:max-h-96 custom-scrollbar">
                {notifications.length === 0 ? (
                  <div className="px-6 py-12 text-center">
                    <div className="text-5xl mb-4 grayscale opacity-20">🔕</div>
                    <p className="text-gray-400 font-medium text-sm">No tienes notificaciones nuevas</p>
                  </div>
                ) : (
                  <div className="divide-y divide-gray-50">
                    {notifications.map((n) => (
                      <div
                        key={n.id}
                        onClick={() => handleNotificationClick(n)}
                        className={`px-5 py-4 hover:bg-white/50 transition-all cursor-pointer group relative ${!n.read ? 'bg-indigo-50/30' : ''}`}
                      >
                        {!n.read && <div className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-500" />}
                        <div className="flex items-start gap-4">
                          <span className="text-2xl mt-1 transform group-hover:scale-125 transition-transform duration-300">{getIcon(n.type)}</span>
                          <div className="flex-1 min-w-0">
                            <p className={`text-sm tracking-tight truncate ${!n.read ? 'font-black text-gray-900' : 'font-semibold text-gray-600'}`}>{n.title}</p>
                            <p className="text-xs text-gray-500 mt-1 line-clamp-2 leading-relaxed">{n.message}</p>
                            <div className="flex items-center justify-between mt-2">
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{new Date(n.created_at).toLocaleString()}</p>
                              <span className="text-[10px] font-black text-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity">VER DETALLE →</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-white/50 p-2 border-t border-gray-100 text-center">
                <button onClick={() => setIsOpen(false)} className="text-[10px] font-black uppercase tracking-widest text-indigo-400 hover:text-indigo-600 py-2 w-full transition-colors">Cerrar panel</button>
              </div>
            </div>
          </>
        )}
      </div>

      {modalOpen && modalChecklist && (
        <DetailsModal
          isOpen={modalOpen}
          onClose={handleModalClose}
          checklist={modalChecklist}
          type={modalType}
          userRole={userRole}
          userName={userName}
          onReviewSubmit={fetchNotifications}
        />
      )}

      {feedbackModalOpen && selectedFeedback && (
        <FeedbackDetailModal
          isOpen={feedbackModalOpen}
          feedback={selectedFeedback}
          onClose={() => {
            setFeedbackModalOpen(false)
            setSelectedFeedback(null)
            fetchNotifications()
          }}
        />
      )}

      <style jsx>{`
        .bell-entrance-animation { animation: bellEntrance 3.5s cubic-bezier(0.34, 1.56, 0.64, 1) forwards; }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        @keyframes bellEntrance {
          0% { transform: scale(0) rotate(-45deg); opacity: 0; filter: blur(20px); }
          15% { transform: scale(1.2) rotate(0deg); opacity: 1; filter: blur(0); }
          20% { transform: scale(1) rotate(-10deg); }
          25% { transform: scale(1.1) rotate(10deg); }
          30% { transform: scale(1) rotate(-10deg); }
          35% { transform: scale(1.1) rotate(10deg); }
          40% { transform: scale(1) rotate(0deg); }
          85% { transform: scale(1); opacity: 1; }
          100% { transform: scale(1.5); opacity: 0; filter: blur(10px); }
        }
        @keyframes shake {
          0%, 100% { transform: rotate(0deg); }
          10%, 30%, 50%, 70%, 90% { transform: rotate(-8deg); }
          20%, 40%, 60%, 80% { transform: rotate(8deg); }
        }
        .animate-shake { animation: shake 0.4s ease-in-out infinite; }
      `}</style>
    </>
  )
}