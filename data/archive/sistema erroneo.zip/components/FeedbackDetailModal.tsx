'use client'

import { createPortal } from 'react-dom'
import { format } from 'date-fns'
import { es } from 'date-fns/locale'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

export interface Feedback {
    id: number
    submission_date: string
    store_id: string
    customer_name: string
    service_rating: number
    speed_rating: number
    food_quality_rating: number
    cleanliness_rating: number
    nps_score: number
    nps_category: string
    comments: string
    photo_urls: string[] | null
    stores: { name: string } | null
    admin_review_status?: 'pendiente' | 'aprobado' | 'rechazado' | 'corregir'
    admin_review_comments?: string
    email?: string
    visit_frequency?: string
    ticket_url?: string
}

import { useAuth } from './ProtectedRoute'

function AdminReviewPanel({ feedback, onClose }: { feedback: Feedback, onClose: () => void }) {
    const [reviewMode, setReviewMode] = useState<'none' | 'reject'>('none')
    const [comment, setComment] = useState('')
    const [loading, setLoading] = useState(false)
    const { user } = useAuth()

    // Check if user is admin based on auth context (same as Sidebar)
    const isAdmin = user?.role === 'admin'

    if (!isAdmin) return null

    const handleApprove = async () => {
        setLoading(true)
        const { error } = await supabase
            .from('customer_feedback')
            .update({
                admin_review_status: 'aprobado',
                admin_review_date: new Date().toISOString()
            })
            .eq('id', feedback.id)

        setLoading(false)
        if (!error) {
            onClose()
            // Force reload page logic would be better here, but onClose triggers list update if passed correctly
            window.location.reload() // Simple refresh to show updated status
        } else {
            console.error('Error approving:', error)
            alert('Error al aprobar: ' + error.message)
        }
    }

    const handleReject = async () => {
        if (!comment.trim()) return
        setLoading(true)
        const { error } = await supabase
            .from('customer_feedback')
            .update({
                admin_review_status: 'rechazado', // Map to DB enum
                admin_review_comments: comment,
                admin_review_date: new Date().toISOString()
            })
            .eq('id', feedback.id)

        setLoading(false)
        if (!error) {
            onClose()
            window.location.reload()
        } else {
            console.error('Error rejecting:', error)
            alert('Error al rechazar: ' + error.message)
        }
    }

    if (reviewMode === 'reject') {
        return (
            <div className="bg-red-50 p-6 border-t border-red-100 flex flex-col gap-4 animate-in slide-in-from-bottom-4">
                <h4 className="font-bold text-red-900">Motivo del Rechazo / Corrección</h4>
                <textarea
                    className="w-full p-3 border border-red-200 rounded-xl focus:ring-2 focus:ring-red-500/20 outline-none text-sm"
                    placeholder="Describe qué debe corregirse..."
                    rows={3}
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    autoFocus
                />
                <div className="flex gap-3 justify-end">
                    <button
                        onClick={() => setReviewMode('none')}
                        className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm font-bold"
                    >
                        Cancelar
                    </button>
                    <button
                        onClick={handleReject}
                        disabled={loading || !comment.trim()}
                        className="px-6 py-2 bg-red-600 text-white rounded-lg text-sm font-bold hover:bg-red-700 disabled:opacity-50 shadow-sm"
                    >
                        {loading ? 'Enviando...' : 'Confirmar Rechazo'}
                    </button>
                </div>
            </div>
        )
    }

    // Only show approve buttons if not already approved/rejected (or allow re-review)
    return (
        <div className="bg-gray-900 p-4 border-t border-gray-800 flex justify-between items-center text-white">
            <span className="text-gray-400 text-xs font-bold uppercase tracking-wider">Panel de Administrador</span>
            <div className="flex gap-3">
                <button
                    onClick={() => setReviewMode('reject')}
                    className="px-4 py-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 text-red-400 rounded-lg text-sm font-bold transition-colors"
                >
                    ⚠️ Rechazar / Corregir
                </button>
                <button
                    onClick={handleApprove}
                    disabled={loading}
                    className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-sm font-bold shadow-lg shadow-emerald-500/20 transition-all hover:scale-105 active:scale-95"
                >
                    {loading ? 'Procesando...' : '✅ Aprobar Feedback'}
                </button>
            </div>
        </div>
    )
}

interface FeedbackDetailModalProps {
    isOpen: boolean
    onClose: () => void
    feedback: Feedback | null
}

export default function FeedbackDetailModal({ isOpen, onClose, feedback }: FeedbackDetailModalProps) {
    const [mounted, setMounted] = useState(false)

    useEffect(() => {
        setMounted(true)
        return () => setMounted(false)
    }, [])

    if (!mounted || !isOpen || !feedback) return null

    const headerImage = getStoreImage(feedback.stores?.name)

    return createPortal(
        <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4">
            <div
                className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
                onClick={onClose}
            />

            <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
                <div className="flex-1 overflow-y-auto custom-scrollbar">
                    <div className={`relative ${headerImage ? 'h-48' : 'h-16'} bg-gray-900 transition-all`}>
                        {headerImage && (
                            <>
                                <img
                                    src={headerImage}
                                    alt="Store"
                                    className="w-full h-full object-cover opacity-60"
                                />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                            </>
                        )}
                        <button
                            onClick={onClose}
                            className={`absolute top-4 right-4 ${headerImage ? 'bg-black/50 hover:bg-black/70' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'} ${headerImage ? 'text-white' : ''} rounded-full p-2 transition-colors z-10 flex items-center justify-center`}
                        >
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>

                    <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
                        {/* 🔔 Estatus de Revisión (Visible para todos) */}
                        {feedback.admin_review_status && feedback.admin_review_status !== 'pendiente' && (
                            <div className="col-span-1 md:col-span-2">
                                <div className={`rounded-2xl p-6 border ${feedback.admin_review_status === 'aprobado'
                                    ? 'bg-emerald-50 border-emerald-100'
                                    : 'bg-red-50 border-red-100'
                                    }`}>
                                    <div className="flex items-start gap-4">
                                        <div className={`p-3 rounded-xl ${feedback.admin_review_status === 'aprobado'
                                            ? 'bg-emerald-100 text-emerald-600'
                                            : 'bg-red-100 text-red-600'
                                            }`}>
                                            {feedback.admin_review_status === 'aprobado'
                                                ? <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                                                : <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                                            }
                                        </div>
                                        <div className="flex-1">
                                            <h4 className={`text-lg font-black uppercase tracking-tight mb-1 ${feedback.admin_review_status === 'aprobado' ? 'text-emerald-900' : 'text-red-900'
                                                }`}>
                                                {feedback.admin_review_status === 'aprobado' ? 'Feedback Aprobado' : 'Requiere Atención'}
                                            </h4>
                                            {feedback.admin_review_comments && (
                                                <div className="mt-2 bg-white/60 p-3 rounded-lg border border-black/5">
                                                    <p className="text-xs font-bold uppercase tracking-widest opacity-50 mb-1">Comentarios del Admin:</p>
                                                    <p className={`font-medium ${feedback.admin_review_status === 'aprobado' ? 'text-emerald-800' : 'text-red-800'
                                                        }`}>
                                                        "{feedback.admin_review_comments}"
                                                    </p>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                        <div className="space-y-6">
                            <div>
                                <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-4">Cliente</h3>
                                <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 space-y-3">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <p className="text-xs text-gray-400 font-bold uppercase">Nombre</p>
                                            <p className="font-medium text-gray-900">{feedback.customer_name || 'Anónimo'}</p>
                                        </div>
                                        {feedback.nps_score !== undefined && (
                                            <div className={`flex flex-col items-end`}>
                                                <div className={`px-2 py-1 rounded-lg text-xs font-bold ${feedback.nps_score >= 9 ? 'bg-emerald-100 text-emerald-700' : feedback.nps_score >= 7 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`}>
                                                    NPS: {feedback.nps_score}
                                                </div>
                                                <span className="text-[10px] text-gray-400 uppercase mt-1">{feedback.nps_category}</span>
                                            </div>
                                        )}
                                    </div>

                                    <div className="grid grid-cols-2 gap-4 pt-2 border-t border-gray-200">
                                        <div>
                                            <p className="text-xs text-gray-400 font-bold uppercase">Fecha</p>
                                            <p className="text-sm text-gray-700 font-mono">
                                                {feedback.submission_date ? format(new Date(feedback.submission_date), "d MMM yyyy", { locale: es }) : '-'}
                                            </p>
                                            <p className="text-xs text-gray-500 font-mono">
                                                {feedback.submission_date ? format(new Date(feedback.submission_date), "HH:mm a", { locale: es }) : ''}
                                            </p>
                                        </div>
                                        {feedback.visit_frequency && (
                                            <div>
                                                <p className="text-xs text-gray-400 font-bold uppercase">Frecuencia</p>
                                                <p className="text-sm text-gray-700">{feedback.visit_frequency}</p>
                                            </div>
                                        )}
                                        {feedback.email && (
                                            <div className="col-span-2">
                                                <p className="text-xs text-gray-400 font-bold uppercase">Email</p>
                                                <p className="text-sm text-gray-700 break-all">{feedback.email}</p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>

                            <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-4">Calificaciones</h3>
                            <div className="grid grid-cols-2 gap-4">
                                <ScoreCard label="Servicio" score={feedback.service_rating} />
                                <ScoreCard label="Rapidez" score={feedback.speed_rating} />
                                <ScoreCard label="Calidad" score={feedback.food_quality_rating} />
                                <ScoreCard label="Limpieza" score={feedback.cleanliness_rating} />
                            </div>
                        </div>

                        <div className="space-y-6">
                            <div>
                                <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-2">Comentarios</h3>
                                <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100">
                                    <p className="text-gray-700 italic leading-relaxed">"{feedback.comments || 'Sin comentarios'}"</p>
                                </div>
                            </div>

                            {feedback.photo_urls && feedback.photo_urls.length > 0 && (
                                <div>
                                    <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-2">Evidencia ({feedback.photo_urls.length})</h3>
                                    <div className="grid grid-cols-3 gap-2">
                                        {feedback.photo_urls.map((url, i) => (
                                            <a key={i} href={getImageUrl(url)} target="_blank" rel="noopener noreferrer" className="aspect-square rounded-xl overflow-hidden border border-gray-200 hover:opacity-80 transition-opacity">
                                                <img src={getImageUrl(url)} alt="Evidence" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                            </a>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {feedback.ticket_url && (
                                <div>
                                    <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-2">Ticket de Compra</h3>
                                    <div className="grid grid-cols-3 gap-2">
                                        <a href={getImageUrl(feedback.ticket_url)} target="_blank" rel="noopener noreferrer" className="aspect-square rounded-xl overflow-hidden border border-gray-200 hover:opacity-80 transition-opacity">
                                            <img src={getImageUrl(feedback.ticket_url)} alt="Ticket" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                        </a>
                                    </div>
                                </div>
                            )}


                        </div>
                    </div>
                </div>

                <div className="flex-none">
                    <AdminReviewPanel feedback={feedback} onClose={onClose} />
                </div>
            </div>
        </div>,
        document.body
    )
}

function ScoreCard({ label, score }: { label: string, score: number }) {
    const getColor = (s: number) => {
        if (s >= 5) return 'text-emerald-500 bg-emerald-50 border-emerald-100'
        if (s >= 4) return 'text-blue-500 bg-blue-50 border-blue-100'
        if (s >= 3) return 'text-yellow-500 bg-yellow-50 border-yellow-100'
        return 'text-red-500 bg-red-50 border-red-100'
    }

    return (
        <div className={`p-3 rounded-xl border flex flex-col items-center justify-center ${getColor(score)}`}>
            <span className="text-3xl font-black mb-1">{score.toFixed(1)}</span>
            <span className="text-[10px] font-bold uppercase tracking-widest opacity-70">{label}</span>
        </div>
    )
}

// 📸 Helper para imágenes de sucursales
function getStoreImage(storeName: string | undefined): string {
    if (!storeName) return 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=1000'

    // Normalizar nombre para búsqueda (Safe cast)
    const name = String(storeName || '').toLowerCase()

    // 🌮 Tacos Gavilan (Rojo/Branding)
    if (name.includes('gavilan') || name.includes('gavilán')) {
        return 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&q=80&w=1000'
    }
    // 🦌 El Venado (Tonos más rústicos)
    if (name.includes('venado')) {
        return 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80&w=1000'
    }
    // 🏭 Layout Industrial/General (REMOVED fallback as requested)
    return ''
}

// 🖼️ Helper mejorado para URLs (Soporta Google Drive + Supabase)
function getImageUrl(url: string) {
    if (!url) return ''

    // Soporte para Google Drive (Thumbnails)
    if (url.includes('drive.google.com')) {
        const idMatch = url.match(/\/d\/([a-zA-Z0-9_-]+)/) || url.match(/id=([a-zA-Z0-9_-]+)/)
        if (idMatch && idMatch[1]) {
            return `https://drive.google.com/thumbnail?id=${idMatch[1]}&sz=w800`
        }
    }

    if (url.startsWith('http')) return url
    return `https://ywwwdcvgfculqmcfkihq.supabase.co/storage/v1/object/public/evidence/${url}`
}
