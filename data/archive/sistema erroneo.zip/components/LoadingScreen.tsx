'use client'

export default function LoadingScreen({ message = 'Cargando Información...' }: { message?: string }) {
    return (
        <div className="flex-1 flex flex-col items-center justify-center min-h-[60vh] p-8">
            <div className="flex flex-col items-center space-y-6">
                {/* Simple Brand Reveal */}
                <div className="relative">
                    <img
                        src="/logo.png"
                        alt="TAG"
                        className="h-16 w-auto object-contain opacity-80"
                    />
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-8 h-[2px] bg-[#fdc82f] rounded-full"></div>
                </div>

                {/* Minimal Progress */}
                <div className="flex flex-col items-center gap-4">
                    <div className="w-32 h-[3px] bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full bg-[#e31837] w-1/3 rounded-full animate-loading-bar"></div>
                    </div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] animate-pulse">
                        {message}
                    </p>
                </div>
            </div>

            <style jsx>{`
        @keyframes loading-bar {
          0% { transform: translateX(-110%); }
          100% { transform: translateX(310%); }
        }
        .animate-loading-bar {
          animation: loading-bar 1.5s infinite ease-in-out;
        }
      `}</style>
        </div>
    )
}
