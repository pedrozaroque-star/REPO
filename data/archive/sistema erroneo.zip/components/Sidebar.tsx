'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import NotificationBell from './NotificationBell'
import { useState, useMemo, useEffect } from 'react'
import { useAuth } from './ProtectedRoute'

export default function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { user } = useAuth()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [isMounted, setIsMounted] = useState(false)

  // State for collapsible sections, initially all closed
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    'General': false,
    'Operación': false,
    'Gestión y Equipo': false,
    'Calidad y Servicio': false,
    'Experiencia QR': false
  })

  useEffect(() => {
    const saved = localStorage.getItem('sidebar_collapsed')
    setIsCollapsed(saved === 'true')
    setIsMounted(true)
  }, [])

  const toggleSidebar = () => {
    const newState = !isCollapsed
    setIsCollapsed(newState)
    localStorage.setItem('sidebar_collapsed', newState.toString())
  }

  const toggleSection = (title: string) => {
    setOpenSections(prev => ({
      ...prev,
      [title]: !prev[title]
    }))
  }

  const handleLogout = () => {
    localStorage.removeItem('sidebar_collapsed')
    localStorage.removeItem('teg_token')
    localStorage.removeItem('teg_user')
    router.push('/login')
  }

  const menuGroups = [
    {
      title: 'General',
      items: [
        { name: 'Dashboard', path: '/dashboard', icon: '📊', roles: ['manager', 'supervisor', 'admin'] },
        { name: 'Reportes', path: '/reportes', icon: '📈', roles: ['manager', 'supervisor', 'admin'] },
        { name: 'Estadísticas', path: '/estadisticas', icon: '📉', roles: ['manager', 'supervisor', 'admin'] }
      ]
    },
    {
      title: 'Operación',
      items: [
        { name: 'Checklists', path: '/checklists', icon: '✅', roles: ['asistente', 'manager', 'supervisor', 'admin'] },
        { name: 'Checklists Manager', path: '/checklists-manager', icon: '👔', roles: ['manager', 'supervisor', 'admin'] },
        { name: 'Inspecciones', path: '/inspecciones', icon: '📋', roles: ['supervisor', 'admin'] },
        { name: 'Horarios', path: '/horarios', icon: '📅', roles: ['manager', 'supervisor', 'admin'] }
      ]
    },
    {
      title: 'Gestión y Equipo',
      items: [
        { name: 'Usuarios', path: '/usuarios', icon: '👥', roles: ['admin'] },
        { name: 'Tiendas', path: '/tiendas', icon: '🏪', roles: ['admin'] },
        { name: 'Evaluaciones Staff', path: '/staff-evaluations', icon: '📋', roles: ['manager', 'supervisor', 'admin'] }
      ]
    },
    {
      title: 'Calidad y Servicio',
      items: [
        { name: 'Feedback Clientes', path: '/feedback', icon: '💬', roles: ['asistente', 'manager', 'supervisor', 'admin'] }
      ]
    },
    {
      title: 'Experiencia QR',
      items: [
        { name: 'Eval. Staff (QR)', path: '/evaluacion', icon: '📱', roles: ['admin'] },
        { name: 'Clientes (QR)', path: '/clientes', icon: '⭐', roles: ['admin'] }
      ]
    }
  ]

  const filteredGroups = useMemo(() => {
    return menuGroups.map(group => ({
      ...group,
      items: group.items.filter(item => {
        if (!item.roles || item.roles.length === 0) return true
        if (!user?.role) return false
        return item.roles.includes(user.role.toLowerCase())
      })
    })).filter(group => group.items.length > 0)
  }, [user?.role])

  // Prevent hydration mismatch
  if (!isMounted) return <div className="hidden md:flex flex-col w-64 h-screen bg-[#e31837]" />

  return (
    <>
      {/* Sidebar para Desktop */}
      <div className={`hidden md:flex flex-col sticky top-0 h-screen z-50 transition-all duration-300 ease-[cubic-bezier(0.25,0.1,0.25,1)] ${isCollapsed ? 'w-20' : 'w-72'}`}>

        {/* Background with Dark Subtle Gradient */}
        <div className="flex flex-col h-full bg-gradient-to-b from-[#e31837] via-[#c0102a] to-[#50050a] border-r border-red-900 shadow-2xl relative">

          {/* Collapse Toggle Button */}
          <button
            onClick={toggleSidebar}
            className={`absolute -right-3 top-10 z-50 w-7 h-7 bg-white rounded-full shadow-md border border-gray-100 flex items-center justify-center text-[10px] text-red-600 transition-transform duration-300 hover:scale-110 active:scale-95 hover:bg-red-50 focus:outline-none ${isCollapsed ? 'rotate-180' : ''}`}
            title={isCollapsed ? "Expandir Menú" : "Colapsar Menú"}
          >
            ◀
          </button>

          {/* Logo Branding Section */}
          <div className={`flex flex-col items-center justify-center transition-all duration-300 ${isCollapsed ? 'py-6 px-2' : 'py-10 px-6'}`}>
            <div className={`bg-white rounded-full shadow-lg flex items-center justify-center transition-all duration-300 overflow-hidden ${isCollapsed ? 'w-12 h-12 p-1.5' : 'w-36 h-36 p-1'}`}>
              <img
                src="/logo.png"
                alt="Tacos Gavilán"
                className="w-full h-full object-contain"
                onError={(e) => { e.currentTarget.style.display = 'none'; }}
              />
            </div>

            {!isCollapsed && (
              <div className="mt-6 flex flex-col items-center animate-in fade-in slide-in-from-bottom-2 duration-500">
                <div className="h-1 w-12 bg-[#fdc82f] rounded-full mb-3 shadow-sm"></div>
                <span className="text-2xl font-bold text-white tracking-wide drop-shadow-sm">Tacos Gavilan</span>
              </div>
            )}
          </div>

          {/* Expand/Collapse All Control */}
          {!isCollapsed && (
            <div className="px-6 pb-2 -mt-4 flex justify-center animate-in fade-in duration-500 delay-100">
              <button
                onClick={() => {
                  const allOpen = Object.values(openSections).every(Boolean)
                  const newState = Object.keys(openSections).reduce((acc, key) => ({ ...acc, [key]: !allOpen }), {})
                  setOpenSections(newState)
                }}
                className="text-[10px] font-bold uppercase tracking-[0.15em] text-white/50 hover:text-[#fdc82f] transition-all flex items-center gap-2 group"
              >
                <span className="group-hover:scale-110 transition-transform">{Object.values(openSections).every(Boolean) ? 'T' : '▼'}</span>
                {Object.values(openSections).every(Boolean) ? 'Colapsar Todo' : 'Expandir Todo'}
              </button>
            </div>
          )}

          {/* Scrollable Navigation Area */}
          <nav className="flex-1 px-4 space-y-6 overflow-y-auto scrollbar-hide py-4 font-gotham">
            {filteredGroups.map((group) => {
              const isOpen = openSections[group.title] !== false // defaults to true if missing, but now "Experiencia QR" is initialized

              return (
                <div key={group.title} className="space-y-2">
                  {!isCollapsed ? (
                    <button
                      onClick={() => toggleSection(group.title)}
                      className="w-full flex items-center justify-start gap-3 px-3 group/header hover:bg-white/5 rounded-lg py-2 transition-colors"
                    >
                      <h3 className="text-[15px] font-medium text-[#fdc82f] opacity-100 drop-shadow-sm">
                        {group.title}
                      </h3>
                      <span className={`text-[#fdc82f] text-[10px] transition-transform duration-300 opacity-80 ${isOpen ? 'rotate-180' : ''}`}>
                        ▼
                      </span>
                    </button>
                  ) : (
                    <div className="h-[1px] w-8 bg-[#fdc82f]/50 mx-auto my-2"></div>
                  )}

                  <div className={`space-y-1 overflow-hidden transition-all duration-300 ease-in-out ${isOpen || isCollapsed ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'}`}>
                    {group.items.map((item) => {
                      const isActive = pathname === item.path
                      return (
                        <Link
                          key={item.name}
                          href={item.path}
                          title={isCollapsed ? item.name : ''}
                          className={`
                            group flex items-center min-h-[50px] text-[16px] font-medium tracking-normal rounded-r-xl transition-all duration-200 relative
                            ${isCollapsed ? 'justify-center rounded-xl mx-0 p-2' : 'pl-4 pr-3'}
                            ${isActive
                              ? 'bg-gradient-to-r from-white/10 to-transparent text-white'
                              : 'text-white/90 hover:text-white hover:bg-white/5'
                            }
                          `}
                        >
                          {/* Active Indicator Border */}
                          {isActive && !isCollapsed && (
                            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-[#fdc82f] rounded-r-full shadow-[0_0_8px_rgba(253,200,47,0.6)]"></div>
                          )}

                          <span className={`text-2xl transition-transform duration-200 group-hover:scale-110 z-10 ${isCollapsed ? '' : 'mr-4'} ${isActive ? 'text-white drop-shadow-md' : 'text-white/90'}`}>
                            {item.icon}
                          </span>

                          {!isCollapsed && (
                            <span className="font-medium">
                              {item.name}
                            </span>
                          )}
                        </Link>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </nav>

          {/* Fixed User Footer Section */}
          <div className={`flex-shrink-0 bg-black/20 backdrop-blur-sm border-t border-white/10 ${isCollapsed ? 'p-3' : 'p-5'}`}>
            {!isCollapsed ? (
              <div className="space-y-4 animate-in fade-in duration-300">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 flex-shrink-0 rounded-xl bg-white flex items-center justify-center text-[#e31837] font-medium shadow-lg border-2 border-[#fdc82f]">
                    {user?.name?.[0] || user?.email?.[0] || '?'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[14px] font-medium text-white truncate capitalize tracking-tight">
                      {user?.name || user?.email?.split('@')[0]}
                    </p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#fdc82f] animate-pulse shadow-[0_0_5px_#fdc82f]"></span>
                      <p className="text-[11px] font-medium text-[#fdc82f] uppercase tracking-widest opacity-90">
                        {user?.role || 'Admin'}
                      </p>
                    </div>
                  </div>
                  <NotificationBell light />
                </div>
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center justify-center px-4 py-3 text-[12px] font-medium uppercase tracking-[0.1em] text-white/90 bg-white/10 border border-white/10 rounded-xl hover:bg-white hover:text-[#e31837] transition-all duration-300 active:scale-95 hover:shadow-lg"
                >
                  Cerrar Sesión
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-4">
                <div className="h-9 w-9 rounded-xl bg-white flex items-center justify-center text-[#e31837] font-medium shadow-md border border-[#fdc82f]">
                  {user?.name?.[0] || user?.email?.[0] || '?'}
                </div>
                <NotificationBell light />
                <button
                  onClick={handleLogout}
                  className="w-9 h-9 flex items-center justify-center rounded-xl bg-white/10 text-white/60 hover:bg-white hover:text-[#e31837] transition-all active:scale-95"
                  title="Cerrar Sesión"
                >
                  🚪
                </button>
              </div>
            )}
          </div>
        </div>
      </div >

      {/* Mobile Header Bar */}
      < div className="md:hidden fixed top-0 left-0 right-0 z-40 bg-white border-b border-gray-200 px-5 py-3 flex items-center justify-between shadow-sm lg:hidden" >
        <img src="/logo.png" alt="TAG" className="h-8 w-auto object-contain" />
        <div className="flex items-center gap-3">
          <NotificationBell />
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-gray-900 p-2.5 hover:bg-gray-50 rounded-xl transition-colors border border-gray-100/50 shadow-sm"
          >
            {mobileMenuOpen ? '✕' : '☰'}
          </button>
        </div>
      </div >

      {/* Mobile Menu Overlay */}
      {
        mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-[60] flex">
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity" onClick={() => setMobileMenuOpen(false)} />

            <div className="relative w-[300px] max-w-[85vw] bg-gradient-to-br from-[#e31837] to-[#b91c1c] h-full shadow-2xl flex flex-col animate-in slide-in-from-left duration-300">
              {/* Mobile Header inside Menu */}
              <div className="flex items-center justify-between p-6 border-b border-white/10">
                <div className="bg-white p-2 rounded-full shadow-lg">
                  <img src="/logo.png" alt="TAG" className="h-10 w-auto object-contain" />
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-10 h-10 flex items-center justify-center bg-white/10 rounded-full text-white hover:bg-white hover:text-[#e31837] transition-all"
                >
                  ✕
                </button>
              </div>

              <nav className="flex-1 px-4 py-6 space-y-8 overflow-y-auto scrollbar-hide">
                {filteredGroups.map((group) => (
                  <div key={group.title} className="space-y-3">
                    <h3 className="px-2 text-[15px] font-medium text-[#fdc82f] border-b border-white/10 pb-1 mb-2">
                      {group.title}
                    </h3>
                    <div className="space-y-1">
                      {group.items.map((item) => {
                        const isActive = pathname === item.path
                        return (
                          <Link
                            key={item.name}
                            href={item.path}
                            onClick={() => setMobileMenuOpen(false)}
                            className={`
                            group flex items-center px-4 py-3.5 text-[16px] font-medium rounded-xl transition-all
                            ${isActive
                                ? 'bg-white text-[#e31837] shadow-xl'
                                : 'text-white/90 hover:bg-white/10'
                              }
                          `}
                          >
                            <span className={`mr-4 text-xl ${isActive ? 'text-[#e31837]' : 'text-white'}`}>{item.icon}</span>
                            {item.name}
                          </Link>
                        )
                      })}
                    </div>
                  </div>
                ))}
              </nav>

              <div className="p-6 border-t border-white/10 bg-black/10">
                <button
                  onClick={handleLogout}
                  className="w-full py-4 text-[14px] font-medium uppercase tracking-widest text-[#e31837] bg-white rounded-2xl shadow-xl shadow-red-900/20 active:scale-95 transition-all"
                >
                  Cerrar Sesión
                </button>
              </div>
            </div>
          </div>
        )
      }
    </>
  )
}
