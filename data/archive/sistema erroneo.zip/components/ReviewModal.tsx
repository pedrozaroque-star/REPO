'use client'

import { useState, useEffect } from 'react'
import { formatDateLA } from '@/lib/checklistPermissions'
import { supabase, getSupabaseClient, fetchWithAuth } from '@/lib/supabase'
import { config } from '@/lib/config'
import { INSPECTION_DICT } from '@/lib/inspectionQuestions'
import { MANAGER_CHECKLIST_SECTIONS } from '@/lib/managerChecklistQuestions'
import { ASSISTANT_DICT } from '@/lib/assistantChecklistQuestions'

interface ReviewModalProps {
  isOpen: boolean
  onClose: () => void
  checklists: any[]
  checklistType: 'assistant' | 'manager' | 'supervisor'
  currentUser: { id: number, name: string, email: string, role: string }
  onSave: () => void
}

export default function ReviewModal({ isOpen, onClose, checklists, checklistType, currentUser, onSave }: ReviewModalProps) {
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [reviewStatus, setReviewStatus] = useState('')
  const [reviewComment, setReviewComment] = useState('')
  const [saving, setSaving] = useState(false)

  // FILTERED LIST: Hide 'aprobado'/'cerrado' (User Request)
  const displayList = checklists.filter(item => {
    const role = currentUser.role.toLowerCase()
    let status = 'pendiente'

    if (checklistType === 'assistant') {
      if (role === 'manager' || role === 'gerente') status = item.estatus_manager
      else if (role === 'supervisor') status = item.estatus_supervisor
      else if (role === 'admin') status = item.estatus_manager // Admin overrides manager status often
    } else if (checklistType === 'manager') {
      // ADMINS: Check 'estatus_admin' (Audit Status), otherwise 'estatus_supervisor'
      if (role === 'admin') status = item.estatus_admin
      else status = item.estatus_supervisor
    } else if (checklistType === 'supervisor') {
      status = item.estatus_admin
    }

    // Normalize
    status = (status || 'pendiente').toLowerCase()

    // Show only: pendiente, rechazado, observado, corregir
    // Hide: aprobado, cerrado
    return status !== 'aprobado' && status !== 'cerrado'
  })
  const currentItem = checklists.find(c => c.id === selectedId)

  useEffect(() => {
    if (isOpen && displayList.length > 0 && !selectedId) {
      setSelectedId(displayList[0].id)
    }
  }, [isOpen, displayList, selectedId])

  useEffect(() => {
    if (currentItem) {
      const role = currentUser.role.toLowerCase()
      let suffix = ''

      if (checklistType === 'assistant') {
        if (role === 'manager' || role === 'gerente') suffix = '_manager'
        else if (role === 'supervisor' || role === 'admin') suffix = '_supervisor'
      } else if (checklistType === 'manager') {
        if (role === 'supervisor') suffix = '_supervisor'
        else if (role === 'admin') suffix = '_admin'
      } else if (checklistType === 'supervisor') {
        if (role === 'admin') suffix = '_admin'
      }

      const statusField = `estatus${suffix}`
      const commentField = `comentarios${suffix}`

      if (suffix && currentItem[statusField] !== undefined) {
        setReviewStatus(currentItem[statusField] || 'pendiente')
        setReviewComment(currentItem[commentField] || '')
      }
    }
  }, [currentItem, currentUser.role, checklistType])

  const getImageUrl = (url: string) => {
    if (!url) return ''
    if (url.includes('drive.google.com')) {
      const idMatch = url.match(/\/d\/([a-zA-Z0-9_-]+)/) || url.match(/id=([a-zA-Z0-9_-]+)/)
      if (idMatch && idMatch[1]) {
        return `https://drive.google.com/thumbnail?id=${idMatch[1]}&sz=w800`
      }
    }
    return url
  }

  const handleSave = async () => {
    if (!currentItem) return
    setSaving(false)
    setSaving(true)
    try {
      const role = currentUser.role.toLowerCase()
      const tableName = checklistType === 'manager' ? 'manager_checklists'
        : checklistType === 'assistant' ? 'assistant_checklists'
          : 'supervisor_inspections'

      const updateData: any = {}
      let suffix = ''

      if (checklistType === 'assistant') {
        if (role === 'manager' || role === 'gerente') suffix = '_manager'
        else if (role === 'supervisor' || role === 'admin') suffix = '_supervisor'
      } else if (checklistType === 'manager') {
        if (role === 'supervisor') suffix = '_supervisor'
        else if (role === 'admin') suffix = '_admin'
      } else if (checklistType === 'supervisor') {
        if (role === 'admin') suffix = '_admin'
      }

      if (!suffix) {
        alert('Tu rol no tiene permisos para revisar este tipo de checklist')
        setSaving(false)
        return
      }

      updateData[`estatus${suffix}`] = reviewStatus
      updateData[`comentarios${suffix}`] = reviewComment
      updateData[`reviso${suffix}`] = currentUser.name || currentUser.email
      updateData[`fecha_revision${suffix}`] = new Date().toISOString()

      console.group('🚀 Intentando guardar revisión (fetchWithAuth)')
      // Log Removed
      // Log Removed
      // Log Removed
      console.groupEnd()

      const url = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/${tableName}?id=eq.${currentItem.id}`
      const response = await fetchWithAuth(url, {
        method: 'PATCH',
        body: JSON.stringify(updateData),
        headers: {
          'Prefer': 'return=minimal'
        }
      })

      if (!response.ok) {
        const errorBody = await response.text()
        console.error('❌ Error de Servidor:', response.status, errorBody)
        throw new Error(`[HTTP ${response.status}] ${errorBody || response.statusText}`)
      }

      onSave()
      setSaving(false)

      // Buscar siguiente pendiente para el MISMO nivel de revisión
      const nextItem = displayList.find((c: any) =>
        c.id !== currentItem.id && c[`estatus${suffix}`] === 'pendiente'
      )

      if (nextItem) setSelectedId(nextItem.id)
      else onClose()
    } catch (err: any) {
      console.error('🔴 ERROR FATAL EN SAVEREVIEW:', err)
      let detailedMsg = ''
      if (err instanceof Error) {
        detailedMsg = `${err.name}: ${err.message}`
      } else {
        detailedMsg = JSON.stringify(err)
      }

      alert(`[ERROR-DEBUG-V4] No se pudo guardar: ${detailedMsg}`)
      setSaving(false)
    }
  }

  const renderDetails = (item: any) => {
    if (checklistType === 'manager') {
      let answersData = item.answers
      if (typeof answersData === 'string') {
        try { answersData = JSON.parse(answersData) } catch { answersData = {} }
      }
      if (!answersData) answersData = {}

      return MANAGER_CHECKLIST_SECTIONS.map((section, sIdx) => {
        // Calcular score de la sección
        const totalItems = section.items.length
        let answeredYes = 0

        const renderedItems = section.items.map((label: string, qIdx: number) => {
          const key = `s${sIdx}_${qIdx}`
          const val = answersData[key]
          if (val === 'SI') answeredYes++

          return { label, val }
        })

        const sectionScore = totalItems > 0 ? Math.round((answeredYes / totalItems) * 100) : 0

        return (
          <div key={sIdx} className="mb-6 bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="px-5 py-3 flex justify-between items-center bg-gray-50/80 border-b border-gray-100">
              <h4 className="text-sm font-bold text-gray-800 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#1a1a1a]"></span>
                {section.title}
              </h4>
              <span className={`px-4 py-1.5 rounded-full bg-white border border-gray-100 text-sm font-bold shadow-sm ${sectionScore >= 90 ? 'text-emerald-600' : 'text-[#e31837]'
                }`}>
                {sectionScore}%
              </span>
            </div>
            <div className="p-2 space-y-1">
              {renderedItems.map((q: any, i: number) => (
                <div key={i} className="px-5 py-3 flex justify-between items-center hover:bg-white/40 rounded-xl transition-colors">
                  <span className="text-sm text-gray-700 font-medium leading-tight line-clamp-2 pr-4">{q.label}</span>
                  <span className={`font-bold text-xs px-2.5 py-1 rounded-full ${q.val === 'SI' ? 'bg-emerald-50 text-emerald-700' :
                    q.val === 'NO' ? 'bg-red-50 text-red-700' :
                      'bg-gray-100 text-gray-400'
                    }`}>
                    {q.val === 'SI' ? 'CUMPLE' : q.val === 'NO' ? 'FALLA' : 'N/A'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )
      })
    }

    // CASO ESPECIAL: CHECKLIST DE ASISTENTE
    if (checklistType === 'assistant') {
      const type = item.checklist_type || 'unknown'
      const questions = ASSISTANT_DICT[type] || []
      let answersData = item.answers
      if (typeof answersData === 'string') {
        try { answersData = JSON.parse(answersData) } catch { answersData = {} }
      }
      if (!answersData) answersData = {}

      // Renderizado especial para Temperaturas
      if (type === 'temperaturas') {
        return (
          <div className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm">
            <div className="px-5 py-3 bg-gray-50/80 border-b border-gray-100">
              <h4 className="text-sm font-bold text-gray-800 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-500"></span>
                Registro de Temperaturas
              </h4>
            </div>
            <div className="p-2 space-y-1">
              {questions.map((tempItem: any) => {
                const val = answersData[tempItem.id]
                return (
                  <div key={tempItem.id} className="px-5 py-3 flex justify-between items-center hover:bg-white/40 rounded-xl transition-colors">
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-700 font-bold">{tempItem.label}</span>
                      <span className="text-xs text-gray-400 capitalize">{tempItem.type}</span>
                    </div>
                    <span className="font-bold text-base text-gray-900 bg-gray-50 px-4 py-1.5 rounded-lg border border-gray-100">
                      {val ? `${val}°F` : '--'}
                    </span>
                  </div>
                )
              })}
            </div>
          </div>
        )
      }

      // Renderizado especial para Sobrante
      if (type === 'sobrante') {
        return (
          <div className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm">
            <div className="px-5 py-3 bg-gray-50/80 border-b border-gray-100">
              <h4 className="text-sm font-bold text-gray-800 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                Registro de Sobrantes
              </h4>
            </div>
            <div className="p-2 space-y-1">
              {questions.map((prodItem: any) => {
                const val = answersData[prodItem.id]
                return (
                  <div key={prodItem.id} className="px-5 py-3 flex justify-between items-center hover:bg-white/40 rounded-xl transition-colors">
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-700 font-bold uppercase">{prodItem.label}</span>
                    </div>
                    <span className="font-bold text-base text-gray-900 bg-gray-50 px-4 py-1.5 rounded-lg border border-gray-100">
                      {val ? `${val} Lbs` : '--'}
                    </span>
                  </div>
                )
              })}
            </div>
          </div>
        )
      }

      // Renderizado para Apertura / Cierre / etc.
      // Si tenemos preguntas definidas
      if (Array.isArray(questions) && questions.length > 0) {
        let answeredYes = 0
        const renderedItems = questions.map((label: string, idx: number) => {
          const val = answersData[idx]
          if (val === 'SI') answeredYes++
          return { label, val }
        })

        return (
          <div className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm">
            <div className="px-5 py-3 flex justify-between items-center bg-gray-50/80 border-b border-gray-100">
              <h4 className="text-sm font-bold text-gray-800 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#e31837]"></span>
                Lista de Verificación ({type.charAt(0).toUpperCase() + type.slice(1)})
              </h4>
            </div>
            <div className="p-2 space-y-1">
              {renderedItems.map((q: any, i: number) => (
                <div key={i} className="px-5 py-3 flex justify-between items-center hover:bg-white/40 rounded-xl transition-colors">
                  <span className="text-sm text-gray-700 font-medium leading-tight line-clamp-2 pr-4">{q.label}</span>
                  <span className={`font-bold text-xs px-2.5 py-1 rounded-full ${q.val === 'SI' ? 'bg-emerald-50 text-emerald-700' :
                    q.val === 'NO' ? 'bg-red-50 text-red-700' :
                      'bg-gray-100 text-gray-400'
                    }`}>
                    {q.val === 'SI' ? 'CUMPLE' : q.val === 'NO' ? 'FALLA' : 'N/A'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )
      }

      // Fallback si no tenemos preguntas definidas (Daily, etc)
      return (
        <div className="p-4 text-center border-2 border-dashed border-gray-100 rounded-2xl">
          <p className="text-gray-400 text-sm">Vista detallada no disponible para tipo: {type}</p>
        </div>
      )
    }

    let answersData = item.answers
    if (typeof answersData === 'string') {
      try { answersData = JSON.parse(answersData) } catch { answersData = {} }
    }
    if (!answersData) answersData = {}

    return Object.entries(INSPECTION_DICT).map(([areaKey, dictInfo]: [string, any]) => {
      const areaData = answersData[areaKey] || {}
      const areaScore = areaData.score !== undefined ? areaData.score : (item[`${areaKey}_score`] ?? 0)

      let renderedItems: any[] = []
      if (areaData.items && !Array.isArray(areaData.items)) {
        renderedItems = Object.values(areaData.items).map((subItem: any) => ({
          label: subItem.label, score: subItem.score, status: 'recorded'
        }))
      } else if (Object.keys(areaData).some(k => !isNaN(parseInt(k)))) {
        renderedItems = dictInfo.items.map((label: string, index: number) => {
          const val = areaData[index.toString()]
          return { label: label, score: val, status: val !== undefined ? 'recorded' : 'missing' }
        })
      } else {
        renderedItems = dictInfo.items.map((label: string) => ({ label: label, score: null, status: 'legacy' }))
      }

      return (
        <div key={areaKey} className="mb-6 bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
          <div className="px-5 py-3 flex justify-between items-center bg-gray-50/80 border-b border-gray-100">
            <h4 className="text-sm font-bold text-gray-800 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#e31837]"></span>
              {dictInfo.label}
            </h4>
            <span className="px-4 py-1.5 rounded-full bg-white border border-gray-100 text-gray-700 text-sm font-bold shadow-sm">
              {areaScore}%
            </span>
          </div>
          <div className="p-2 space-y-1">
            {renderedItems.map((q: any, i: number) => {
              let badge = null
              if (q.status === 'legacy') badge = <span className="text-gray-400 text-[10px] italic">Legacy</span>
              else if (q.status === 'missing') badge = <span className="text-gray-300 text-[10px]">N/A</span>
              else badge = (
                <span className={`font-bold text-xs px-2.5 py-1 rounded-full ${q.score === 100 ? 'bg-green-100 text-green-700' :
                  q.score === 60 ? 'bg-yellow-100 text-yellow-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                  {q.score === 100 ? 'SÍ' : q.score === 60 ? 'PARCIAL' : 'NO'}
                </span>
              )
              return (
                <div key={i} className="px-5 py-3 flex justify-between items-center hover:bg-white/40 rounded-xl transition-colors">
                  <span className="text-sm text-gray-700 font-medium leading-tight line-clamp-2 pr-4">{q.label}</span>
                  {badge}
                </div>
              )
            })}
          </div>
        </div>
      )
    })
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-in fade-in duration-300">
      <div className="glass-effect w-full max-w-[1450px] h-[90vh] rounded-[2rem] shadow-2xl border border-white/30 flex overflow-hidden relative">

        {/* COLUMNA IZQUIERDA: LISTA MEJORADA */}
        {/* COLUMNA IZQUIERDA: LISTA MEJORADA - TEMA OSCURO */}
        <div className="w-[350px] bg-[#1a1a1a] flex flex-col relative z-20 flex-shrink-0">
          <div className="p-6 border-b border-gray-800">
            <h3 className="text-2xl font-bold text-white flex items-center gap-2">
              <span className="bg-[#e31837] p-2 rounded-lg text-lg">📋</span>
              Revisiones
            </h3>
            <p className="text-gray-400 text-sm font-medium mt-1">{displayList.length} pendientes</p>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
            {displayList.length === 0 ? (
              <div className="text-center py-20 text-gray-500 italic text-sm">No hay registros pendientes.</div>
            ) : (
              displayList.map((item: any) => {
                const isSelected = selectedId === item.id
                const role = currentUser.role.toLowerCase()
                // const status = role === 'admin' ? (item.estatus_admin || 'pendiente') : (item.estatus_supervisor || 'pendiente')

                return (
                  <button
                    key={item.id}
                    onClick={() => setSelectedId(item.id)}
                    className={`w-full text-left p-4 rounded-xl border transition-all duration-200 relative group overflow-hidden ${isSelected
                      ? 'bg-[#e31837] border-[#e31837] shadow-lg z-10'
                      : 'bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/10 text-gray-300 hover:z-10'
                      }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className={`font-bold text-base truncate pr-2 ${isSelected ? 'text-white' : 'text-gray-200'}`}>
                        {item.store_name}
                      </span>
                      <span className={`text-[13px] font-black px-2.5 py-1 rounded-full ${isSelected
                        ? 'bg-white/20 text-white'
                        : (item.overall_score || item.score) >= 90 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                        {item.overall_score || item.score || 0}%
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className={`text-sm font-medium ${isSelected ? 'text-white/80' : 'text-gray-500'}`}>
                        {item.supervisor_name?.split(' ')[0] || item.manager_name?.split(' ')[0] || item.users?.full_name?.split(' ')[0] || 'Usuario'}
                      </span>
                      {item.checklist_type && (
                        <div className="flex items-center gap-1.5 bg-white/5 px-2 py-1 rounded-lg">
                          <span className="text-xs">
                            {item.checklist_type === 'apertura' ? '🌅' :
                              item.checklist_type === 'cierre' ? '🌙' :
                                item.checklist_type === 'daily' ? '📝' :
                                  item.checklist_type === 'sobrante' ? '📦' :
                                    item.checklist_type === 'recorrido' ? '🚶' :
                                      item.checklist_type === 'temperaturas' ? '🌡️' : '📋'}
                          </span>
                          <span className={`text-[10px] font-bold uppercase tracking-wider ${isSelected ? 'text-white' : 'text-gray-400'}`}>
                            {item.checklist_type}
                          </span>
                        </div>
                      )}
                    </div>
                  </button>
                )
              })
            )}
          </div>
        </div>

        {/* COLUMNA DERECHA: DETALLE PREMIUM */}
        <div className="flex-1 flex flex-col bg-white overflow-hidden rounded-r-[2rem] relative z-10">
          {currentItem ? (
            <>
              {/* Header Detalle */}
              <div className="p-8 border-b border-gray-100 bg-white flex justify-between items-center">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-gray-100 text-gray-600 text-xs font-bold px-3 py-1 rounded-full tracking-wide">
                      {checklistType === 'manager' ? 'Checklist Manager' : checklistType === 'assistant' ? 'Checklist Asistente' : 'Inspección Supervisor'}
                    </span>
                  </div>
                  <h2 className="text-4xl font-bold text-gray-900 tracking-tight">{currentItem.store_name}</h2>
                  <div className="flex items-center gap-6 mt-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#fae8eb] flex items-center justify-center text-base font-bold text-[#e31837]">
                        {(currentItem.supervisor_name || currentItem.manager_name || currentItem.users?.full_name || 'U')[0]}
                      </div>
                      <span className="text-base font-semibold text-gray-600">
                        {currentItem.supervisor_name || currentItem.manager_name || currentItem.users?.full_name || 'Desconocido'}
                      </span>
                    </div>
                    <div className="h-4 w-[1px] bg-gray-200"></div>
                    <div className="flex items-center gap-1 text-base text-gray-500">
                      <span className="opacity-50 text-lg">📅</span>
                      <span className="font-bold">{formatDateLA(currentItem.inspection_date || currentItem.checklist_date)}</span>
                    </div>
                    <div className="h-4 w-[1px] bg-gray-200"></div>
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">Inicio</span>
                      <div className="flex items-center gap-1 text-sm text-gray-600 font-black">
                        <span className="opacity-50 text-base">⏰</span>
                        <span>{currentItem.start_time || currentItem.inspection_time || '--:--'}</span>
                      </div>
                    </div>

                    {(currentItem.created_at) && (
                      <>
                        <div className="h-4 w-[1px] bg-gray-200"></div>
                        <div className="flex flex-col gap-0.5">
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">Final</span>
                          <div className="flex items-center gap-1 text-sm text-gray-600 font-bold">
                            <span className="opacity-50 text-base">🏁</span>
                            <span>{new Date(currentItem.created_at).toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', timeZone: 'America/Los_Angeles' })}</span>
                          </div>
                        </div>

                        <div className="h-4 w-[1px] bg-gray-200"></div>
                        <div className="flex flex-col gap-0.5">
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">Duración</span>
                          <div className="flex items-center gap-1 text-sm text-emerald-600 font-bold">
                            <span className="opacity-50 text-base">⏳</span>
                            <span>
                              {(() => {
                                try {
                                  const start = currentItem.start_time;
                                  if (!start) return '--';
                                  const [h, m] = start.split(':').map(Number);
                                  const startDate = new Date(currentItem.created_at);
                                  startDate.setHours(h, m, 0);
                                  const endDate = new Date(currentItem.created_at);
                                  const diffMs = endDate.getTime() - startDate.getTime();
                                  const diffMin = Math.round(diffMs / 60000);
                                  return diffMin > 0 ? `${diffMin} min` : '< 1 min';
                                } catch { return '--' }
                              })()}
                            </span>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                <div className="flex flex-col items-center">
                  <div className="relative group">
                    <svg className="w-20 h-20 transform -rotate-90">
                      <circle cx="40" cy="40" r="36" stroke="currentColor" strokeWidth="6" fill="transparent" className="text-gray-100" />
                      <circle cx="40" cy="40" r="36" stroke="currentColor" strokeWidth="6" fill="transparent"
                        strokeDasharray={226.2}
                        strokeDashoffset={226.2 - (226.2 * (currentItem.overall_score || currentItem.score || 0)) / 100}
                        className={`${(currentItem.overall_score || currentItem.score) >= 90 ? 'text-emerald-500' : 'text-amber-500'} transition-all duration-1000 ease-out`}
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-2xl font-black text-gray-900">{(currentItem.overall_score || currentItem.score)}%</span>
                      <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Score</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contenido Principal */}
              <div className="flex-1 overflow-y-auto p-8 bg-gray-50/50 custom-scrollbar">
                <div className="max-w-4xl mx-auto space-y-10">

                  {/* Secciones de Preguntas */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div>
                      <h3 className="text-sm font-bold text-gray-400 tracking-wider mb-5 pl-1 uppercase">Resultados Detallados</h3>
                      {renderDetails(currentItem)}
                    </div>

                    <div className="space-y-10">
                      {/* Fotos */}
                      <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm">
                        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-5">Evidencias Fotográficas</h3>
                        {currentItem.photos && currentItem.photos.length > 0 ? (
                          <div className="grid grid-cols-2 gap-4">
                            {currentItem.photos.map((url: string, i: number) => (
                              <a key={i} href={url} target="_blank" rel="noopener noreferrer" className="aspect-square rounded-2xl overflow-hidden border-2 border-gray-50 shadow-sm hover:scale-[1.02] transition-transform group relative">
                                <img src={getImageUrl(url)} className="w-full h-full object-cover" alt="Evidencia" referrerPolicy="no-referrer" />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                  <span className="text-white text-sm font-bold">Ver original ↗</span>
                                </div>
                              </a>
                            ))}
                          </div>
                        ) : (
                          <div className="py-14 text-center border-2 border-dashed border-gray-100 rounded-2xl">
                            <span className="text-4xl grayscale mb-3 block opacity-30">📷</span>
                            <p className="text-sm font-medium text-gray-400">No hay evidencias adjuntas</p>
                          </div>
                        )}
                      </div>

                      {/* Observaciones */}
                      <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm">
                        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-5">Observaciones de Campo</h3>
                        <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 text-base text-gray-700 leading-relaxed italic">
                          {currentItem.observaciones || currentItem.comments || "Sin comentarios registrados."}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Panel de Decisión Gerencial (Pegajoso) */}
                  {/* Panel de Decisión (SOLO VISIBLE SI ES EL REVISOR CORRESPONDIENTE) */}
                  {/* REGLA: 
                      - Admin revisa Supervisor (Inspecciones)
                      - Supervisor revisa Manager (Checklists Manager)
                      - Manager revisa Asistente (Checklists Asistente)
                  */}

                  {/* CASO 1: MODO AUDITORÍA (Cuando Admin ve Manager/Assistant O Supervisor ve Assistant) */}
                  {((checklistType === 'manager' && currentUser.role.toLowerCase() === 'admin') ||
                    (checklistType === 'assistant' && (currentUser.role.toLowerCase() === 'admin' || currentUser.role.toLowerCase() === 'supervisor'))) && (
                      <div className="sticky bottom-0 bg-white/95 backdrop-blur-md rounded-3xl p-8 border border-gray-100 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.1)] space-y-4 z-10">

                        {/* HEADER DEL PANEL */}
                        <div className="flex items-center gap-3 mb-2">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center border shadow-sm ${reviewStatus === 'pendiente' ? 'bg-amber-50 border-amber-200 text-amber-600' :
                            'bg-slate-900 border-slate-900 text-white'
                            }`}>
                            <span className="text-xl">{reviewStatus === 'pendiente' ? '🔔' : '🛡️'}</span>
                          </div>
                          <div>
                            <h3 className="text-2xl font-bold text-gray-900 tracking-tight">
                              {reviewStatus === 'pendiente' ? `Notificar al ${checklistType === 'assistant' ? 'Asistente' : checklistType === 'manager' ? 'Manager' : 'Supervisor'}` : 'Validación de Auditoría'}
                            </h3>
                            <p className="text-base text-gray-500 font-medium">
                              {reviewStatus === 'pendiente' ? `El ${checklistType === 'assistant' ? 'asistente' : checklistType === 'manager' ? 'manager' : 'supervisor'} aún no ha revisado este registro` : `Validar la decisión tomada por el ${checklistType === 'assistant' ? 'asistente' : checklistType === 'manager' ? 'manager' : 'supervisor'}`}
                            </p>
                          </div>
                        </div>

                        {/* Lógica de Bloqueo: Bloquear SOLO si el nivel anterior no ha terminado */}
                        {(() => {
                          const role = currentUser.role.toLowerCase()
                          let isBlocked = false
                          let previousRole = ''

                          // 1. Admin revisando Manager Checklist -> Depende de Supervisor
                          if (checklistType === 'manager' && role === 'admin') {
                            const prevStatus = currentItem.estatus_supervisor || 'pendiente'
                            isBlocked = prevStatus !== 'aprobado' && prevStatus !== 'cerrado'
                            previousRole = 'Supervisor'
                          }
                          // 2. Supervisor/Admin revisando Assistant Checklist -> Depende de Manager
                          else if (checklistType === 'assistant' && (role === 'supervisor' || role === 'admin')) {
                            const prevStatus = currentItem.estatus_manager || 'pendiente'
                            isBlocked = prevStatus !== 'aprobado' && prevStatus !== 'cerrado'
                            previousRole = 'Manager'
                          }

                          // Si está bloqueado, mostramos la alerta (Escenario A)
                          // Si NO está bloqueado, mostramos el panel de decisión (Escenario B)
                          if (isBlocked) {
                            return (
                              <div className="space-y-6">
                                <div className="bg-amber-50 border border-amber-100 rounded-xl p-5 flex gap-4">
                                  <span className="text-amber-500 text-2xl">⚠️</span>
                                  <p className="text-base font-medium text-amber-700 leading-relaxed">
                                    Este registro está <strong className="font-bold underline">PENDIENTE</strong> de revisión por parte del {previousRole}.
                                    <br />Como {role === 'admin' ? 'Administrador' : 'Supervisor'}, no puedes aprobarlo directamente hasta que sea validado por el nivel anterior.
                                  </p>
                                </div>

                                <div>
                                  <label className="block text-sm font-bold text-gray-500 mb-3 ml-1 uppercase tracking-wider">Enviar Recordatorio al {previousRole}</label>
                                  <div className="relative">
                                    <textarea
                                      value={reviewComment}
                                      onChange={(e) => setReviewComment(e.target.value)}
                                      placeholder={`Mensaje para el ${previousRole}...`}
                                      className="w-full h-32 px-5 py-4 bg-white border border-gray-200 rounded-2xl text-lg font-medium text-gray-900 focus:ring-4 focus:ring-[#e31837]/5 outline-none transition-all resize-none shadow-sm"
                                    />
                                  </div>
                                </div>

                                <button
                                  onClick={handleSave}
                                  disabled={saving || !reviewComment.trim()}
                                  className="w-full h-16 bg-gray-900 hover:bg-black text-white rounded-2xl font-bold text-xl shadow-xl transform active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                  {saving ? (
                                    <div className="w-8 h-8 border-4 border-white/30 border-t-white rounded-full animate-spin" />
                                  ) : (
                                    <>
                                      <span className="text-2xl">🔔</span>
                                      <span>Enviar Observación Urgente</span>
                                    </>
                                  )}
                                </button>
                              </div>
                            )
                          } else {
                            return (
                              /* ESCENARIO B: COMPLETADO -> ADMIN PUEDE AUDITAR (APROBAR/RECHAZAR SOBRE LO HECHO) */
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                <div className="md:col-span-1">
                                  <label className="block text-sm font-bold text-gray-500 mb-3 ml-1 uppercase tracking-wider">Decisión de Auditoría</label>
                                  <select
                                    value={reviewStatus}
                                    onChange={(e) => setReviewStatus(e.target.value)}
                                    className="w-full h-16 px-5 bg-gray-50 border border-gray-200 rounded-2xl font-bold text-lg text-gray-900 focus:ring-4 focus:ring-[#e31837]/5 outline-none transition-all cursor-pointer shadow-sm"
                                  >
                                    <option value="cerrado">✅ Validar Auditoría</option>
                                    <option value="rechazado">❌ Rechazar / Corregir</option>
                                  </select>
                                </div>

                                <div className="md:col-span-2">
                                  <label className="block text-sm font-bold text-gray-500 mb-3 ml-1 uppercase tracking-wider">Observaciones de Auditoría</label>
                                  <div className="relative">
                                    <textarea
                                      value={reviewComment}
                                      onChange={(e) => setReviewComment(e.target.value)}
                                      placeholder={`Comentarios finales sobre la gestión del ${checklistType === 'assistant' ? 'asistente' : checklistType === 'manager' ? 'manager' : 'supervisor'}...`}
                                      className="w-full h-16 px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-lg font-medium text-gray-900 focus:ring-4 focus:ring-[#e31837]/5 outline-none transition-all resize-none shadow-sm"
                                    />
                                  </div>
                                </div>

                                <div className="md:col-span-3">
                                  <button
                                    onClick={handleSave}
                                    disabled={saving}
                                    className="w-full h-16 bg-[#e31837] hover:bg-[#c41530] text-white font-bold text-xl rounded-2xl shadow-xl shadow-[#e31837]/20 transform active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed"
                                  >
                                    {saving ? (
                                      <div className="w-8 h-8 border-4 border-white/30 border-t-white rounded-full animate-spin" />
                                    ) : (
                                      <>
                                        <span className="text-2xl">💾</span>
                                        <span>Guardar Validación de Auditoría</span>
                                      </>
                                    )}
                                  </button>
                                </div>
                              </div>
                            )
                          }
                        })()}
                      </div>
                    )}

                  {/* CASO 2: MODO REVISIÓN (ACTIVO) */}
                  {!((checklistType === 'manager' && currentUser.role.toLowerCase() === 'admin') ||
                    (checklistType === 'assistant' && currentUser.role.toLowerCase() === 'admin')) && (
                      <div className="sticky bottom-0 bg-white/95 backdrop-blur-md rounded-3xl p-8 border border-gray-100 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.1)] space-y-8 z-10">
                        <div className="flex items-center gap-4">
                          <div className="w-14 h-14 rounded-2xl bg-gray-900 flex items-center justify-center shadow-lg shadow-gray-200">
                            <span className="text-white text-3xl">🛡️</span>
                          </div>
                          <div>
                            <h3 className="text-2xl font-bold text-gray-900 tracking-tight">Decisión Administrativa</h3>
                            <p className="text-base text-gray-500 font-medium">Finalizar el proceso de revisión</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                          <div className="md:col-span-1">
                            <label className="block text-sm font-bold text-gray-500 mb-3 ml-1 uppercase tracking-wider">Estado Final</label>
                            <select
                              value={reviewStatus}
                              onChange={(e) => setReviewStatus(e.target.value)}
                              className="w-full h-16 px-5 bg-gray-50 border border-gray-200 rounded-2xl font-bold text-lg text-gray-900 focus:ring-4 focus:ring-[#e31837]/5 outline-none transition-all cursor-pointer shadow-sm"
                            >
                              <option value="pendiente">⏳ Quedar Pendiente</option>
                              <option value="cerrado">✅ Aprobar y Cerrar</option>
                              <option value="rechazado">❌ Rechazar / Corregir</option>
                            </select>
                          </div>

                          <div className="md:col-span-2">
                            <label className="block text-sm font-bold text-gray-500 mb-3 ml-1 uppercase tracking-wider">Comentarios / Feedback Detallado</label>
                            <div className="relative">
                              <textarea
                                value={reviewComment}
                                onChange={(e) => setReviewComment(e.target.value)}
                                placeholder={`Instrucciones o feedback para el ${checklistType === 'assistant' ? 'asistente' : checklistType === 'manager' ? 'manager' : 'supervisor'}...`}
                                className="w-full h-16 px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-lg font-medium text-gray-900 focus:ring-4 focus:ring-[#e31837]/5 outline-none transition-all resize-none shadow-sm"
                              />
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={handleSave}
                          disabled={saving}
                          className="w-full h-16 bg-[#e31837] hover:bg-[#c41530] text-white font-bold text-xl rounded-2xl shadow-2xl shadow-[#e31837]/30 transform active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed"
                        >
                          {saving ? (
                            <div className="w-8 h-8 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                          ) : (
                            <>
                              <span className="text-2xl">💾</span>
                              <span>Guardar Revisión Final</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}


                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-200">
              <div className="relative mb-6 opacity-30">
                <div className="w-24 h-24 bg-gray-100 rounded-full animate-pulse"></div>
              </div>
              <p className="text-lg font-bold text-gray-300">Selecciona de la lista</p>
            </div>
          )}
        </div>

        {/* Botón Cerrar X */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 w-12 h-12 glass-effect rounded-2xl flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-white hover:rotate-90 transition-all duration-500 z-[110] shadow-xl"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12"></path></svg>
        </button>
        <div className="absolute bottom-2 left-2 opacity-5 pointer-events-none">
          <span className="text-[10px] text-gray-400 font-mono">DEBUG_V4_{currentUser.role.toUpperCase()}</span>
        </div>
      </div>
    </div>
  )
}
