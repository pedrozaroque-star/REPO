'use client'

import { useState } from 'react'
import { formatDateLA } from '@/lib/checklistPermissions'
import { getQuestionText } from '@/lib/managerQuestions'
import { config } from '@/lib/config'

interface DetailsModalProps {
  isOpen: boolean
  onClose: () => void
  checklist: any
  type: 'manager' | 'assistant' | 'supervisor'
  userRole?: string
  userName?: string
  onReviewSubmit?: () => void
}

const ASSISTANT_QUESTIONS: { [key: string]: string[] } = {
  daily: [
    'Todo el equipo alcanza la temperatura adecuada',
    'Cubeta roja de sanitizante bajo línea @ 200ppm',
    'Máquina de hielo limpia',
    'Área del trapeador limpia',
    'Microondas está limpio',
    'Estaciones de champurrado limpias',
    'Baño de empleados limpio',
    'Tanque de gas de refrescos lleno',
    'Checklists siendo usados',
    'Food Handler visible',
    'Se saluda a clientes dentro de 5 segundos',
    'Hacemos contacto visual con el cliente',
    'Ventanas limpias',
    'Baños limpios',
    'Estacionamiento limpio',
    'TVs funcionando',
    'Toda la iluminación funciona',
    'Mesas y sillas limpias',
    'Todas las luces funcionan',
    'Acero inoxidable limpio',
    'Rebanadoras y tijeras limpias',
    'Drenajes limpios',
    'Pisos y zócalos limpios',
    'Lavado de manos frecuente',
    'Área de escoba organizada',
    'Se utiliza FIFO',
    'Trapos en sanitizante',
    'Expedidor anuncia órdenes',
    'Cámaras funcionando',
    'SOS/DT Time visible',
    'Management consciente',
    'Manejo de efectivo correcto',
    'Reparaciones reportadas',
    'AC limpio'
  ],
  apertura: [
    'Área de preparación limpia',
    'Equipo en temperatura correcta',
    'Walk-in organizado',
    'Estaciones de trabajo limpias'
  ],
  temperaturas: [
    'Walk-in refrigerador',
    'Walk-in congelador',
    'Unidad de preparación',
    'Temperatura de carne',
    'Temperatura de pollo'
  ],
  sobrante: [
    'Carne sobrante etiquetada',
    'Pollo sobrante etiquetado',
    'Verduras etiquetadas',
    'Fecha de caducidad visible'
  ],
  cierre: [
    'Parrillas limpias',
    'Pisos trapeados',
    'Basura retirada',
    'Equipo apagado'
  ],
  recorrido: [
    'Comedor limpio',
    'Baños en orden',
    'Estacionamiento limpio',
    'Área exterior presentable'
  ]
}

export default function DetailsModal({
  isOpen,
  onClose,
  checklist,
  type,
  userRole,
  userName,
  onReviewSubmit
}: DetailsModalProps) {
  const [activeTab, setActiveTab] = useState<'answers' | 'photos' | 'reviews'>('answers')
  const [reviewAction, setReviewAction] = useState<'aprobar' | 'rechazar' | 'corregir' | null>(null)
  const [reviewComments, setReviewComments] = useState('')
  const [submitting, setSubmitting] = useState(false)

  if (!isOpen) return null

  // Determinar nivel de revisión según rol y tipo
  const getReviewLevel = () => {
    if (!userRole) return null
    if (type === 'assistant') {
      if (userRole === 'manager' || userRole === 'gerente') return 'manager'
      if (userRole === 'supervisor') return 'supervisor'
      if (userRole === 'admin') return 'admin'
    }
    if (type === 'manager') {
      if (userRole === 'supervisor') return 'supervisor'
      if (userRole === 'admin') return 'admin'
    }
    if (type === 'supervisor') {
      if (userRole === 'admin') return 'admin'
    }
    return null
  }

  const reviewLevel = getReviewLevel()
  const canReview = reviewLevel && checklist[`estatus_${reviewLevel}`] === 'pendiente'

  // Parsear respuestas
  const parseAnswers = () => {
    try {
      if (type === 'manager' || type === 'supervisor') {
        return checklist.answers || {}
      }

      const answers = typeof checklist.answers === 'string'
        ? JSON.parse(checklist.answers)
        : checklist.answers || {}

      return answers
    } catch {
      return {}
    }
  }

  const answers = parseAnswers()

  // Organizar respuestas en secciones
  const sections: { title: string; questions: { text: string; value: string }[] }[] = []

  if (type === 'assistant') {
    const checklistType = checklist.checklist_type || 'daily'
    const questions = ASSISTANT_QUESTIONS[checklistType] || []

    if (questions.length > 0) {
      const sectionQuestions = questions.map((q, idx) => ({
        text: q,
        value: answers[`q${idx}`] || answers[`${checklistType}_${idx}`] || 'N/A'
      }))

      sections.push({
        title: checklistType.toUpperCase(),
        questions: sectionQuestions
      })
    }
  } else if (type === 'manager') {
    Object.entries(answers).forEach(([key, value]) => {
      if (key.startsWith('s')) {
        const parts = key.split('_')
        const sectionIdx = parseInt(parts[0].replace('s', ''))
        const questionIdx = parseInt(parts[1])

        if (!sections[sectionIdx]) {
          sections[sectionIdx] = { title: `Sección ${sectionIdx + 1}`, questions: [] }
        }

        const questionText = getQuestionText(`s${sectionIdx}_${questionIdx}`)
        const answerValue = typeof value === 'object' && value !== null ? (value as any).value : value

        sections[sectionIdx].questions.push({
          text: questionText,
          value: answerValue || 'N/A'
        })
      }
    })
  } else if (type === 'supervisor') {
    const { INSPECTION_DICT } = require('@/lib/inspectionQuestions')

    Object.entries(INSPECTION_DICT).forEach(([areaKey, dictInfo]: [string, any]) => {
      const areaData = answers[areaKey] || {}
      const areaScore = areaData.score !== undefined ? areaData.score : (checklist[`${areaKey}_score`] ?? 0)

      let renderedItems: any[] = []
      if (areaData.items && !Array.isArray(areaData.items)) {
        renderedItems = Object.values(areaData.items).map((subItem: any) => ({
          text: subItem.label, value: subItem.score === 100 ? 'SI' : subItem.score === 60 ? 'PARCIAL' : 'NO'
        }))
      } else if (Object.keys(areaData).some(k => !isNaN(parseInt(k)))) {
        renderedItems = dictInfo.items.map((label: string, index: number) => {
          const val = areaData[index.toString()]
          return { text: label, value: val === 100 ? 'SI' : val === 60 ? 'PARCIAL' : val === undefined ? 'N/A' : 'NO' }
        })
      } else {
        renderedItems = dictInfo.items.map((label: string) => ({ text: label, value: 'Legacy' }))
      }

      sections.push({
        title: `${dictInfo.label} (${areaScore}%)`,
        questions: renderedItems
      })
    })
  }

  const photoUrls = checklist.photo_urls || []
  const reviewLevels = type === 'assistant'
    ? ['manager', 'supervisor', 'admin']
    : type === 'manager'
      ? ['supervisor', 'admin']
      : ['admin']

  const getAnswerBadge = (value: string) => {
    if (value === 'SI' || value === 'SÍ') return 'bg-green-100 text-green-800'
    if (value === 'NO') return 'bg-red-100 text-red-800'
    if (value === 'N/A') return 'bg-gray-100 text-gray-600'
    if (value === 'PARCIAL') return 'bg-yellow-100 text-yellow-800'
    return 'bg-blue-100 text-blue-800'
  }

  // Manejar envío de revisión
  const handleReviewSubmit = async () => {
    if (!reviewAction || !reviewLevel) return

    setSubmitting(true)

    try {
      const url = config.supabase.url
      const key = config.supabase.anonKey

      const tableName = type === 'assistant'
        ? 'assistant_checklists'
        : type === 'manager'
          ? 'manager_checklists'
          : 'supervisor_inspections'

      const statusMap = {
        'aprobar': 'aprobado',
        'rechazar': 'rechazado',
        'corregir': 'corregir'
      }

      const payload = {
        [`estatus_${reviewLevel}`]: statusMap[reviewAction],
        [`reviso_${reviewLevel}`]: userName,
        [`comentarios_${reviewLevel}`]: reviewComments || null,
        [`fecha_revision_${reviewLevel}`]: new Date().toISOString()
      }

      const res = await fetch(`${url}/rest/v1/${tableName}?id=eq.${checklist.id}`, {
        method: 'PATCH',
        headers: {
          'apikey': key || '',
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify(payload)
      })

      if (res.ok) {
        alert('✅ Revisión guardada exitosamente')
        if (onReviewSubmit) onReviewSubmit()
        onClose()
      } else {
        alert('❌ Error al guardar la revisión')
      }
    } catch (error) {
      console.error('Error:', error)
      alert('❌ Error al guardar la revisión')
    } finally {
      setSubmitting(false)
    }
  }

  const getImageUrl = (url: string) => {
    if (!url) return ''
    if (url.includes('drive.google.com')) {
      const idMatch = url.match(/\/d\/([a-zA-Z0-9_-]+)/) || url.match(/id=([a-zA-Z0-9_-]+)/)
      if (idMatch && idMatch[1]) {
        return `https://drive.google.com/thumbnail?id=${idMatch[1]}&sz=w800`
      }
    }
    return url
  }

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="bg-white/95 backdrop-blur-2xl rounded-[2.5rem] shadow-2xl max-w-7xl w-full max-h-[95vh] flex flex-col border border-white/20 overflow-hidden">

        {/* Header */}
        <div className="p-8 border-b border-gray-100 flex-shrink-0 bg-gradient-to-r from-indigo-50/50 to-purple-50/50">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-4xl font-black text-gray-900 tracking-tight">
                {type === 'assistant' ? `Checklist: ${checklist.checklist_type?.toUpperCase()}`
                  : type === 'manager' ? 'Manager Checklist'
                    : 'Inspección Supervisor'}
              </h2>
              <div className="flex flex-wrap items-center gap-8 mt-5 text-base text-gray-600 font-bold">
                <span className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm">📅 {formatDateLA(checklist.checklist_date || checklist.created_at)}</span>
                <span className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm">🏪 {checklist.store_name || 'N/A'}</span>
                <span className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm transition-transform hover:scale-105 cursor-default">👤 {checklist.assistant_name || checklist.manager_name || checklist.supervisor_name || 'N/A'}</span>
                <div className="flex items-center gap-3 bg-white px-5 py-2 rounded-full shadow-sm border-2 border-indigo-50">
                  <span className="text-gray-400 text-xs font-black uppercase tracking-widest">Score</span>
                  <span className={`text-2xl font-black ${checklist.score >= 90 ? 'text-green-600' : checklist.score >= 70 ? 'text-yellow-600' : 'text-red-600'}`}>
                    {checklist.score}%
                  </span>
                </div>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-12 h-12 flex items-center justify-center rounded-full bg-gray-100 text-gray-400 hover:bg-red-50 hover:text-red-500 transition-all text-2xl font-light shadow-inner"
            >
              ×
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-4 mt-10">
            {(['answers', 'photos', 'reviews'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-10 py-3 rounded-full font-black text-base transition-all duration-300 transform ${activeTab === tab
                  ? 'bg-indigo-600 text-white shadow-2xl shadow-indigo-200 -translate-y-1'
                  : 'bg-white/50 text-gray-500 hover:bg-white hover:text-gray-900 border border-gray-100 shadow-sm'
                  }`}>
                {tab === 'answers' ? '📋 Respuestas' : tab === 'photos' ? `📷 Fotos (${photoUrls.length})` : '👮‍♂️ Revisiones'}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-8 bg-gray-50/30">
          {activeTab === 'answers' && (
            <div className="space-y-6">
              {sections.length === 0 ? (
                <div className="text-center py-20 bg-white/50 rounded-3xl border border-dashed border-gray-200">
                  <div className="text-7xl mb-4 grayscale opacity-20">📋</div>
                  <p className="text-gray-400 font-medium">No se encontraron respuestas registradas</p>
                </div>
              ) : (
                sections.map((section, idx) => (
                  <div key={idx} className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden transition-all hover:shadow-xl hover:-translate-y-1">
                    <div className="bg-gradient-to-r from-gray-50/50 to-white px-10 py-5 border-b border-gray-100 flex justify-between items-center">
                      <h3 className="font-black text-gray-900 text-sm uppercase tracking-[0.2em]">{section.title}</h3>
                    </div>
                    <div className="divide-y divide-gray-50">
                      {section.questions.map((q, qIdx) => (
                        <div key={qIdx} className="px-10 py-6 flex items-start justify-between gap-12 hover:bg-gray-50/80 transition-colors">
                          <p className="text-lg font-bold text-gray-700 flex-1 leading-relaxed">{q.text}</p>
                          <span className={`px-6 py-2 rounded-full text-xs font-black tracking-widest flex-shrink-0 shadow-md border-2 transition-all hover:scale-110 ${getAnswerBadge(q.value)}`}>
                            {q.value || 'N/A'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))
              )}

              {checklist.comments && (
                <div className="bg-gradient-to-br from-indigo-600 to-purple-600 rounded-3xl p-10 text-white shadow-xl shadow-indigo-100">
                  <h4 className="font-black text-white/50 text-sm uppercase tracking-[0.2em] mb-4">Comentarios Adicionales</h4>
                  <p className="text-xl font-medium leading-relaxed italic">"{checklist.comments}"</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'photos' && (
            <div>
              {photoUrls.length === 0 ? (
                <div className="text-center py-20 bg-white/50 rounded-3xl border border-dashed border-gray-200">
                  <div className="text-7xl mb-4 grayscale opacity-20">📷</div>
                  <p className="text-gray-400 font-medium">No hay fotos en este checklist</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                  {photoUrls.map((url: string, idx: number) => (
                    <div key={idx} className="relative group aspect-square rounded-3xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-500">
                      <img
                        src={getImageUrl(url)}
                        alt={`Foto ${idx + 1}`}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                        onClick={() => window.open(url, '_blank')}
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-end p-6">
                        <span className="text-white font-bold text-sm tracking-tight">
                          Click para ampliar
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-6">
              {reviewLevels.map((level) => {
                const status = checklist[`estatus_${level}`]
                const reviewer = checklist[`reviso_${level}`]
                const comments = checklist[`comentarios_${level}`]
                const date = checklist[`fecha_revision_${level}`]

                const statusColors: { [key: string]: string } = {
                  'pendiente': 'bg-yellow-50 text-yellow-700 border-yellow-100',
                  'aprobado': 'bg-green-50 text-green-700 border-green-100',
                  'rechazado': 'bg-red-50 text-red-700 border-red-100',
                  'corregir': 'bg-orange-50 text-orange-700 border-orange-100',
                  'cerrado': 'bg-blue-50 text-blue-700 border-blue-100'
                }

                const levelNames: { [key: string]: string } = {
                  'manager': 'Manager',
                  'supervisor': 'Supervisor',
                  'admin': 'Admin'
                }

                return (
                  <div key={level} className="bg-white border border-gray-100 rounded-[2rem] p-10 shadow-sm transition-all hover:shadow-xl">
                    <div className="flex items-center justify-between mb-8">
                      <h4 className="font-black text-gray-900 text-2xl tracking-tight">Revisión de {levelNames[level]}</h4>
                      {status && (
                        <span className={`px-8 py-2.5 rounded-full text-xs font-black tracking-[0.2em] border-2 transition-all shadow-sm ${statusColors[status] || 'bg-gray-50 text-gray-800'}`}>
                          {status.toUpperCase()}
                        </span>
                      )}
                    </div>

                    {reviewer ? (
                      <div className="space-y-6">
                        <div className="grid grid-cols-2 gap-10">
                          <div className="bg-gray-50/80 p-6 rounded-2xl border border-gray-100 shadow-inner">
                            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Revisado por</p>
                            <p className="text-lg font-black text-gray-900">{reviewer}</p>
                          </div>
                          {date && (
                            <div className="bg-gray-50/80 p-6 rounded-2xl border border-gray-100 shadow-inner">
                              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Fecha</p>
                              <p className="text-lg font-black text-gray-900">{formatDateLA(date)}</p>
                            </div>
                          )}
                        </div>

                        {comments && (
                          <div className="bg-indigo-50/40 rounded-3xl p-8 border border-indigo-100 shadow-sm relative overflow-hidden">
                            <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500"></div>
                            <p className="text-xs font-black text-indigo-400 uppercase tracking-widest mb-3">Comentarios del Revisor</p>
                            <p className="text-base text-gray-800 font-bold leading-relaxed italic">"{comments}"</p>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="bg-gray-50/50 rounded-2xl p-10 text-center border-2 border-dashed border-gray-200">
                        <p className="text-lg text-gray-400 font-bold italic">Esperando validación de {levelNames[level]}...</p>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </div>

        {/* Footer con acciones de revisión */}
        <div className="border-t p-8 bg-white/80 backdrop-blur-md flex-shrink-0">
          {canReview ? (
            reviewAction ? (
              // Formulario de revisión
              <div className="space-y-6 w-full animate-in slide-in-from-bottom duration-300">
                <div>
                  <label className="block text-sm font-black text-gray-700 uppercase tracking-widest mb-3">
                    Notas de Revisión {reviewAction !== 'aprobar' && <span className="text-red-500 font-black">(REQUERIDO)</span>}
                  </label>
                  <textarea
                    value={reviewComments}
                    onChange={(e) => setReviewComments(e.target.value)}
                    className="w-full px-6 py-4 border border-gray-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all outline-none text-gray-700 font-medium min-h-[120px]"
                    placeholder="Escribe tus observaciones aquí..."
                  />
                </div>
                <div className="flex gap-4 justify-end">
                  <button
                    onClick={() => {
                      setReviewAction(null)
                      setReviewComments('')
                    }}
                    className="px-8 py-3 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-full font-bold transition-all"
                  >
                    Retroceder
                  </button>
                  <button
                    onClick={handleReviewSubmit}
                    disabled={submitting || (reviewAction !== 'aprobar' && !reviewComments)}
                    className="px-10 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full font-bold transition-all shadow-lg shadow-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed hover:-translate-y-0.5"
                  >
                    {submitting ? 'Procesando...' : 'Finalizar Revisión'}
                  </button>
                </div>
              </div>
            ) : (
              // Botones de acción
              <div className="flex flex-wrap gap-4 justify-end w-full">
                <button
                  onClick={onClose}
                  className="px-10 py-4 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-full font-black text-sm uppercase tracking-widest transition-all"
                >
                  Cerrar
                </button>
                <div className="flex gap-4">
                  <button
                    onClick={() => setReviewAction('rechazar')}
                    className="px-10 py-4 bg-red-50 hover:bg-red-100 text-red-600 rounded-full font-black text-sm uppercase tracking-widest transition-all border-2 border-red-100 shadow-sm"
                  >
                    ❌ Rechazar
                  </button>
                  <button
                    onClick={() => setReviewAction('corregir')}
                    className="px-10 py-4 bg-orange-50 hover:bg-orange-100 text-orange-600 rounded-full font-black text-sm uppercase tracking-widest transition-all border-2 border-orange-100 shadow-sm"
                  >
                    ⚠️ Corregir
                  </button>
                  <button
                    onClick={() => setReviewAction('aprobar')}
                    className="px-12 py-4 bg-gradient-to-r from-green-600 to-emerald-700 hover:from-green-700 hover:to-emerald-800 text-white rounded-full font-black text-sm uppercase tracking-widest transition-all shadow-xl shadow-green-100 hover:-translate-y-1"
                  >
                    ✅ Aprobar
                  </button>
                </div>
              </div>
            )
          ) : (
            // Solo botón cerrar si no puede revisar
            <div className="flex justify-between items-center w-full">
              <p className="text-sm font-black text-gray-400 uppercase tracking-[0.2em] italic flex items-center gap-3">
                {reviewLevel ? `🔒 Nivel ${reviewLevel.toUpperCase()} ya validado` : 'ℹ️ Solo consulta de registro'}
              </p>
              <button
                onClick={onClose}
                className="px-10 py-3 bg-gray-900 hover:bg-black text-white rounded-full font-bold transition-all shadow-xl hover:-translate-y-0.5"
              >
                Cerrar consulta
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}