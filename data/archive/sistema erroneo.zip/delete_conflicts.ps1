# Renombrar archivos para que Next.js no los vea como rutas
Get-ChildItem -Path "app/(admin)" -Filter "*.*" -Recurse | ForEach-Object {
    if ($_.Name -eq "page.tsx") { Rename-Item -Path $_.FullName -NewName "page.tsx.disabled" -Force -ErrorAction SilentlyContinue }
    if ($_.Name -eq "layout.tsx") { Rename-Item -Path $_.FullName -NewName "layout.tsx.disabled" -Force -ErrorAction SilentlyContinue }
}

# Intentar renombrar las carpetas también
Rename-Item -LiteralPath 'app/(admin)' -NewName 'app_deleted_admin' -Force -ErrorAction SilentlyContinue
Rename-Item -LiteralPath 'app/checklists_BACKUP' -NewName 'app_deleted_checklists' -Force -ErrorAction SilentlyContinue

Write-Host "File disabling triggered."
