-- 1. Contar filas totales en el origen
SELECT COUNT(*) as total_temp_rows FROM "feedback_temp";

-- 2. Ver si el JOIN funciona (usando la lógica exacta)
SELECT 
    f."Sucursal" as temp_name, 
    s.name as store_name, 
    count(*) 
FROM "feedback_temp" f
LEFT JOIN stores s ON UPPER(TRIM(f."Sucursal")) = UPPER(TRIM(s.name))
GROUP BY 1, 2;

-- 3. Ver qué filas NO hacen match
SELECT DISTINCT "Sucursal" 
FROM "feedback_temp" f
WHERE NOT EXISTS (
    SELECT 1 FROM stores s WHERE UPPER(TRIM(s.name)) = UPPER(TRIM(f."Sucursal"))
);
