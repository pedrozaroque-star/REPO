-- Add Admin Review columns to customer_feedback
ALTER TABLE customer_feedback 
ADD COLUMN IF NOT EXISTS admin_review_status TEXT DEFAULT 'pendiente',
ADD COLUMN IF NOT EXISTS admin_review_comments TEXT,
ADD COLUMN IF NOT EXISTS admin_reviewer_id UUID REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS admin_review_date TIMESTAMPTZ;

-- Add constraint for status enum if desired (optional but good for data integrity)
ALTER TABLE customer_feedback 
DROP CONSTRAINT IF EXISTS customer_feedback_admin_review_status_check;

ALTER TABLE customer_feedback 
ADD CONSTRAINT customer_feedback_admin_review_status_check 
CHECK (admin_review_status IN ('pendiente', 'aprobado', 'rechazado', 'corregir'));
