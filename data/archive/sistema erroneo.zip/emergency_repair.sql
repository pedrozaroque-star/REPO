-- 1. Grant usage on schema public to authenticated role
GRANT USAGE ON SCHEMA public TO authenticated;

-- 2. Grant ALL permissions on critical tables to authenticated
GRANT ALL ON TABLE public.notifications TO authenticated;
GRANT ALL ON TABLE public.customer_feedback TO authenticated;

-- 3. Ensure 'read' column exists in notifications (Sanity Check)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'notifications' AND column_name = 'read') THEN
        ALTER TABLE public.notifications ADD COLUMN read BOOLEAN DEFAULT FALSE;
    END IF;
END
$$;

-- 4. Reset RLS Policy for Notifications (Allow Everything for Authenticated)
DO $$
BEGIN
    DROP POLICY IF EXISTS "Enable all access for authenticated" ON "public"."notifications";
    CREATE POLICY "Enable all access for authenticated" ON "public"."notifications"
    AS PERMISSIVE FOR ALL
    TO authenticated
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);
END
$$;

-- 5. Reset RLS Policy for Customer Feedback (Allow READ for everyone, Write for Auth)
DO $$
BEGIN
    DROP POLICY IF EXISTS "Enable read access for all users" ON "public"."customer_feedback";
    CREATE POLICY "Enable read access for all users" ON "public"."customer_feedback"
    AS PERMISSIVE FOR SELECT
    TO public
    USING (true);

    DROP POLICY IF EXISTS "Enable all access for authenticated" ON "public"."customer_feedback";
    CREATE POLICY "Enable all access for authenticated" ON "public"."customer_feedback"
    AS PERMISSIVE FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);
END
$$;

-- 6. Force reload config
NOTIFY pgrst, 'reload config';
