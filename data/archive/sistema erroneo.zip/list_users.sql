SELECT id, email, role FROM users;
