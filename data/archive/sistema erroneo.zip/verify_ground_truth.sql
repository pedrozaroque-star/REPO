-- 1. Check Notifications Schema (Is 'read' there?)
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'notifications' AND column_name = 'read';

-- 2. Check Feedback 511 (Is it ACTUALLY rejected? Or NULL?)
SELECT id, admin_review_status, admin_review_comments 
FROM customer_feedback 
WHERE id = 511;

-- 3. Check Policies again (Who can see what?)
SELECT * FROM pg_policies WHERE tablename = 'customer_feedback';
SELECT * FROM pg_policies WHERE tablename = 'notifications';

-- 4. Try to READ it as anonymous to see if RLS blocks it (simulating restricted access)
-- Note: we can't easily simulate roles in this SQL runner, but if Step 2 returns 'rechazado', then RLS is the blocker.
