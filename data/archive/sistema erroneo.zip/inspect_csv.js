const fs = require('fs');
const path = require('path');
const readline = require('readline');

const filePath = path.join(process.cwd(), 'feedback_clientes.csv');

async function inspectCSV() {
    if (!fs.existsSync(filePath)) {
        console.error('File not found:', filePath);
        process.exit(1);
    }

    const fileStream = fs.createReadStream(filePath);
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });

    let lineCount = 0;
    for await (const line of rl) {
        console.log(`Line ${lineCount}:`, line);
        lineCount++;
        if (lineCount >= 2) break; // Read only first 2 lines (header + 1 data row)
    }
}

inspectCSV();
