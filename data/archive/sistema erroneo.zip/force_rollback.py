import subprocess
import os

files_to_restore = [
    "app/checklists/page.tsx",
    "app/inspecciones/page.tsx",
    "app/checklists-manager/page.tsx",
    "app/dashboard/page.tsx"
]

for file in files_to_restore:
    print(f"Restoring {file}...")
    try:
        # Use HEAD~5 to be safe and get the pre-overhaul version
        result = subprocess.run(["git", "checkout", "HEAD~5", "--", file.replace("/", os.sep)], 
                                capture_output=True, text=True, check=True)
        print(f"SUCCESS: {result.stdout}")
    except subprocess.CalledProcessError as e:
        print(f"FAILED: {file}")
        print(f"Error: {e.stderr}")

print("Rollback script finished.")
