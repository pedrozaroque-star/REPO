-- 1. Comparar Columnas de ambas tablas
SELECT 
    t.table_name,
    c.column_name, 
    c.data_type
FROM information_schema.columns c
JOIN information_schema.tables t ON c.table_name = t.table_name
WHERE c.table_name IN ('customer_feedback', 'feedback_temp')
ORDER BY t.table_name, c.ordinal_position;

-- 2. Ver un registro de ejemplo de 'feedback_temp' (Origen)
SELECT * FROM feedback_temp LIMIT 1;

-- 3. Ver un registro de ejemplo de 'customer_feedback' (Destino)
SELECT * FROM customer_feedback LIMIT 1;
