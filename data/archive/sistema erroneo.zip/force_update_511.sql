UPDATE customer_feedback 
SET admin_review_status = 'rechazado', 
    admin_review_comments = 'PRUEBAFORZADA - SI VES ESTO ES QUE EL UPDATE ORIGINAL FALLO' 
WHERE id = 511;
