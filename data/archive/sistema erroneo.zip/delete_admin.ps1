$shell = New-Object -ComObject Shell.Application
$folder = $shell.NameSpace("c:\Users\pedro\Desktop\teg-modernizado\app")
$item = $folder.ParseName("(admin)")
if ($item) {
    $item.InvokeVerb("delete")
    Write-Host "Deletion initiated"
}
else {
    Write-Host "Folder not found or already deleted"
}
