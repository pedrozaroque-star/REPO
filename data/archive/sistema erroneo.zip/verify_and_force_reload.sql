-- 1. Check if column exists
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'notifications';

-- 2. Check if admin review columns exist
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'customer_feedback';

-- 3. FORCE Schema Cache Reload by COMMENTing on tables (This event triggers reload)
COMMENT ON TABLE notifications IS 'Table for user notifications - Rebuilt Cache';
COMMENT ON TABLE customer_feedback IS 'Table for customer feedback - Rebuilt Cache';

-- 4. Check RLS on notifications (Maybe we can't update read status?)
SELECT * FROM pg_policies WHERE tablename = 'notifications';

-- 5. Ensure Policy Exists for Notification Update
-- 'ENABLE ALL permissions for authenticated users on notifications'
DO $$
BEGIN
    DROP POLICY IF EXISTS "Enable all access for authenticated" ON "public"."notifications";
    CREATE POLICY "Enable all access for authenticated" ON "public"."notifications"
    AS PERMISSIVE FOR ALL
    TO authenticated
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);
END
$$;
