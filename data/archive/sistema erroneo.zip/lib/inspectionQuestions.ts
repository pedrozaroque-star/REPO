export const INSPECTION_DICT: any = {
    servicio: {
        label: 'Servicio al Cliente',
        items: ['Saluda y despide cordialmente', 'Atiende con paciencia y respeto', 'Entrega órdenes con frase de cierre', 'Evita charlas personales en línea']
    },
    carnes: {
        label: 'Procedimiento de Carnes',
        items: ['Controla temperatura (450°/300°) y tiempos', 'Utensilios limpios, no golpear espátulas', 'Escurre carnes y rota producto (FIFO)', 'Vigila cebolla asada y porciones']
    },
    alimentos: {
        label: 'Preparación de Alimentos',
        items: ['Respeta porciones estándar (cucharas)', 'Quesadillas bien calientes, sin quemar', 'Burritos bien enrollados, sin dorar de más', 'Stickers correctos donde aplica']
    },
    tortillas: {
        label: 'Seguimiento a Tortillas',
        items: ['Tortillas bien calientes (aceite solo en orillas)', 'Máx 5 tacos por plato (presentación)', 'Reponer a tiempo y mantener frescura']
    },
    limpieza: {
        label: 'Limpieza General y Baños',
        items: ['Cubetas rojas con sanitizer tibio', 'Plancha limpia y sin residuos', 'Baños con insumos completos y sin olores', 'Exterior y basureros limpios']
    },
    bitacoras: {
        label: 'Checklists y Bitácoras',
        items: ['Checklist apertura/cierre completo', 'Bitácora de temperaturas al día', 'Registros de limpieza firmados']
    },
    aseo: {
        label: 'Aseo Personal',
        items: ['Uniforme limpio y completo', 'Uñas cortas, sin joyas/auriculares', 'Uso correcto de gorra y guantes']
    }
}
