export const MANAGER_CHECKLIST_SECTIONS = [
    {
        title: 'Cookline and Kitchen',
        items: [
            'No trash or oil under all grills equipment',
            'All products are at proper temperature',
            'Sneeze Guards are cleaned (fingerprints etc)',
            'All stainless steel is clean and polished',
            'All hoods are clean and in working order',
            'Grills are clean (panels on side no buildup)',
            'All trash cans are clean (inside out)',
            'Walls and all doors are clean',
            'Nacho cheese machine is clean',
            'Food is fresh and looks appetizing to guest',
            'Buckets @200ppm, are being utilized; towels not sitting on line',
            'Walk-in walls, floors and baseboards are clean and swept',
            'All items are 6" above ground (boxes, mops, etc.)',
            'Prep Stations are cleaned and sanitized',
            'All equipment is in working order',
            'Delivery is put away and is organized',
            'All lighting and vents are working and clean',
            'Gaskets are clean and not ripped',
            'Soda nozzles are clean (no mildew)',
            'Ice machine is free of mildew and wiped down',
            'Scissors/Tomato/Lime clean and working',
            'All drains are clean',
            'Employee restroom is clean and stocked',
            'All open bags are stored properly'
        ]
    },
    {
        title: 'Dining Room & Guest Areas',
        items: [
            "Clean/dust furniture, TV's, etc.",
            'Windows and window seals are clean',
            'Restrooms are clean and in working order',
            '5 Second greeting and upsell (welcoming guests)',
            'Music and AC at appropriate level',
            'Dining room is clean / Parking Lot',
            'Walls, drink stations are clean',
            'Vents and ceiling tiles are clean and in working order',
            'Uniforms are clean and free of stains',
            'Menuboards are working',
            'Trash can area clean and wiped down',
            'Table touching guest in dining room',
            'Parking Lot and trash cans clean',
            'Entry doors clean (No smudges)'
        ]
    },
    {
        title: 'Checklist and Reports',
        items: [
            'Food handlers cards are on file',
            'Is store fully staffed',
            'What is labor % for week',
            'How many assistants? Shift leaders',
            'Are all checklists being utilized? Complete',
            'Schedule posted and clear to read',
            'Are managers aware of employees time clock errors? (Ronos/Toast)',
            'Action plans in place for any team members (WHO)',
            'Are sales up from prior weeks',
            'Does everyone have at least one day off',
            'Is everyone trained on new processes',
            'Has all repairs been reported on Basecamp',
            'Cash handling procedures are being followed'
        ]
    },
    {
        title: 'Temperature is taken of each employee on shift',
        items: [
            'Any employee issues reported to DM',
            'Soda CO2 is 1/4 or less, let manager know'
        ]
    }
]
