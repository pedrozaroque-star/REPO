-- Inspect current schema of customer_feedback to prevent duplicates
SELECT 
    column_name, 
    data_type 
FROM 
    information_schema.columns 
WHERE 
    table_name = 'customer_feedback';
