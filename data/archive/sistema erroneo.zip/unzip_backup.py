import zipfile
import os

zip_path = 'RESPALDO 12292025.zip'
extract_path = 'respaldo_recovered'

print(f"Unzipping {zip_path} to {extract_path}...")
try:
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)
    print("Unzip successful.")
except Exception as e:
    print(f"Error: {e}")
