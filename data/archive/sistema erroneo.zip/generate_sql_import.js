
const { createClient } = require('@supabase/supabase-js');
const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: '.env.local' });

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('Missing Supabase credentials');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);
const FILE_PATH = path.join(process.cwd(), 'FEEDBACK REAL EXCEL.xlsx');
const OUTPUT_FILE = path.join(process.cwd(), 'import_feedback.sql');

async function generateSQL() {
    console.log('🔄 Reading Excel and fetching Stores...');

    if (!fs.existsSync(FILE_PATH)) {
        console.error(`❌ File not found: ${FILE_PATH}`);
        process.exit(1);
    }
    const workbook = XLSX.readFile(FILE_PATH);
    const sheetName = workbook.SheetNames[0];
    const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

    const { data: stores, error } = await supabase.from('stores').select('id, name');
    if (error) {
        console.error('Error fetching stores:', error);
        process.exit(1);
    }

    const storeMap = {};
    stores.forEach(s => {
        storeMap[s.name.toUpperCase().trim()] = s.id;
    });

    console.log(`📊 Processing ${data.length} rows...`);

    let sqlContent = `-- SQL Import Script generated from FEEDBACK REAL EXCEL.xlsx\n`;
    sqlContent += `-- Run this in Supabase SQL Editor\n\n`;
    sqlContent += `TRUNCATE TABLE customer_feedback;\n\n`;
    sqlContent += `INSERT INTO customer_feedback (submission_date, store_id, customer_name, email, visit_frequency, service_rating, speed_rating, food_quality_rating, cleanliness_rating, nps_score, nps_category, comments, ticket_url) VALUES \n`;

    const values = [];

    for (const row of data) {
        const branchName = row['Sucursal'] || row['Tienda'] || row['Branch'] || '';
        const storeId = storeMap[branchName.toString().toUpperCase().trim()];

        if (!storeId) continue;

        const parseRating = (val) => {
            if (!val) return 0;
            if (typeof val === 'number') return val;
            const match = val.toString().match(/(\d+)/);
            return match ? parseInt(match[1]) : 0;
        };

        const determineNPS = (score) => {
            if (score >= 9) return 'promoter';
            if (score >= 7) return 'passive';
            return 'detractor';
        };

        const escapeSQL = (str) => {
            if (!str) return 'NULL';
            // Simple escape for single quotes
            return `'${str.toString().replace(/'/g, "''")}'`;
        };

        const dateVal = excelDateToJS(row['Marca temporal'] || row['Date']);
        const email = escapeSQL(row['Email'] || row['Correo']);
        const freq = escapeSQL(row['Frecuencia'] || row['Visit Frequency']);
        const name = escapeSQL(row['Nombre'] || row['Customer'] || 'Anónimo');
        const comment = escapeSQL(row['Comentarios'] || row['Comments'] || '');
        const ticket = escapeSQL(row['Ticket'] || row['Foto Ticket']);

        const service = parseRating(row['Servicio']);
        const speed = parseRating(row['Rapidez'] || row['Speed']);
        const quality = parseRating(row['Calidad'] || row['Quality']);
        const clean = parseRating(row['Limpieza'] || row['Cleanliness']);
        const nps = parseRating(row['NPS'] || row['Recomendación']);
        const category = `'${determineNPS(nps)}'`;

        values.push(`('${dateVal}', '${storeId}', ${name}, ${email}, ${freq}, ${service}, ${speed}, ${quality}, ${clean}, ${nps}, ${category}, ${comment}, ${ticket})`);
    }

    // Join all values with commas and a semicolon at the end
    sqlContent += values.join(',\n') + ';';

    fs.writeFileSync(OUTPUT_FILE, sqlContent);
    console.log(`✅ SQL file generated at: ${OUTPUT_FILE}`);
}

function excelDateToJS(serial) {
    if (!serial) return new Date().toISOString();
    if (typeof serial === 'string') return new Date(serial).toISOString();
    const utc_days = Math.floor(serial - 25569);
    const utc_value = utc_days * 86400;
    const date_info = new Date(utc_value * 1000);
    return date_info.toISOString();
}

generateSQL();
