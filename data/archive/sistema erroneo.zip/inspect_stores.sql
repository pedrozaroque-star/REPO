SELECT id, name 
FROM stores 
WHERE name ILIKE '%Lynwood%' 
   OR name ILIKE '%Santa Ana%' 
   OR name ILIKE '%South Gate%';
