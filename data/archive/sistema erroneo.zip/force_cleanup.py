import os
import shutil
import subprocess
import time

def kill_node():
    try:
        subprocess.run(['taskkill', '/F', '/IM', 'node.exe'], capture_output=True)
        print("Killed node processes")
        time.sleep(2)
    except:
        pass

def force_delete(path):
    if not os.path.exists(path):
        print(f"Path {path} does not exist")
        return

    # Try standard delete
    try:
        shutil.rmtree(path)
        print(f"Deleted {path}")
        return
    except Exception as e:
        print(f"Standard delete failed: {e}")

    # Try renaming first
    new_path = path + "_to_be_deleted_" + str(int(time.time()))
    try:
        os.rename(path, new_path)
        print(f"Renamed {path} to {new_path}")
        shutil.rmtree(new_path)
        print(f"Deleted renamed {new_path}")
    except Exception as e:
        print(f"Rename failed: {e}")

if __name__ == "__main__":
    kill_node()
    paths = [
        r"c:\Users\pedro\Desktop\teg-modernizado\app\(admin)",
        r"c:\Users\pedro\Desktop\teg-modernizado\app\checklists_BACKUP",
        r"c:\Users\pedro\Desktop\teg-modernizado\app\test-dates",
        r"c:\Users\pedro\Desktop\teg-modernizado\.next"
    ]
    for p in paths:
        force_delete(p)
