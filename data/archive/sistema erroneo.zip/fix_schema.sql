-- PASO 1 (PREVIO): Corre esto para agregar las columnas que faltan
ALTER TABLE customer_feedback ADD COLUMN IF NOT EXISTS ticket_url TEXT;
ALTER TABLE customer_feedback ADD COLUMN IF NOT EXISTS email TEXT;
ALTER TABLE customer_feedback ADD COLUMN IF NOT EXISTS visit_frequency TEXT;
ALTER TABLE customer_feedback ADD COLUMN IF NOT EXISTS language TEXT;

-- Confirmación
SELECT column_name FROM information_schema.columns WHERE table_name = 'customer_feedback';
