-- Trigger to notify supervisors when Admin rejects feedback
CREATE OR REPLACE FUNCTION public.notify_feedback_review()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
    supervisor_user_id UUID;
    store_name_text TEXT;
BEGIN
    -- Only trigger if status changed to 'rechazado' or 'corregir'
    IF (NEW.admin_review_status = 'rechazado' OR NEW.admin_review_status = 'corregir') 
       AND (OLD.admin_review_status IS DISTINCT FROM NEW.admin_review_status) THEN

        -- Get Store Name
        BEGIN
            SELECT name INTO store_name_text FROM stores WHERE id = NEW.store_id;
        EXCEPTION WHEN OTHERS THEN
            store_name_text := 'Sucursal';
        END;

        -- STRATEGY: Notify ALL users with role 'supervisor' (or 'manager' if that makes more sense, but user said Supervisor)
        -- We assume there is a 'users' table with 'role' column based on previous context.
        -- We will loop through them to send notifications.
        
        FOR supervisor_user_id IN 
            SELECT id FROM users WHERE role = 'supervisor' -- Adjust role name if needed (e.g. 'supervisor' vs 'Supervisor')
        LOOP
            INSERT INTO notifications (
                user_id,
                title,
                message,
                type,
                link,
                reference_id,
                reference_type,
                is_read,
                created_at
            ) VALUES (
                supervisor_user_id, 
                '⚠️ Feedback Rechazado/Observado',
                'El feedback en ' || COALESCE(store_name_text, 'tienda') || ' requiere atención. Comentarios: ' || COALESCE(NEW.admin_review_comments, 'Sin comentarios'),
                'alert',
                '/feedback', -- Or specific link if possible
                NEW.id::text,
                'customer_feedback',
                false,
                NOW()
            );
        END LOOP;
        
    END IF;
    RETURN NEW;
END;
$function$;

-- Drop trigger if exists
DROP TRIGGER IF EXISTS tr_notify_feedback_review ON customer_feedback;

-- Create Trigger
CREATE TRIGGER tr_notify_feedback_review
AFTER UPDATE ON customer_feedback
FOR EACH ROW
EXECUTE FUNCTION notify_feedback_review();
