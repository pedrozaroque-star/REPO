const fs = require('fs');
const readline = require('readline');
const path = require('path');

console.log('START DEBUG');
const FILE_PATH = path.join(process.cwd(), 'feedback_clientes.csv');
try {
    if (!fs.existsSync(FILE_PATH)) {
        console.error('File not found');
    } else {
        console.log('File found, size:', fs.statSync(FILE_PATH).size);
        const rl = readline.createInterface({
            input: fs.createReadStream(FILE_PATH),
            crlfDelay: Infinity
        });
        let count = 0;
        rl.on('line', (line) => {
            if (count < 3) console.log('Line:', line);
            count++;
        });
        rl.on('close', () => console.log('Read', count, 'lines. END DEBUG'));
    }
} catch (e) {
    console.error('Error:', e);
}
