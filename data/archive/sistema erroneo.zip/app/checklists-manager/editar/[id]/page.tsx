'use client'

import { useState, useEffect } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'

// 53 Preguntas (las mismas del formulario de creación)
const SECTIONS = [
  {
    title: 'Cookline and Kitchen',
    items: [
      'No trash or oil under all grills equipment',
      'All products are at proper temperature',
      'Sneeze Guards are cleaned (fingerprints etc)',
      'All stainless steel is clean and polished',
      'All hoods are clean and in working order',
      'Grills are clean (panels on side no buildup)',
      'All trash cans are clean (inside out)',
      'Walls and all doors are clean',
      'Nacho cheese machine is clean',
      'Food is fresh and looks appetizing to guest',
      'Buckets @200ppm, are being utilized; towels not sitting on line',
      'Walk-in walls, floors and baseboards are clean and swept',
      'All items are 6" above ground (boxes, mops, etc.)',
      'Prep Stations are cleaned and sanitized',
      'All equipment is in working order',
      'Delivery is put away and is organized',
      'All lighting and vents are working and clean',
      'Gaskets are clean and not ripped',
      'Soda nozzles are clean (no mildew)',
      'Ice machine is free of mildew and wiped down',
      'Scissors/Tomato/Lime clean and working',
      'All drains are clean',
      'Employee restroom is clean and stocked',
      'All open bags are stored properly'
    ]
  },
  {
    title: 'Dining Room & Guest Areas',
    items: [
      "Clean/dust furniture, TV's, etc.",
      'Windows and window seals are clean',
      'Restrooms are clean and in working order',
      '5 Second greeting and upsell (welcoming guests)',
      'Music and AC at appropriate level',
      'Dining room is clean / Parking Lot',
      'Walls, drink stations are clean',
      'Vents and ceiling tiles are clean and in working order',
      'Uniforms are clean and free of stains',
      'Menuboards are working',
      'Trash can area clean and wiped down',
      'Table touching guest in dining room',
      'Parking Lot and trash cans clean',
      'Entry doors clean (No smudges)'
    ]
  },
  {
    title: 'Checklist and Reports',
    items: [
      'Food handlers cards are on file',
      'Is store fully staffed',
      'What is labor % for week',
      'How many assistants? Shift leaders',
      'Are all checklists being utilized? Complete',
      'Schedule posted and clear to read',
      'Are managers aware of employees time clock errors? (Ronos/Toast)',
      'Action plans in place for any team members (WHO)',
      'Are sales up from prior weeks',
      'Does everyone have at least one day off',
      'Is everyone trained on new processes',
      'Has all repairs been reported on Basecamp',
      'Cash handling procedures are being followed'
    ]
  },
  {
    title: 'Additional',
    items: [
      'Temperature is taken of each employee on shift',
      'Any employee issues reported to DM',
      'Soda CO2 is 1/4 or less, let manager know'
    ]
  }
]

export default function EditManagerChecklistPage() {
  const router = useRouter()
  const params = useParams()
  const { user } = useAuth()
  const checklistId = params?.id

  const [checklist, setChecklist] = useState<any>(null)
  const [answers, setAnswers] = useState<{ [key: string]: string }>({})
  const [comments, setComments] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [canEdit, setCanEdit] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')

  useEffect(() => {
    if (user && checklistId) {
      loadChecklist()
    }
  }, [user, checklistId])

  if (!user) return null

  const loadChecklist = async () => {
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      const res = await fetch(
        `${url}/rest/v1/manager_checklists?id=eq.${checklistId}&select=*`,
        {
          headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` }
        }
      )
      const data = await res.json()

      if (!Array.isArray(data) || data.length === 0) {
        setErrorMessage('Checklist no encontrado')
        setLoading(false)
        return
      }

      const checklistData = data[0]
      setChecklist(checklistData)

      const validation = validateEditPermissions(checklistData)
      setCanEdit(validation.canEdit)
      setErrorMessage(validation.message)

      if (validation.canEdit) {
        if (checklistData.answers) {
          const loadedAnswers: { [key: string]: string } = {}
          Object.entries(checklistData.answers).forEach(([key, answer]: [string, any]) => {
            loadedAnswers[key] = answer.value || answer
          })
          setAnswers(loadedAnswers)
        }
        setComments(checklistData.comments || '')
      }

      setLoading(false)
    } catch (err) {
      console.error('Error loading checklist:', err)
      setErrorMessage('Error al cargar el checklist')
      setLoading(false)
    }
  }

  const validateEditPermissions = (checklistData: any) => {
    if (checklistData.user_id !== user?.id) {
      return {
        canEdit: false,
        message: '❌ Solo el creador puede editar este checklist'
      }
    }

    const supervisorStatus = checklistData.estatus_supervisor || 'pendiente'
    const adminStatus = checklistData.estatus_admin || 'pendiente'

    if (supervisorStatus !== 'pendiente' || adminStatus !== 'pendiente') {
      return {
        canEdit: false,
        message: '❌ No se puede editar un checklist que ya ha sido revisado'
      }
    }

    const checklistDateStr = checklistData.checklist_date
    const today = new Date()
    const year = today.getFullYear()
    const month = String(today.getMonth() + 1).padStart(2, '0')
    const day = String(today.getDate()).padStart(2, '0')
    const todayStr = `${year}-${month}-${day}`

    if (checklistDateStr !== todayStr) {
      return {
        canEdit: false,
        message: `❌ Solo se pueden editar checklists del día actual`
      }
    }

    return { canEdit: true, message: '' }
  }

  const handleAnswerChange = (sectionIdx: number, itemIdx: number, value: string) => {
    const key = `s${sectionIdx}_${itemIdx}`
    setAnswers(prev => ({ ...prev, [key]: value }))
  }

  const calculateScore = () => {
    const totalQuestions = SECTIONS.reduce((sum, section) => sum + section.items.length, 0)
    const answeredYes = Object.values(answers).filter(v => v === 'SI').length
    return totalQuestions > 0 ? Math.round((answeredYes / totalQuestions) * 100) : 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!canEdit) {
      alert('No tienes permisos para editar este checklist')
      return
    }

    setSaving(true)
    try {
      const score = calculateScore()
      const formattedAnswers: { [key: string]: { value: string } } = {}
      Object.entries(answers).forEach(([key, value]) => {
        formattedAnswers[key] = { value }
      })

      const payload = {
        answers: formattedAnswers,
        score: score,
        comments: comments || null
      }

      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      const res = await fetch(`${url}/rest/v1/manager_checklists?id=eq.${checklistId}`, {
        method: 'PATCH',
        headers: {
          'apikey': key || '',
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify(payload)
      })

      if (res.ok) {
        alert(`✅ Checklist actualizado exitosamente!\n\nNuevo Score: ${score}%`)
        router.push('/checklists-manager')
      } else {
        alert('Error al actualizar el checklist')
      }
    } catch (err) {
      console.error('Error:', err)
      alert('Error al actualizar el checklist')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="flex h-[80vh] items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#e31837]"></div>
      </div>
    )
  }

  if (!canEdit || errorMessage) {
    return (
      <div className="flex h-[80vh] items-center justify-center flex-col animate-in fade-in duration-500">
        <div className="bg-white p-12 rounded-[2.5rem] border border-gray-100 shadow-sm text-center max-w-md">
          <div className="text-6xl mb-6">🔒</div>
          <h2 className="text-2xl font-black text-gray-900 tracking-tight mb-2">Edición Restringida</h2>
          <p className="text-gray-500 font-medium mb-8 leading-relaxed">{errorMessage}</p>
          <div className="space-y-4">
            <button
              onClick={() => router.push('/checklists-manager')}
              className="w-full bg-gray-900 text-white px-8 py-4 rounded-2xl font-black text-[11px] tracking-widest uppercase hover:bg-[#e31837] transition-all shadow-xl active:scale-95"
            >
              ← Volver al Historial
            </button>
            {checklist && (
              <button
                onClick={() => router.push(`/checklists-manager/ver/${checklistId}`)}
                className="w-full bg-white border border-gray-200 text-gray-700 px-8 py-4 rounded-2xl font-black text-[11px] tracking-widest uppercase hover:bg-gray-50 transition-all active:scale-95"
              >
                👁️ Ver Evaluación
              </button>
            )}
          </div>
        </div>
      </div>
    )
  }

  const answeredCount = Object.keys(answers).length
  const totalQuestions = SECTIONS.reduce((sum, section) => sum + section.items.length, 0)
  const currentScore = calculateScore()

  return (
    <div className="p-8 lg:p-10 space-y-10 animate-in fade-in duration-700">
      <div className="max-w-[1200px] mx-auto space-y-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-gray-200 pb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="bg-[#e31837] text-white text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider">Modo Edición</span>
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Ajuste de Auditoría</span>
            </div>
            <h1 className="text-4xl font-black text-gray-900 tracking-tighter">
              Actualizar <span className="text-[#e31837]">Checklist</span>
            </h1>
            <p className="text-gray-500 mt-1 font-medium">{checklist?.store_name} • {checklist?.checklist_date}</p>
          </div>
          <button
            onClick={() => router.push('/checklists-manager')}
            className="px-6 py-3.5 bg-white border border-gray-200 text-gray-700 rounded-xl font-black text-[11px] tracking-widest uppercase transition-all hover:bg-gray-50 active:scale-95 shadow-sm"
          >
            ← Cancelar Cambios
          </button>
        </div>

        {/* Aviso de bloqueo por revisión 🔒 */}
        <div className="p-6 bg-amber-50 border border-amber-200 rounded-[2rem] flex items-start gap-4 animate-in slide-in-from-top duration-700">
          <div className="text-2xl mt-0.5">ℹ️</div>
          <div>
            <p className="text-sm font-bold text-amber-900 leading-snug">Nota sobre Edición Gerencial</p>
            <p className="text-xs font-medium text-amber-700 mt-1 leading-relaxed">
              Este registro se bloqueará para edición una vez que sea revisado por un Supervisor o Admin.
              Verifica que todos los hallazgos sean correctos antes de la revisión final.
            </p>
          </div>
        </div>

        {/* Progress Tracker Card */}
        <div className="bg-white rounded-[2.5rem] border border-gray-200 shadow-sm p-8 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex-1 w-full space-y-4">
            <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
              <span className="text-gray-500">Integridad de Datos</span>
              <span className="text-gray-900">{answeredCount} / {totalQuestions} Completadas</span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-[#e31837] h-full rounded-full transition-all duration-500"
                style={{ width: `${(answeredCount / totalQuestions) * 100}%` }}
              />
            </div>
          </div>
          <div className="bg-gray-50 px-10 py-4 rounded-2xl border border-gray-100 text-center min-w-[200px]">
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Score Resultante</p>
            <p className="text-3xl font-black text-gray-900 tracking-tighter">{currentScore}%</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-10">
          {SECTIONS.map((section, sIdx) => (
            <div key={sIdx} className="bg-white rounded-[2.5rem] border border-gray-200 shadow-sm overflow-hidden">
              <div className="p-8 border-b border-gray-50 bg-gray-50/30">
                <h3 className="text-lg font-black text-gray-900 tracking-tight uppercase italic">{section.title}</h3>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em] mt-1">Verificación de cumplimiento de área</p>
              </div>

              <div className="divide-y divide-gray-50">
                {section.items.map((question, qIdx) => {
                  const key = `s${sIdx}_${qIdx}`
                  const value = answers[key]
                  return (
                    <div key={qIdx} className="p-6 hover:bg-gray-50/50 transition-colors flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                      <div className="flex-1 flex gap-4 items-start">
                        <span className="w-8 h-8 rounded-lg bg-gray-50 border border-gray-100 flex items-center justify-center text-[10px] font-black text-gray-400">{qIdx + 1}</span>
                        <p className="text-gray-700 font-bold text-[14px] leading-relaxed pt-1">{question}</p>
                      </div>

                      <div className="flex gap-2">
                        {['SI', 'NO', 'NA'].map((opt) => (
                          <label key={opt} className={`
                            px-6 py-2.5 rounded-xl border text-[10px] font-black uppercase tracking-widest cursor-pointer transition-all
                            ${value === opt
                              ? (opt === 'SI' ? 'bg-emerald-50 border-emerald-200 text-emerald-600' : opt === 'NO' ? 'bg-red-50 border-red-200 text-red-600' : 'bg-gray-200 border-gray-300 text-gray-700')
                              : 'bg-white border-gray-100 text-gray-300 hover:border-gray-300'
                            }
                          `}>
                            <input
                              type="radio"
                              name={`q_${key}`}
                              value={opt}
                              checked={value === opt}
                              onChange={(e) => handleAnswerChange(sIdx, qIdx, e.target.value)}
                              className="hidden"
                            />
                            {opt === 'SI' ? 'Cumple' : opt === 'NO' ? 'Falla' : 'N/A'}
                          </label>
                        ))}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          ))}

          <div className="bg-white rounded-[2.5rem] border border-gray-200 shadow-sm p-10 space-y-10">
            <div className="space-y-6">
              <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Observaciones de la Auditoría</h3>
              <textarea
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                rows={4}
                className="w-full px-6 py-4 bg-gray-50 border-0 rounded-3xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none resize-none"
                placeholder="Añadir notas aclaratorias sobre los cambios realizados..."
              />
            </div>

            <div className="flex gap-4 pt-10 border-t border-gray-50">
              <button
                type="submit"
                disabled={saving || answeredCount < totalQuestions}
                className="flex-[2] px-8 py-4 bg-gray-900 text-white rounded-2xl font-black text-[11px] tracking-widest uppercase transition-all hover:bg-[#e31837] active:scale-95 shadow-xl disabled:bg-gray-300"
              >
                {saving ? 'Guardando Ajustes...' : 'Sincronizar Cambios'}
              </button>
              <button
                type="button"
                onClick={() => router.push('/checklists-manager')}
                className="flex-1 px-8 py-4 bg-white border border-gray-100 text-gray-400 rounded-2xl font-black text-[11px] tracking-widest uppercase transition-all hover:bg-gray-50 active:scale-95 shadow-sm"
              >
                Descartar
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}