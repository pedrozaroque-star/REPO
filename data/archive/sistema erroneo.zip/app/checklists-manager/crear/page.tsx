'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'
import { uploadPhotos } from '@/lib/uploadPhotos'

import { MANAGER_CHECKLIST_SECTIONS as SECTIONS } from '@/lib/managerChecklistQuestions'

export default function CreateManagerChecklistPage() {
  const router = useRouter()
  const { user } = useAuth()

  const getLocalDate = () => {
    const now = new Date()
    const year = now.getFullYear()
    const month = String(now.getMonth() + 1).padStart(2, '0')
    const day = String(now.getDate()).padStart(2, '0')
    return `${year}-${month}-${day}`
  }

  const [formData, setFormData] = useState({
    checklist_date: getLocalDate(),
    start_time: '',
    end_time: '',
    shift: 'AM',
    store_id: '',
    comments: ''
  })

  const [answers, setAnswers] = useState<{ [key: string]: string }>({})
  const [stores, setStores] = useState<any[]>([])
  const [photos, setPhotos] = useState<File[]>([])
  const [uploading, setUploading] = useState(false)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchStores()

    const now = new Date()
    const hours = String(now.getHours()).padStart(2, '0')
    const minutes = String(now.getMinutes()).padStart(2, '0')
    setFormData(prev => ({ ...prev, start_time: `${hours}:${minutes}` }))
  }, [])

  const fetchStores = async () => {
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      const res = await fetch(`${url}/rest/v1/stores?select=*&order=name.asc`, {
        headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` }
      })
      const data = await res.json()
      setStores(Array.isArray(data) ? data : [])
    } catch (err) {
      console.error('Error loading stores:', err)
    }
  }

  const handleAnswerChange = (sectionIdx: number, itemIdx: number, value: string) => {
    const key = `s${sectionIdx}_${itemIdx}`
    setAnswers(prev => ({ ...prev, [key]: value }))
  }

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files)
      setPhotos(prev => [...prev, ...newFiles].slice(0, 5))
    }
  }

  const removePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index))
  }

  const calculateScore = () => {
    const totalQuestions = SECTIONS.reduce((sum, section) => sum + section.items.length, 0)
    const answeredYes = Object.values(answers).filter(v => v === 'SI').length
    return totalQuestions > 0 ? Math.round((answeredYes / totalQuestions) * 100) : 0
  }

  const validateForm = () => {
    if (!formData.store_id) {
      alert('Por favor selecciona una sucursal')
      return false
    }
    if (!formData.start_time) {
      alert('Por favor ingresa la hora de inicio')
      return false
    }

    const totalQuestions = SECTIONS.reduce((sum, section) => sum + section.items.length, 0)
    const answeredQuestions = Object.keys(answers).length

    if (answeredQuestions < totalQuestions) {
      alert(`Por favor responde todas las preguntas. Respondidas: ${answeredQuestions}/${totalQuestions}`)
      return false
    }

    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validateForm() || !user) return

    setLoading(true)

    try {
      const now = new Date()
      const endTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`

      let photoUrls: string[] = []
      if (photos.length > 0) {
        setUploading(true)
        photoUrls = await uploadPhotos(photos, 'staff-photos', `manager_${user.id}`)
        setUploading(false)
      }

      const score = calculateScore()

      const payload = {
        store_id: parseInt(formData.store_id),
        user_id: user.id,
        manager_name: user.name || user.email,
        checklist_date: formData.checklist_date,
        checklist_time: formData.start_time,
        start_time: formData.start_time,
        end_time: endTime,
        shift: formData.shift,
        answers: answers,
        score: score,
        comments: formData.comments || null,
        photo_urls: photoUrls.length > 0 ? photoUrls : null,
        created_by: user.email
      }

      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      const res = await fetch(`${url}/rest/v1/manager_checklists`, {
        method: 'POST',
        headers: {
          'apikey': key || '',
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify(payload)
      })

      if (res.ok) {
        alert(`✅ Checklist guardado exitosamente!\n\nScore: ${score}%`)
        router.push('/checklists-manager')
      } else {
        alert('Error al guardar el checklist')
      }
    } catch (err) {
      console.error('Error:', err)
      alert('Error al guardar el checklist')
    } finally {
      setLoading(false)
    }
  }

  if (!user) return null

  const answeredCount = Object.keys(answers).length
  const totalQuestions = SECTIONS.reduce((sum, section) => sum + section.items.length, 0)
  const currentScore = calculateScore()

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Modern Header */}
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.back()}
              className="w-10 h-10 rounded-xl bg-white border border-gray-200 flex items-center justify-center text-gray-400 hover:text-gray-900 hover:border-gray-900 transition-all"
            >
              ←
            </button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 tracking-tight border-b-4 border-[#e31837] inline-block pb-1">
                Bitácora Gerencial (Manager)
              </h1>
              <p className="text-sm font-medium text-gray-500 mt-2">Evaluación de estándares operativos</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-[#e31837]">{currentScore}%</div>
            <div className="text-xs font-bold text-gray-400">Cumplimiento Actual</div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-10">
          <div className="bg-white rounded-[2.5rem] border border-gray-200 shadow-sm p-10">
            <h2 className="text-xl font-black text-gray-900 tracking-tight uppercase mb-8">Información de bitácora</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500 ml-1">Sucursal</label>
                <select
                  required
                  value={formData.store_id}
                  onChange={(e) => setFormData({ ...formData, store_id: e.target.value })}
                  className="w-full px-5 py-4 bg-gray-50 border-0 rounded-2xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                >
                  <option value="">Seleccionar...</option>
                  {stores.map(store => (
                    <option key={store.id} value={store.id}>{store.name}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Turno</label>
                <select
                  value={formData.shift}
                  onChange={(e) => setFormData({ ...formData, shift: e.target.value })}
                  className="w-full px-5 py-3.5 bg-gray-50 border-0 rounded-xl text-sm font-bold text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                >
                  <option value="AM">AM</option>
                  <option value="PM">PM</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500 ml-1">Fecha</label>
                <input
                  type="date"
                  value={formData.checklist_date}
                  onChange={(e) => setFormData({ ...formData, checklist_date: e.target.value })}
                  className="w-full px-5 py-4 bg-gray-50 border-0 rounded-2xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500 ml-1">Hora Inicio</label>
                <input
                  type="time"
                  value={formData.start_time}
                  onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                  className="w-full px-5 py-4 bg-gray-50 border-0 rounded-2xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                  required
                />
              </div>
            </div>
          </div>

          {SECTIONS.map((section, sIdx) => (
            <div key={sIdx} className="bg-white rounded-[2.5rem] border border-gray-200 shadow-sm overflow-hidden">
              <div className="p-8 border-b border-gray-50 bg-gray-50/30">
                <h3 className="text-lg font-bold text-gray-900 tracking-tight">{section.title}</h3>
                <p className="text-xs font-bold text-gray-400 mt-1">Verificación de cumplimiento de área</p>
              </div>
              <div className="divide-y divide-gray-50">
                {section.items.map((question, qIdx) => {
                  const key = `s${sIdx}_${qIdx}`
                  const value = answers[key]
                  return (
                    <div key={qIdx} className="p-6 hover:bg-gray-50/50 transition-colors flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                      <div className="flex-1 flex gap-4 items-start">
                        <span className="w-8 h-8 rounded-lg bg-gray-50 border border-gray-100 flex items-center justify-center text-xs font-bold text-gray-400">{qIdx + 1}</span>
                        <p className="text-gray-700 font-medium text-sm leading-relaxed pt-1">{question}</p>
                      </div>
                      <div className="flex gap-2">
                        {['SI', 'NO', 'NA'].map((opt) => (
                          <label key={opt} className={`px-6 py-2.5 rounded-xl border text-[10px] font-black uppercase tracking-widest cursor-pointer transition-all ${value === opt ? (opt === 'SI' ? 'bg-emerald-50 border-emerald-200 text-emerald-600' : opt === 'NO' ? 'bg-red-50 border-red-200 text-red-600' : 'bg-gray-200 border-gray-300 text-gray-700') : 'bg-white border-gray-100 text-gray-300 hover:border-gray-300'}`}>
                            <input type="radio" name={`q_${key}`} value={opt} checked={value === opt} onChange={(e) => handleAnswerChange(sIdx, qIdx, e.target.value)} className="hidden" />
                            {opt === 'SI' ? 'Cumple' : opt === 'NO' ? 'Falla' : 'N/A'}
                          </label>
                        ))}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          ))}

          <div className="bg-white rounded-[2.5rem] border border-gray-200 shadow-sm p-10 space-y-10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-6">
                <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Evidencias Fotográficas</h3>
                <div className="relative group/upload">
                  <input type="file" accept="image/*" multiple onChange={handlePhotoChange} className="absolute inset-0 opacity-0 cursor-pointer z-20" id="photo-upload" />
                  <div className="w-full py-8 border-2 border-dashed border-gray-100 rounded-3xl bg-gray-50 flex flex-col items-center justify-center group-hover/upload:border-[#e31837]/30 transition-all">
                    <span className="text-3xl mb-2">📸</span>
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Añadir Archivos (Max 5)</span>
                  </div>
                </div>
                {photos.length > 0 && (
                  <div className="grid grid-cols-5 gap-4">
                    {photos.map((photo, idx) => (
                      <div key={idx} className="relative group">
                        <img src={URL.createObjectURL(photo)} alt="" className="w-full h-20 object-cover rounded-xl border border-gray-100" />
                        <button type="button" onClick={() => removePhoto(idx)} className="absolute -top-2 -right-2 w-6 h-6 bg-red-600 text-white rounded-full flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity">×</button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="space-y-6">
                <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Observaciones Finales</h3>
                <textarea value={formData.comments} onChange={(e) => setFormData({ ...formData, comments: e.target.value })} rows={4} className="w-full px-6 py-4 bg-gray-50 border-0 rounded-3xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none resize-none" placeholder="Justificaciones o notas adicionales para la gerencia..." />
              </div>
            </div>
            <div className="flex gap-4 pt-10 border-t border-gray-50">
              <button type="submit" disabled={loading || uploading} className="flex-[2] px-8 py-4 bg-gray-900 text-white rounded-2xl font-black text-[11px] tracking-widest uppercase transition-all hover:bg-[#e31837] active:scale-95 shadow-xl disabled:bg-gray-300">
                {uploading ? 'Transfiriendo archivos...' : loading ? 'Sincronizando...' : `Finalizar Protocolo (${currentScore}%)`}
              </button>
              <button type="button" onClick={() => router.push('/checklists-manager')} className="flex-1 px-8 py-4 bg-white border border-gray-100 text-gray-400 rounded-2xl font-black text-[11px] tracking-widest uppercase transition-all hover:bg-gray-50 active:scale-95 shadow-sm">
                Cancelar
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}