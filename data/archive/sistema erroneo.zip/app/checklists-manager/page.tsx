'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'
import ReviewModal from '@/components/ReviewModal'
import { getStatusColor, getStatusLabel, formatDateLA, canEditChecklist } from '@/lib/checklistPermissions'
import { supabase } from '@/lib/supabase'
import LoadingScreen from '@/components/LoadingScreen'

function ManagerChecklistsContent() {
  const router = useRouter()
  const { user } = useAuth()
  const [checklists, setChecklists] = useState<any[]>([])
  const [stats, setStats] = useState({
    total: 0,
    pendientes: 0,
    aprobados: 0,
    rechazados: 0,
    cerrados: 0
  })
  const [loading, setLoading] = useState(true)
  const [storeFilter, setStoreFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [stores, setStores] = useState<any[]>([])
  const [showReviewModal, setShowReviewModal] = useState(false)

  useEffect(() => {
    if (user) fetchData()
  }, [storeFilter, statusFilter, user])

  const fetchData = async () => {
    try {
      setLoading(true)

      const { data: storesData } = await supabase.from('stores').select('*').order('name', { ascending: true })
      setStores(Array.isArray(storesData) ? storesData : [])

      let query = supabase
        .from('manager_checklists')
        .select(`
          *,
          stores (name, code),
          users (full_name)
        `)
        .order('checklist_date', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(100)

      if (storeFilter !== 'all') {
        query = query.eq('store_id', storeFilter)
      }

      const { data: checkData, error } = await query
      if (error) throw error

      let formattedData = Array.isArray(checkData) ? checkData.map(item => ({
        ...item,
        store_name: item.stores?.name || 'N/A',
        manager_real_name: item.users?.full_name || item.manager_name || item.created_by
      })) : []

      if (statusFilter !== 'all') {
        const reviewLevel = 'supervisor'
        formattedData = formattedData.filter(item => {
          const status = item[`estatus_${reviewLevel}`] || 'pendiente'
          return status === statusFilter
        })
      }

      setChecklists(formattedData)

      const { data: allChecks } = await supabase.from('manager_checklists').select('estatus_supervisor')
      const allChecksArray = Array.isArray(allChecks) ? allChecks : []
      const statusField = 'estatus_supervisor'

      setStats({
        total: allChecksArray.length,
        pendientes: allChecksArray.filter(c => (c[statusField] || 'pendiente') === 'pendiente').length,
        aprobados: allChecksArray.filter(c => c[statusField] === 'aprobado').length,
        rechazados: allChecksArray.filter(c => c[statusField] === 'rechazado').length,
        cerrados: allChecksArray.filter(c => c[statusField] === 'cerrado').length
      })

      setLoading(false)
    } catch (err) {
      console.error('Error:', err)
      setLoading(false)
    }
  }

  const getStatusBadge = (item: any) => {
    const status = item.estatus_supervisor || 'pendiente'
    const colorClass = getStatusColor(status)
    const label = getStatusLabel(status)

    return (
      <span className={`px-2.5 py-1 rounded-md text-xs font-bold capitalize tracking-wide border border-current bg-opacity-5 transition-all ${colorClass}`}>
        {label.toLowerCase()}
      </span>
    )
  }

  const canReview = () => {
    const role = user?.role?.toLowerCase()
    return role === 'supervisor' || role === 'admin'
  }

  const canCreate = () => {
    const role = user?.role?.toLowerCase()
    return role === 'manager'
  }

  const handleEdit = (item: any) => {
    if (!user) return
    const editCheck = canEditChecklist(
      item.checklist_date || item.created_at,
      user.role,
      item.user_id,
      user.id,
      item.start_time,
      item.estatus_supervisor
    )
    if (!editCheck.canEdit) {
      alert(editCheck.reason)
      return
    }
    router.push(`/checklists-manager/editar/${item.id}`)
  }

  const canUserEdit = (item: any) => {
    if (!user) return false
    const editCheck = canEditChecklist(
      item.checklist_date || item.created_at,
      user.role,
      item.user_id,
      user.id,
      item.start_time,
      item.estatus_supervisor
    )
    return editCheck.canEdit
  }

  if (loading) {
    return <LoadingScreen message="Sincronizando Auditoría de Gerencia..." />
  }

  if (!user) return null

  return (
    <div className="p-6">
      <div className="max-w-[94%] mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-6">
            <div className="w-16 h-16 rounded-2xl bg-gray-900 flex items-center justify-center shadow-lg">
              <span className="text-3xl">🛡️</span>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Bitácora Gestión</h1>
              <p className="text-gray-600 mt-1">Supervisión táctica de cumplimiento y control administrativo.</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {canReview() && checklists.length > 0 && (
              <button
                onClick={() => setShowReviewModal(true)}
                className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-all shadow-sm flex items-center gap-2"
              >
                {user?.role === 'admin' ? '👁️ Ver Auditoría' : '✓ Revisión Administrativa'}
              </button>
            )}
            {canCreate() && (
              <button
                onClick={() => router.push('/checklists-manager/crear')}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-all shadow-sm flex items-center gap-2"
              >
                <span className="text-lg leading-none">+</span> Nueva Ejecución
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          {[
            { label: 'Archivados', val: stats.total, color: 'text-gray-900', icon: '📂' },
            { label: 'Pendientes', val: stats.pendientes, color: 'text-amber-600', icon: '⏱️' },
            { label: 'Validados', val: stats.aprobados, color: 'text-emerald-600', icon: '🛡️' },
            { label: 'Observados', val: stats.rechazados, color: 'text-red-600', icon: '⚠️' },
            { label: 'Finalizados', val: stats.cerrados, color: 'text-gray-500', icon: '🔒' }
          ].map((s, i) => (
            <div key={i} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm text-center">
              <span className="text-xl mb-2 block">{s.icon}</span>
              <p className="text-[10px] text-gray-400 uppercase font-bold mb-1">{s.label}</p>
              <p className={`text-xl font-bold ${s.color}`}>{s.val}</p>
            </div>
          ))}
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-wrap gap-6 items-center justify-between mb-8">
          <div className="flex items-center gap-6">
            <div className="relative">
              <select
                value={storeFilter}
                onChange={(e) => setStoreFilter(e.target.value)}
                className="appearance-none bg-gray-50 border border-gray-200 rounded-lg px-4 py-2 pr-10 text-sm font-medium text-gray-700 focus:ring-2 focus:ring-red-500 outline-none cursor-pointer"
              >
                <option value="all">Todas las Tiendas</option>
                {stores.map(store => (
                  <option key={store.id} value={store.id}>{store.name.toUpperCase()}</option>
                ))}
              </select>
              <span className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-xs">▼</span>
            </div>

            {canReview() && (
              <div className="flex bg-gray-100 p-1 rounded-lg gap-1 border border-gray-200">
                {['all', 'pendiente', 'aprobado', 'rechazado'].map(f => (
                  <button
                    key={f}
                    onClick={() => setStatusFilter(f)}
                    className={`px-4 py-1.5 rounded-md text-xs font-bold uppercase transition-all ${statusFilter === f
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                      }`}
                  >
                    {f === 'all' ? 'Ver Todos' : f}
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Resultados:</span>
            <span className="px-3 py-1 bg-gray-900 text-white rounded-lg text-xs font-bold">{checklists.length}</span>
          </div>
        </div>

        {/* Table Section */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden mb-10">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Fecha / Hora</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Sucursal</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Responsable</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Puntuación</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-center">Estado</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {checklists.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-gray-500 font-medium">
                      No se encontraron registros de gestión.
                    </td>
                  </tr>
                ) : (
                  checklists.map((item) => {
                    const scoreColor = item.score >= 85 ? 'text-emerald-600' : item.score >= 70 ? 'text-amber-500' : 'text-red-600'
                    const canEdit = canUserEdit(item)

                    return (
                      <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex flex-col">
                            <span className="text-sm font-semibold text-gray-900">{formatDateLA(item.checklist_date || item.created_at)}</span>
                            <span className="text-xs text-gray-400 font-bold uppercase">{item.shift} | {item.start_time}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm font-bold text-gray-700 uppercase">{item.store_name}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm text-gray-600 font-medium">{item.manager_real_name}</span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <span className={`text-lg font-bold ${scoreColor}`}>{item.score}%</span>
                            <div className="w-12 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <div className={`h-full ${scoreColor.replace('text', 'bg')} rounded-full`} style={{ width: `${item.score}%` }}></div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-center">
                          {getStatusBadge(item)}
                        </td>
                        <td className="px-6 py-4 text-right">
                          {canEdit ? (
                            <button
                              onClick={() => handleEdit(item)}
                              className="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg text-xs font-bold hover:bg-red-600 hover:text-white transition-all"
                            >
                              ✏️ Editar
                            </button>
                          ) : (
                            <span className="text-[10px] text-gray-300 font-bold uppercase tracking-wider">Cerrado</span>
                          )}
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {showReviewModal && user && (
        <ReviewModal
          isOpen={showReviewModal}
          onClose={() => setShowReviewModal(false)}
          checklists={checklists}
          checklistType="manager"
          currentUser={{
            id: user.id,
            name: user.name || user.email,
            email: user.email,
            role: user.role
          }}
          onSave={() => {
            setShowReviewModal(false)
            fetchData()
          }}
        />
      )}
    </div>
  )
}

export default function ManagerChecklistsPage() {
  return <ManagerChecklistsContent />
}
