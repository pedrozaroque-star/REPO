'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'
import { supabase } from '@/lib/supabase'

export default function NewManagerChecklistPage() {
    const router = useRouter()
    const { user } = useAuth()
    const [loading, setLoading] = useState(false)
    const [storeId, setStoreId] = useState('')
    const [stores, setStores] = useState<any[]>([])
    const [answers, setAnswers] = useState<Record<string, any>>({})

    useEffect(() => {
        fetchStores()
    }, [])

    const fetchStores = async () => {
        const { data } = await supabase.from('stores').select('*').order('name')
        if (data) setStores(data)
    }

    // Simplified Sections Logic (since we don't have the original 53 questions file)
    const sections = [
        {
            title: 'Cookline and Kitchen',
            questions: [
                'Higiene personal y uniformes completos',
                'Temperaturas de equipos en rango',
                'Limpieza de estaciones de trabajo',
                'Rotación de producto (FIFO)',
                'Tiempos de cocción correctos'
            ]
        },
        {
            title: 'Dining Room & Guest Areas',
            questions: [
                'Mesas y sillas limpias y ordenadas',
                'Estación de bebidas surtida y limpia',
                'Baños limpios y con suministros',
                'Música ambiental a volumen adecuado',
                'Iluminación funcionando correctamente'
            ]
        },
        {
            title: 'Service & Speed',
            questions: [
                'Tiempos de entrega < 5 mins',
                'Saludo amable al cliente',
                'Precisión en los pedidos',
                'Manejo de quejas adecuado'
            ]
        },
        {
            title: 'Checklist and Reports',
            questions: [
                'Checklists de asistentes completados',
                'Reporte de ventas enviado',
                'Bitácora de mantenimiento actualizada'
            ]
        }
    ]

    const calculateScore = () => {
        const total = sections.reduce((acc, s) => acc + s.questions.length, 0)
        const yesCount = Object.values(answers).filter(v => v === 'SI').length
        return Math.round((yesCount / total) * 100)
    }

    const handleSubmit = async () => {
        if (!user || !storeId) return
        setLoading(true)

        const score = calculateScore()

        try {
            const { error } = await supabase.from('manager_checklists').insert({
                store_id: parseInt(storeId),
                user_id: user.id,
                manager_name: (user as any).name || user.email,
                checklist_date: new Date().toISOString().split('T')[0],
                answers: answers,
                score: score,
                estatus_supervisor: 'pendiente',
                estatus_admin: 'pendiente'
            })

            if (error) throw error
            router.push('/checklists-manager')
        } catch (err) {
            alert('Error: ' + (err as any).message)
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-8">
                <button onClick={() => router.back()} className="text-gray-400 hover:text-gray-900">← Volver</button>
                <h1 className="text-2xl font-bold text-gray-900">Nuevo Checklist Gerencial</h1>
            </div>

            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
                {/* Store Select */}
                <div className="mb-8">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Seleccionar Tienda</label>
                    <select
                        value={storeId}
                        onChange={(e) => setStoreId(e.target.value)}
                        className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gray-900 outline-none"
                    >
                        <option value="">-- Elige una tienda --</option>
                        {stores.map(s => (
                            <option key={s.id} value={s.id}>{s.name}</option>
                        ))}
                    </select>
                </div>

                {/* Questions Sections */}
                <div className="space-y-10">
                    {sections.map((section, idx) => (
                        <div key={idx}>
                            <h3 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-2 mb-4">{section.title}</h3>
                            <div className="space-y-3">
                                {section.questions.map((q) => (
                                    <div key={q} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                                        <span className="text-gray-700 font-medium">{q}</span>
                                        <div className="flex gap-2">
                                            {['SI', 'NO', 'N/A'].map(opt => (
                                                <label key={opt} className={`
                           px-3 py-1 rounded-md text-sm font-bold cursor-pointer transition-all border
                           ${answers[q] === opt
                                                        ? (opt === 'SI' ? 'bg-green-600 text-white border-green-600' : opt === 'NO' ? 'bg-red-600 text-white border-red-600' : 'bg-gray-600 text-white border-gray-600')
                                                        : 'bg-white text-gray-500 border-gray-200 hover:border-gray-400'}
                         `}>
                                                    <input
                                                        type="radio"
                                                        name={q}
                                                        value={opt}
                                                        checked={answers[q] === opt}
                                                        onChange={() => setAnswers({ ...answers, [q]: opt })}
                                                        className="hidden"
                                                    />
                                                    {opt}
                                                </label>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>

                {/* Footer Actions */}
                <div className="mt-10 pt-6 border-t border-gray-100 flex items-center justify-between">
                    <div className="text-sm text-gray-500">
                        Preguntas contestadas: {Object.keys(answers).length} / {sections.reduce((acc, s) => acc + s.questions.length, 0)}
                    </div>
                    <button
                        onClick={handleSubmit}
                        disabled={loading || !storeId}
                        className="px-8 py-3 bg-gray-900 text-white font-bold rounded-xl hover:bg-black transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {loading ? 'Guardando...' : 'Finalizar Revisión'}
                    </button>
                </div>
            </div>
        </div>
    )
}
