'use client'

import { useEffect, useState } from 'react'
import AdminReviewModal from '@/components/AdminReviewModal'

interface Store {
    id: number | string
    name: string
}

interface StaffEvaluation {
    id: number
    evaluation_date: string
    evaluator_name: string
    evaluated_name: string
    evaluated_role: string
    desempeno_general: number
    comentarios: string
    stores?: {
        name: string
    }
}

function StaffEvaluationsContent() {
    const [evaluations, setEvaluations] = useState<StaffEvaluation[]>([])
    const [loading, setLoading] = useState(true)
    const [stores, setStores] = useState<Store[]>([])
    const [storeFilter, setStoreFilter] = useState('all')
    const [roleFilter, setRoleFilter] = useState('all')

    // Modal State
    const [selectedEvaluation, setSelectedEvaluation] = useState<StaffEvaluation | null>(null)
    const [isModalOpen, setIsModalOpen] = useState(false)

    const roles = ['Cajero(a)', 'Cocinero', 'Shift Leader', 'Asistente', 'Manager', 'Supervisor']

    const fetchData = async () => {
        try {
            const url = process.env.NEXT_PUBLIC_SUPABASE_URL
            const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
            if (!url || !key) return

            // Tiendas
            const sRes = await fetch(`${url}/rest/v1/stores?select=id,name&order=name.asc`, {
                headers: { 'apikey': key, 'Authorization': `Bearer ${key}` } as HeadersInit
            })
            setStores(await sRes.json())

            // Evaluaciones
            let eUrl = `${url}/rest/v1/staff_evaluations?select=*,stores(name)&order=evaluation_date.desc&limit=50`
            if (storeFilter !== 'all') eUrl += `&store_id=eq.${storeFilter}`
            if (roleFilter !== 'all') eUrl += `&evaluated_role=eq.${roleFilter}`

            const eRes = await fetch(eUrl, {
                headers: { 'apikey': key, 'Authorization': `Bearer ${key}` } as HeadersInit
            })
            setEvaluations(await eRes.json())
            setLoading(false)
        } catch (err) {
            console.error(err)
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchData()
    }, [storeFilter, roleFilter])

    const getScoreColor = (score: number) => {
        if (score >= 9) return 'text-green-600'
        if (score >= 7) return 'text-yellow-600'
        return 'text-red-600'
    }

    const getStatusBadge = (status: string) => {
        const styles = {
            pending: 'bg-gray-100 text-gray-600',
            reviewed: 'bg-green-100 text-green-700',
            action_required: 'bg-red-100 text-red-700'
        }
        const labels = {
            pending: 'Pendiente',
            reviewed: 'Revisado',
            action_required: 'Acción Req.'
        }
        const key = status as keyof typeof styles || 'pending'
        return (
            <span className={`px-2 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${styles[key]}`}>
                {labels[key]}
            </span>
        )
    }

    const openReview = (ev: StaffEvaluation) => {
        setSelectedEvaluation(ev)
        setIsModalOpen(true)
    }

    if (loading) {
        return (
            <div className="flex-1 flex items-center justify-center p-20">
                <p className="text-gray-500 font-bold uppercase tracking-widest text-xs">Cargando evaluaciones...</p>
            </div>
        )
    }

    return (
        <div className="p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-8 flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Evaluaciones de Staff</h1>
                        <p className="text-gray-600 mt-2">Revisión y seguimiento de cumplimiento del equipo operativo.</p>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex gap-4">
                    <div className="flex-1">
                        <label className="block text-[9px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">Unidad de Negocio</label>
                        <select
                            value={storeFilter}
                            onChange={e => setStoreFilter(e.target.value)}
                            className="w-full bg-gray-50 border-0 rounded-xl p-3 text-xs font-black uppercase tracking-wider text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none cursor-pointer"
                        >
                            <option value="all">Todas las Sedes</option>
                            {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                        </select>
                    </div>
                    <div className="flex-1">
                        <label className="block text-[9px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">Rol Operativo</label>
                        <select
                            value={roleFilter}
                            onChange={e => setRoleFilter(e.target.value)}
                            className="w-full bg-gray-50 border-0 rounded-xl p-3 text-xs font-black uppercase tracking-wider text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none cursor-pointer"
                        >
                            <option value="all">Todos los Perfiles</option>
                            {roles.map(r => <option key={r} value={r}>{r}</option>)}
                        </select>
                    </div>
                </div>

                <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden mb-10">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-gray-50/50">
                                    <th className="px-8 py-5 text-[9px] font-black text-gray-400 uppercase tracking-widest">Estatus</th>
                                    <th className="px-8 py-5 text-[9px] font-black text-gray-400 uppercase tracking-widest">Fecha</th>
                                    <th className="px-8 py-5 text-[9px] font-black text-gray-400 uppercase tracking-widest">Colaborador</th>
                                    <th className="px-8 py-5 text-[9px] font-black text-gray-400 uppercase tracking-widest">Cargo</th>
                                    <th className="px-8 py-5 text-[9px] font-black text-gray-400 uppercase tracking-widest">Tienda</th>
                                    <th className="px-8 py-5 text-[9px] font-black text-gray-400 uppercase tracking-widest">Evaluador</th>
                                    <th className="px-8 py-5 text-[9px] font-black text-gray-400 uppercase tracking-widest text-right">Resultado</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50">
                                {evaluations.map(ev => (
                                    <tr
                                        key={ev.id}
                                        className="hover:bg-gray-50 cursor-pointer transition-colors group"
                                        onClick={() => openReview(ev)}
                                    >
                                        <td className="px-8 py-6">
                                            {getStatusBadge((ev as any).review_status)}
                                        </td>
                                        <td className="px-8 py-6 text-[13px] text-gray-500 font-medium">
                                            {new Date(ev.evaluation_date).toLocaleDateString('es-MX', { day: '2-digit', month: 'short' })}
                                        </td>
                                        <td className="px-8 py-6">
                                            <span className="font-black text-gray-900 group-hover:text-[#e31837] tracking-tight uppercase italic transition-colors">
                                                {ev.evaluated_name}
                                            </span>
                                        </td>
                                        <td className="px-8 py-6">
                                            <span className="text-[10px] font-black text-gray-500 bg-gray-100 rounded-lg px-2.5 py-1 uppercase tracking-tighter">
                                                {ev.evaluated_role}
                                            </span>
                                        </td>
                                        <td className="px-8 py-6 text-xs font-bold text-gray-400 uppercase tracking-tight">{ev.stores?.name}</td>
                                        <td className="px-8 py-6 text-xs text-gray-500 italic font-medium">{ev.evaluator_name || 'Anónimo'}</td>
                                        <td className="px-8 py-6 text-right">
                                            <span className={`text-xl font-black italic tabular-nums ${getScoreColor(ev.desempeno_general)}`}>
                                                {ev.desempeno_general}<span className="text-[10px] font-bold text-gray-300 ml-1 not-italic">/10</span>
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {/* Review Modal */}
            <AdminReviewModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                type="staff_evaluation"
                data={selectedEvaluation}
                onUpdate={fetchData}
            />
        </div>
    )
}

export default function StaffEvaluationsPage() {
    return <StaffEvaluationsContent />
}
