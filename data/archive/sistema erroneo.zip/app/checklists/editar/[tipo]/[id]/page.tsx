'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'
import { canEditChecklist } from '@/lib/checklistPermissions'
import { supabase } from '@/lib/supabase'
import ChecklistForm from '@/components/checklists/ChecklistForm' // ✅ Importamos el Universal

export default function EditChecklistPage() {
  const params = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const [checklist, setChecklist] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const tipo = params?.tipo as string
  const id = params?.id as string

  useEffect(() => {
    if (user && id) fetchChecklist()
  }, [user, id])

  if (!user) return null

  const fetchChecklist = async () => {
    try {
      const { data, error } = await supabase
        .from('assistant_checklists')
        .select('*')
        .eq('id', id)
        .single()

      if (error || !data) throw new Error('Checklist no encontrado')

      const dateToCheck = data.checklist_date || data.created_at
      const perms = canEditChecklist(
        dateToCheck,
        user.role,
        data.user_id,
        user.id,
        data.checklist_time,
        data.estatus_manager
      )

      if (!perms.canEdit) throw new Error(perms.reason)

      setChecklist(data)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  if (loading) return (
    <div className="flex h-[80vh] items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#e31837]"></div>
    </div>
  )

  if (error) return (
    <div className="flex h-[80vh] items-center justify-center flex-col animate-in fade-in duration-500">
      <div className="bg-white p-12 rounded-[2.5rem] border border-gray-100 shadow-sm text-center max-w-md">
        <div className="text-6xl mb-6">🔒</div>
        <h2 className="text-2xl font-black text-gray-900 tracking-tight mb-2">Acceso Denegado</h2>
        <p className="text-gray-500 font-medium mb-8 leading-relaxed">{error}</p>
        <button
          onClick={() => router.push('/checklists')}
          className="w-full bg-gray-900 text-white px-8 py-4 rounded-2xl font-black text-[11px] tracking-widest uppercase hover:bg-[#e31837] transition-all shadow-xl active:scale-95"
        >
          Volver al Historial
        </button>
      </div>
    </div>
  )

  return (
    <div className="p-8 lg:p-10 space-y-10 animate-in fade-in duration-700">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => router.back()}
          className="mb-8 px-5 py-2.5 bg-white border border-gray-100 text-gray-400 rounded-xl font-black text-[10px] tracking-widest uppercase transition-all hover:bg-gray-50 hover:text-gray-900 shadow-sm flex items-center gap-2"
        >
          ← Volver al listado
        </button>

        {/* Aviso de bloqueo por revisión 🔒 */}
        <div className="mb-8 p-5 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-4 animate-in slide-in-from-top duration-700">
          <div className="text-2xl mt-0.5">ℹ️</div>
          <div>
            <p className="text-sm font-bold text-amber-900 leading-snug">Nota sobre Edición</p>
            <p className="text-xs font-medium text-amber-700 mt-1 leading-relaxed">
              Este registro se bloqueará permanentemente una vez que sea revisado por un Manager o Supervisor.
              Asegúrate de que toda la información sea correcta antes de que sea validada.
            </p>
          </div>
        </div>

        <ChecklistForm
          user={user}
          initialData={checklist}
          type={tipo}
        />
      </div>
    </div>
  )
}