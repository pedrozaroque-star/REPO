'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'
import ReviewModal from '@/components/ReviewModal'
import { canEditChecklist, getStatusColor, getStatusLabel, formatDateLA } from '@/lib/checklistPermissions'

function ChecklistsContent() {
  const router = useRouter()
  const { user } = useAuth()
  const [checklists, setChecklists] = useState<any[]>([])
  const [stats, setStats] = useState({
    total: 0,
    daily: 0,
    temperaturas: 0,
    sobrante: 0,
    recorrido: 0,
    cierre: 0,
    apertura: 0
  })
  const [loading, setLoading] = useState(true)
  const [typeFilter, setTypeFilter] = useState('all')
  const [storeFilter, setStoreFilter] = useState('all')
  const [stores, setStores] = useState<any[]>([])
  const [showReviewModal, setShowReviewModal] = useState(false)

  useEffect(() => {
    if (user) {
      fetchStores()
    }
  }, [user])

  useEffect(() => {
    if (user && stores.length > 0) {
      fetchData()
    }
  }, [typeFilter, storeFilter, user, stores])

  const fetchStores = async () => {
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      const res = await fetch(`${url}/rest/v1/stores?select=*`, {
        headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` }
      })
      const data = await res.json()
      let loadedStores = Array.isArray(data) ? data : []

      const userScope = (user as any)?.store_scope
      if (user?.role === 'asistente' && Array.isArray(userScope) && userScope.length > 0) {
        loadedStores = loadedStores.filter(s => userScope.includes(s.code) || userScope.includes(s.name))
      }

      setStores(loadedStores)
    } catch (err) {
      console.error('Error tiendas:', err)
    }
  }

  const fetchData = async () => {
    if (!user) return
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      let checkUrl = `${url}/rest/v1/assistant_checklists?select=*,stores(name,code),users!user_id(full_name)&order=checklist_date.desc,created_at.desc&limit=100`

      if (typeFilter !== 'all') {
        checkUrl += `&checklist_type=eq.${typeFilter}`
      }
      if (storeFilter !== 'all') {
        checkUrl += `&store_id=eq.${storeFilter}`
      }

      const userScope = (user as any)?.store_scope

      const role = user?.role?.toLowerCase()
      if (role === 'asistente' || role === 'manager' || role === 'gerente' || role === 'supervisor') {
        if (Array.isArray(userScope) && userScope.length > 0) {
          const allowedStoreIds = stores
            .filter(s => userScope.includes(s.code) || userScope.includes(s.name))
            .map(s => s.id)

          if (allowedStoreIds.length > 0) {
            checkUrl += `&store_id=in.(${allowedStoreIds.join(',')})`
          } else {
            checkUrl += `&store_id=eq.0`
          }
        } else if (role === 'asistente') {
          checkUrl += `&store_id=eq.0`
        }

        if (role === 'asistente' && user?.id) {
          checkUrl += `&user_id=eq.${user.id}`
        }
      }

      const checkRes = await fetch(checkUrl, {
        headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` }
      })
      const checkData = await checkRes.json()

      const formattedData = Array.isArray(checkData) ? checkData.map(item => ({
        ...item,
        store_name: item.stores?.name || 'N/A'
      })) : []

      setChecklists(formattedData)

      let allCheckUrl = `${url}/rest/v1/assistant_checklists?select=checklist_type`
      if (user?.role === 'asistente' && Array.isArray(userScope) && userScope.length > 0) {
        const allowedStoreIds = stores
          .filter(s => userScope.includes(s.code) || userScope.includes(s.name))
          .map(s => s.id)

        if (allowedStoreIds.length > 0) {
          allCheckUrl += `&store_id=in.(${allowedStoreIds.join(',')})`
        }
        allCheckUrl += `&user_id=eq.${user.id}`
      }

      const allCheckRes = await fetch(allCheckUrl, {
        headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` }
      })
      const allChecks = await allCheckRes.json()
      const allChecksArray = Array.isArray(allChecks) ? allChecks : []

      setStats({
        total: allChecksArray.length,
        daily: allChecksArray.filter(c => c.checklist_type === 'daily').length,
        temperaturas: allChecksArray.filter(c => c.checklist_type === 'temperaturas').length,
        sobrante: allChecksArray.filter(c => c.checklist_type === 'sobrante').length,
        recorrido: allChecksArray.filter(c => c.checklist_type === 'recorrido').length,
        cierre: allChecksArray.filter(c => c.checklist_type === 'cierre').length,
        apertura: allChecksArray.filter(c => c.checklist_type === 'apertura').length
      })

      setLoading(false)
    } catch (err) {
      console.error('Error:', err)
      setLoading(false)
    }
  }

  const checklistTypes = [
    { value: 'daily', label: 'Daily Checklist', icon: '📝', color: 'border-blue-600' },
    { value: 'temperaturas', label: 'Temperaturas', icon: '🌡️', color: 'border-red-600' },
    { value: 'sobrante', label: 'Producto Sobrante', icon: '📦', color: 'border-yellow-600' },
    { value: 'recorrido', label: 'Recorrido', icon: '🚶', color: 'border-green-600' },
    { value: 'cierre', label: 'Cierre', icon: '🌙', color: 'border-purple-600' },
    { value: 'apertura', label: 'Apertura', icon: '🌅', color: 'border-orange-600' }
  ]

  const getTypeInfo = (type: string) => {
    return checklistTypes.find(t => t.value === type) || checklistTypes[0]
  }

  const getStatusBadge = (item: any) => {
    const status = item.estatus_manager || 'pendiente'
    const colorClass = getStatusColor(status)
    const label = getStatusLabel(status)

    return (
      <span className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border shadow-sm transition-all duration-500 scale-95 group-hover:scale-100 ${colorClass}`}>
        {label === 'RECIBIDO' ? '✓ REVISADO' : label === 'RECHAZADO' ? '⚠ RECHAZADO' : '● PENDIENTE'}
      </span>
    )
  }

  const handleEdit = (item: any) => {
    if (!user) return

    const editCheck = canEditChecklist(
      item.checklist_date || item.created_at,
      user.role,
      item.user_id,
      user.id,
      item.checklist_time,
      item.estatus_manager
    )

    if (!editCheck.canEdit) {
      alert(editCheck.reason)
      return
    }

    router.push(`/checklists/editar/${item.checklist_type}/${item.id}`)
  }

  const canUserEdit = (item: any) => {
    if (!user) return false
    const editCheck = canEditChecklist(
      item.checklist_date || item.created_at,
      user.role,
      item.user_id,
      user.id,
      item.checklist_time,
      item.estatus_manager
    )
    return editCheck.canEdit
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center p-20">
        <div className="text-center">
          <div className="text-6xl mb-4">📋</div>
          <p className="text-gray-400 font-black uppercase tracking-widest text-xs">Sincronizando checklists...</p>
        </div>
      </div>
    )
  }

  if (!user) return null

  return (
    <div className="p-6 h-full overflow-hidden flex flex-col">
      <div className="max-w-[94%] mx-auto w-full">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-6">
            <div className="w-16 h-16 rounded-2xl bg-gray-900 flex items-center justify-center shadow-lg">
              <span className="text-3xl">📋</span>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Bitácora Checklists</h1>
              <p className="text-gray-600 mt-1">Sincronización y log de cumplimiento de procesos.</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {checklists.length > 0 && (
              <button
                onClick={() => setShowReviewModal(true)}
                className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-all shadow-sm flex items-center gap-2"
              >
                ✓ Revisión Administrativa
              </button>
            )}
            <button
              onClick={() => router.push('/checklists/crear')}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-all shadow-sm flex items-center gap-2"
            >
              <span className="text-lg leading-none">+</span> Nuevo Checklist
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-8">
          {[
            { l: 'Total', v: stats.total, c: 'bg-gray-100', i: '📊' },
            { l: 'Daily', v: stats.daily, c: 'bg-blue-50', i: '📝' },
            { l: 'Temps', v: stats.temperaturas, c: 'bg-red-50', i: '🌡️' },
            { l: 'Sobrante', v: stats.sobrante, c: 'bg-yellow-50', i: '📦' },
            { l: 'Recorrido', v: stats.recorrido, c: 'bg-green-50', i: '🚶' },
            { l: 'Cierre', v: stats.cierre, c: 'bg-purple-50', i: '🌙' },
            { l: 'Apertura', v: stats.apertura, c: 'bg-orange-50', i: '🌅' }
          ].map((s, i) => (
            <div key={i} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm text-center">
              <span className="text-2xl mb-1 block">{s.i}</span>
              <p className="text-xs text-gray-500 uppercase font-bold truncate">{s.l}</p>
              <p className="text-2xl font-bold text-gray-900">{s.v}</p>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-wrap gap-6 items-center justify-between mb-8">
          <div className="flex items-center gap-6">
            <div className="relative">
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="appearance-none bg-gray-50 border border-gray-200 rounded-lg px-4 py-2 pr-10 text-sm font-medium text-gray-700 focus:ring-2 focus:ring-red-500 outline-none cursor-pointer"
              >
                <option value="all">Todos los Tipos</option>
                {checklistTypes.map(type => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </select>
              <span className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-xs">▼</span>
            </div>

            <div className="relative group">
              <select
                value={storeFilter}
                onChange={(e) => setStoreFilter(e.target.value)}
                className="appearance-none bg-slate-50 border border-slate-100 rounded-xl px-6 py-3 text-[11px] font-black uppercase tracking-[0.2em] text-slate-700 hover:bg-slate-100 transition-all outline-none cursor-pointer pr-12 font-jakarta shadow-inner"
              >
                <option value="all">GLOBAL (TODAS)</option>
                {stores.map(store => (
                  <option key={store.id} value={store.id}>{store.name.toUpperCase()}</option>
                ))}
              </select>
              <span className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-xs text-slate-400">▼</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest font-jakarta">Mostrando</span>
            <span className="px-4 py-2 bg-slate-900 text-white rounded-xl text-[12px] font-black font-outfit tabular-nums shadow-lg">{checklists.length}</span>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest font-jakarta">Registros</span>
          </div>
        </div>

        {/* Table Section */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100 mt-2 flex-1 flex flex-col min-h-0">
          <div className="overflow-y-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50 border-b border-gray-100 sticky top-0 z-10">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Fecha / Hora</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Categoría</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Sucursal</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Responsable</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-center">Estatus</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {checklists.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-gray-500 font-medium">
                      No se encontraron registros de checklists.
                    </td>
                  </tr>
                ) : (
                  checklists.map((item) => {
                    const typeInfo = getTypeInfo(item.checklist_type)
                    const canEdit = canUserEdit(item)
                    return (
                      <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex flex-col">
                            <span className="text-sm font-semibold text-gray-900">{formatDateLA(item.checklist_date || item.created_at)}</span>
                            <span className="text-xs text-gray-500">{item.checklist_time || item.start_time || '00:00'}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{typeInfo.icon}</span>
                            <span className="text-xs font-bold text-gray-700 uppercase tracking-wide">{typeInfo.label}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm text-gray-700 font-medium">{item.store_name}</span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-col">
                            <span className="text-sm text-gray-900 font-medium">{item.users?.full_name}</span>
                            <span className="text-[10px] text-gray-400 font-bold uppercase">{item.stores?.code}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-center">
                          {getStatusBadge(item)}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => router.push(`/checklists/ver/${item.checklist_type}/${item.id}`)}
                              className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                              title="Ver detalles"
                            >
                              👁️
                            </button>
                            {canEdit && (
                              <button
                                onClick={() => handleEdit(item)}
                                className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                                title="Editar"
                              >
                                ✏️
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {showReviewModal && user && (
        <ReviewModal
          isOpen={showReviewModal}
          onClose={() => setShowReviewModal(false)}
          checklists={checklists}
          checklistType="assistant"
          currentUser={{
            id: user.id,
            name: (user as any).name || user.email,
            email: user.email,
            role: user.role
          }}
          onSave={() => {
            setShowReviewModal(false)
            fetchData()
          }}
        />
      )}
    </div>
  )
}

export default function ChecklistsPage() {
  return <ChecklistsContent />
}