'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'
import '@/app/checklists/checklists.css'

interface Store {
  id: string
  name: string
}

const QUESTIONS = [
  'Todo el equipo alcanza la temperatura adecuada',
  'Cubeta roja de sanitizante bajo línea @ 200ppm',
  'Máquina de hielo limpia',
  'Área del trapeador limpia',
  'Microondas está limpio',
  'Estaciones de champurrado limpias',
  'Baño de empleados limpio',
  'Tanque de gas de refrescos lleno',
  'Checklists siendo usados',
  'Food Handler visible',
  'Se saluda a clientes dentro de 5 segundos',
  'Hacemos contacto visual con el cliente',
  'Ventanas limpias',
  'Baños limpios',
  'Estacionamiento limpio',
  'TVs funcionando',
  'Toda la iluminación funciona',
  'Mesas y sillas limpias',
  'Todas las luces funcionan',
  'Acero inoxidable limpio',
  'Rebanadoras y tijeras limpias',
  'Drenajes limpios',
  'Pisos y zócalos limpios',
  'Lavado de manos frecuente',
  'Área de escoba organizada',
  'Se utiliza FIFO',
  'Trapos en sanitizante',
  'Expedidor anuncia órdenes',
  'Cámaras funcionando',
  'SOS/DT Time visible',
  'Management consciente',
  'Manejo de efectivo correcto',
  'Reparaciones reportadas',
  'AC limpio'
]

export default function CierrePage() {
  const router = useRouter()
  const { user } = useAuth()
  const [stores, setStores] = useState<Store[]>([])
  const [loading, setLoading] = useState(false)
  const [showThanks, setShowThanks] = useState(false)

  const getLocalDate = () => {
    const now = new Date()
    const year = now.getFullYear()
    const month = String(now.getMonth() + 1).padStart(2, '0')
    const day = String(now.getDate()).padStart(2, '0')
    return `${year}-${month}-${day}`
  }

  const [formData, setFormData] = useState({
    store_id: '',
    checklist_date: getLocalDate(),
    start_time: new Date().toTimeString().slice(0, 5),
    shift: 'AM' as 'AM' | 'PM',
    comments: ''
  })

  const [answers, setAnswers] = useState<{ [key: number]: 'SI' | 'NO' | 'NA' | null }>({})

  useEffect(() => {
    if (user) {
      fetchStores()
    }
  }, [user])

  if (!user) return null

  const fetchStores = async () => {
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
      const res = await fetch(`${url}/rest/v1/stores?select=id,name,code&order=name.asc`, {
        headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` }
      })
      const data = await res.json()
      let loadedStores = Array.isArray(data) ? data : []

      const userScope = (user as any)?.store_scope
      if (user?.role === 'asistente' && Array.isArray(userScope) && userScope.length > 0) {
        loadedStores = loadedStores.filter(s => userScope.includes(s.code) || userScope.includes(s.name))
      }

      setStores(loadedStores)

      if (user?.role === 'asistente' && Array.isArray(userScope) && userScope.length > 0 && loadedStores.length > 0) {
        const myStoreId = loadedStores[0].id.toString()
        setFormData(prev => ({ ...prev, store_id: myStoreId }))
      }

    } catch (err) {
      console.error('Error:', err)
    }
  }

  const handleAnswer = (index: number, value: 'SI' | 'NO' | 'NA') => {
    setAnswers(prev => ({ ...prev, [index]: value }))
  }

  const calculateScore = (): number => {
    const values = Object.values(answers).filter(v => v !== null)
    const siCount = values.filter(v => v === 'SI').length
    if (values.length === 0) return 0
    return Math.round((siCount / values.length) * 100)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.store_id) {
      alert('Por favor selecciona una sucursal')
      return
    }

    if (Object.keys(answers).length < QUESTIONS.length) {
      alert(`Por favor responde TODAS las preguntas (${Object.keys(answers).length}/${QUESTIONS.length})`)
      return
    }

    setLoading(true)

    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
      const endTime = new Date().toTimeString().slice(0, 5)

      const payload = {
        store_id: parseInt(formData.store_id),
        user_id: user.id,
        assistant_name: user.name || user.email || 'Asistente',
        created_by: user.name || user.email || 'Asistente',
        checklist_type: 'daily',
        checklist_date: formData.checklist_date,
        start_time: formData.start_time,
        end_time: endTime,
        shift: formData.shift,
        answers: answers,
        score: calculateScore(),
        comments: formData.comments || null
      }

      const res = await fetch(`${url}/rest/v1/assistant_checklists`, {
        method: 'POST',
        headers: {
          'apikey': key || '',
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify(payload)
      })

      if (res.ok) {
        setShowThanks(true)
        setTimeout(() => router.push('/checklists'), 2000)
      } else {
        alert('Error al enviar. Intenta de nuevo.')
      }
    } catch (err) {
      console.error('Error:', err)
      alert('Error al enviar. Intenta de nuevo.')
    }

    setLoading(false)
  }

  if (showThanks) {
    return (
      <div className="flex h-[80vh] items-center justify-center flex-col animate-in zoom-in duration-500">
        <div className="bg-white p-12 rounded-[2.5rem] border border-gray-100 shadow-sm text-center max-w-md">
          <div className="text-7xl mb-6">✅</div>
          <h2 className="text-3xl font-black text-gray-900 tracking-tighter mb-2">¡Completado!</h2>
          <p className="text-gray-500 font-medium mb-8">Daily Checklist de Cierre enviado exitosamente.</p>
        </div>
      </div>
    )
  }

  const score = calculateScore()
  const answered = Object.keys(answers).length

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Modern Header */}
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.back()}
              className="w-10 h-10 rounded-xl bg-white border border-gray-200 flex items-center justify-center text-gray-400 hover:text-gray-900 hover:border-gray-900 transition-all"
            >
              ←
            </button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 tracking-tight border-b-4 border-[#e31837] inline-block pb-1">
                Checklist de Cierre
              </h1>
              <p className="text-sm font-medium text-gray-500 mt-2">Protocolo de seguridad e higiene</p>
            </div>
            <div className="text-right">
              <div className="text-right">
                <div className="text-3xl font-bold text-[#e31837]">{score}%</div>
                <div className="text-xs font-bold text-gray-400">Cumplimiento Actual</div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-10">
              <div className="bg-white rounded-[2.5rem] border border-gray-200 shadow-sm p-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-500 ml-1">Sucursal</label>
                    <select
                      required
                      value={formData.store_id}
                      onChange={(e) => setFormData({ ...formData, store_id: e.target.value })}
                      className="w-full px-5 py-4 bg-gray-50 border-0 rounded-2xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                    >
                      <option value="">Seleccionar Sucursal...</option>
                      {stores.map(store => <option key={store.id} value={store.id}>{store.name}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-500 ml-1">Fecha de Registro</label>
                      <input
                        type="date"
                        required
                        value={formData.checklist_date}
                        onChange={(e) => setFormData({ ...formData, checklist_date: e.target.value })}
                        className="w-full px-5 py-4 bg-gray-50 border-0 rounded-2xl text-sm font-bold text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Periodo / Turno</label>
                      <select
                        value={formData.shift}
                        onChange={(e) => setFormData({ ...formData, shift: e.target.value as 'AM' | 'PM' })}
                        className="w-full px-5 py-4 bg-gray-50 border-0 rounded-2xl text-sm font-bold text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                      >
                        <option value="AM">Mañana (AM)</option>
                        <option value="PM">Tarde (PM)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-[2.5rem] border border-gray-200 shadow-sm overflow-hidden">
                  <div className="p-8 border-b border-gray-50 bg-gray-50/30">
                    <h3 className="text-lg font-black text-gray-900 tracking-tight uppercase italic font-serif">Puntos de Verificación</h3>
                    <p className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em] mt-1">Protocolo de seguridad e higiene</p>
                  </div>

                  <div className="divide-y divide-gray-50">
                    {QUESTIONS.map((question, idx) => (
                      <div key={idx} className="p-6 hover:bg-gray-50/50 transition-colors flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                        <div className="flex-1 flex gap-4 items-start">
                          <span className="w-8 h-8 rounded-lg bg-gray-50 border border-gray-100 flex items-center justify-center text-[10px] font-black text-gray-400">{idx + 1}</span>
                          <p className="text-gray-700 font-bold text-[14px] leading-relaxed pt-1">{question}</p>
                        </div>

                        <div className="flex gap-2">
                          {['SI', 'NO', 'NA'].map(val => (
                            <button
                              key={val}
                              type="button"
                              onClick={() => handleAnswer(idx, val as any)}
                              className={`px-6 py-2.5 rounded-xl border text-[10px] font-black uppercase tracking-widest transition-all ${answers[idx] === val
                                ? val === 'SI' ? 'bg-emerald-50 border-emerald-200 text-emerald-600' : val === 'NO' ? 'bg-red-50 border-red-200 text-red-600' : 'bg-gray-200 border-gray-300 text-gray-700'
                                : 'bg-white border-gray-100 text-gray-400 hover:border-gray-300 hover:text-gray-600'
                                }`}
                            >
                              {val === 'SI' ? 'Cumple' : val === 'NO' ? 'No Cumple' : 'N/A'}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white rounded-[2.5rem] border border-gray-200 shadow-sm p-10 space-y-10">
                  <div className="space-y-6">
                    <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Observaciones Finales</h3>
                    <textarea
                      value={formData.comments}
                      onChange={(e) => setFormData({ ...formData, comments: e.target.value })}
                      rows={4}
                      className="w-full px-6 py-4 bg-gray-50 border-0 rounded-3xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none resize-none"
                      placeholder="Detalla cualquier incidencia o comentario relevante sobre el cierre..."
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gray-900 text-white py-5 rounded-2xl font-black text-[12px] tracking-[0.2em] uppercase transition-all hover:bg-[#e31837] active:scale-95 shadow-xl disabled:bg-gray-300 flex items-center justify-center gap-4"
                  >
                    {loading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        Sincronizando...
                      </>
                    ) : (
                      'Finalizar y Registrar Cierre'
                    )}
                  </button>
                </div>
            </form>
          </div>
        </div>
        )
}