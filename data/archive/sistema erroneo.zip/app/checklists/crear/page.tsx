'use client'

import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'

export default function CrearChecklistPage() {
  const router = useRouter()
  const { user } = useAuth()

  const checklistTypes = [
    { id: 'daily', label: 'Checklist Diario', icon: '📋', color: 'bg-blue-500' },
    { id: 'temperaturas', label: 'Control de Temperaturas', icon: '🌡️', color: 'bg-red-500' },
    { id: 'sobrante', label: 'Producto Sobrante', icon: '📦', color: 'bg-green-500' },
    { id: 'recorrido', label: 'Recorrido de Turno', icon: '🚶', color: 'bg-purple-500' },
    { id: 'apertura', label: 'Apertura de Tienda', icon: '🌅', color: 'bg-orange-500' },
    { id: 'cierre', label: 'Cierre de Tienda', icon: '🌙', color: 'bg-indigo-500' }
  ]

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Nuevo Checklist</h1>
        <p className="text-gray-500 mt-2">Selecciona el tipo de reporte que deseas realizar.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {checklistTypes.map((type) => (
          <button
            key={type.id}
            onClick={() => router.push(`/checklists/crear/${type.id}`)}
            className="group flex flex-col items-center justify-center p-8 bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md hover:border-gray-200 transition-all text-center"
          >
            <div className={`w-16 h-16 ${type.color} rounded-2xl flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition-transform shadow-lg shadow-gray-200`}>
              {type.icon}
            </div>
            <h3 className="text-lg font-bold text-gray-900">{type.label}</h3>
            <span className="text-sm text-gray-400 mt-2 bg-gray-50 px-3 py-1 rounded-full group-hover:bg-gray-100">
              Iniciar reporte →
            </span>
          </button>
        ))}
      </div>
    </div>
  )
}
