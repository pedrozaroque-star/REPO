'use client'

import { useState, useEffect } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'
import { supabase } from '@/lib/supabase'

export default function DynamicChecklistForm() {
    const router = useRouter()
    const params = useParams()
    const { user } = useAuth()
    const type = params.type as string
    const [loading, setLoading] = useState(false)
    const [storeId, setStoreId] = useState('')
    const [stores, setStores] = useState<any[]>([])

    // Dynamic fields state
    const [answers, setAnswers] = useState<Record<string, any>>({})
    const [comments, setComments] = useState('')

    useEffect(() => {
        fetchStores()
    }, [])

    const fetchStores = async () => {
        const { data } = await supabase.from('stores').select('*').order('name')
        if (data) setStores(data)
    }

    const getQuestions = (type: string) => {
        switch (type) {
            case 'temperaturas':
                return [
                    { id: 'temp_walkin', label: 'Walk-in Cooler (°F)', type: 'number' },
                    { id: 'temp_freezer', label: 'Walk-in Freezer (°F)', type: 'number' },
                    { id: 'temp_line', label: 'Línea de Servicio (°F)', type: 'number' },
                    { id: 'temp_grill', label: 'Parrilla (°F)', type: 'number' }
                ]
            case 'sobrante':
                return [
                    { id: 'waste_meat', label: 'Carne (Lbs)', type: 'number' },
                    { id: 'waste_chicken', label: 'Pollo (Lbs)', type: 'number' },
                    { id: 'waste_rice', label: 'Arroz (Lbs)', type: 'number' },
                    { id: 'waste_beans', label: 'Frijoles (Lbs)', type: 'number' }
                ]
            default: // daily, recorrido, apertura, cierre
                return [
                    { id: 'clean_floors', label: 'Pisos limpios y secos', type: 'yesno' },
                    { id: 'trash_empty', label: 'Botes de basura vacíos', type: 'yesno' },
                    { id: 'staff_uniform', label: 'Personal con uniforme completo', type: 'yesno' },
                    { id: 'food_safe', label: 'Alimentos a temperatura segura', type: 'yesno' },
                    { id: 'restrooms', label: 'Baños limpios y surtidos', type: 'yesno' }
                ]
        }
    }

    const questions = getQuestions(type)

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        if (!user || !storeId) return

        setLoading(true)
        try {
            const { error } = await supabase.from('assistant_checklists').insert({
                checklist_type: type,
                store_id: parseInt(storeId),
                user_id: user.id,
                created_by: (user as any).name || user.email,
                checklist_date: new Date().toISOString().split('T')[0],
                answers: answers,
                comments: comments,
                score: calculateScore(),
                shift: new Date().getHours() < 12 ? 'AM' : 'PM',
                start_time: new Date().toLocaleTimeString(),
                end_time: new Date().toLocaleTimeString()
            })

            if (error) throw error
            router.push('/checklists')
        } catch (err) {
            alert('Error al guardar: ' + (err as any).message)
        } finally {
            setLoading(false)
        }
    }

    const calculateScore = () => {
        // Logic simple para demo, se puede mejorar
        const total = questions.length
        if (total === 0) return 100
        const yesCount = Object.values(answers).filter(v => v === 'SI' || v === true).length
        return Math.round((yesCount / total) * 100)
    }

    const getTitle = () => {
        const types: any = {
            daily: 'Checklist Diario',
            temperaturas: 'Control de Temperaturas',
            sobrante: 'Producto Sobrante',
            recorrido: 'Recorrido de Turno',
            apertura: 'Apertura',
            cierre: 'Cierre'
        }
        return types[type] || 'Nuevo Checklist'
    }

    return (
        <div className="p-6 max-w-3xl mx-auto">
            <div className="flex items-center gap-4 mb-8">
                <button onClick={() => router.back()} className="text-gray-400 hover:text-gray-900">← Volver</button>
                <h1 className="text-2xl font-bold text-gray-900">{getTitle()}</h1>
            </div>

            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                <form onSubmit={handleSubmit} className="space-y-6">

                    {/* Store Selector */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Tienda</label>
                        <select
                            value={storeId}
                            onChange={(e) => setStoreId(e.target.value)}
                            className="w-full p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                            required
                        >
                            <option value="">Selecciona una tienda...</option>
                            {stores.map(s => (
                                <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                            ))}
                        </select>
                    </div>

                    {/* Questions */}
                    <div className="space-y-4">
                        {questions.map((q) => (
                            <div key={q.id} className="bg-gray-50 p-4 rounded-xl">
                                <label className="block text-base font-medium text-gray-900 mb-2">{q.label}</label>

                                {q.type === 'yesno' ? (
                                    <div className="flex gap-4">
                                        {['SI', 'NO', 'N/A'].map((opt) => (
                                            <label key={opt} className={`
                        flex-1 py-2 text-center rounded-lg cursor-pointer transition-all border
                        ${answers[q.id] === opt
                                                    ? 'bg-gray-900 text-white border-gray-900'
                                                    : 'bg-white text-gray-700 border-gray-200 hover:border-gray-400'}
                      `}>
                                                <input
                                                    type="radio"
                                                    name={q.id}
                                                    value={opt}
                                                    onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
                                                    className="hidden"
                                                />
                                                {opt}
                                            </label>
                                        ))}
                                    </div>
                                ) : (
                                    <input
                                        type="number"
                                        className="w-full p-2 border border-gray-200 rounded-lg"
                                        placeholder="Ingrese valor..."
                                        onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
                                    />
                                )}
                            </div>
                        ))}
                    </div>

                    {/* Comments */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Comentarios Adicionales</label>
                        <textarea
                            value={comments}
                            onChange={(e) => setComments(e.target.value)}
                            className="w-full p-3 border border-gray-200 rounded-lg h-24"
                            placeholder="Observaciones..."
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full py-4 bg-[#e31837] text-white font-bold rounded-xl shadow-lg hover:bg-red-700 transition-all"
                    >
                        {loading ? 'Guardando...' : 'Guardar Checklist'}
                    </button>

                </form>
            </div>
        </div>
    )
}
