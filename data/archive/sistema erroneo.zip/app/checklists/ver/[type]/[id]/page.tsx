'use client'

import { useState, useEffect } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import { getStatusLabel, getStatusColor } from '@/lib/checklistPermissions'

export default function ChecklistDetailsPage() {
    const router = useRouter()
    const params = useParams()
    const [checklist, setChecklist] = useState<any>(null)
    const [loading, setLoading] = useState(true)
    const [activeTab, setActiveTab] = useState('respuestas') // respuestas, fotos, revisiones

    useEffect(() => {
        fetchChecklist()
    }, [])

    const fetchChecklist = async () => {
        const { data, error } = await supabase
            .from('assistant_checklists')
            .select(`
        *,
        stores (name, code),
        users (full_name)
      `)
            .eq('id', params.id)
            .single()

        if (data) setChecklist(data)
        setLoading(false)
    }

    if (loading) return <div className="p-10 text-center">Cargando detalles...</div>
    if (!checklist) return <div className="p-10 text-center">Checklist no encontrado</div>

    const statusColor = getStatusColor(checklist.estatus_manager)

    return (
        <div className="p-6 max-w-5xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                    <button onClick={() => router.back()} className="text-gray-400 hover:text-gray-900">← Volver</button>
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900 capitalize">{checklist.checklist_type} checklist</h1>
                        <p className="text-gray-500">{checklist.stores?.name} - {new Date(checklist.checklist_date).toLocaleDateString()}</p>
                    </div>
                </div>
                <div className={`px-4 py-2 rounded-lg ${statusColor} bg-opacity-10 border border-current`}>
                    <span className={`font-bold uppercase ${statusColor.replace('bg-', 'text-')}`}>
                        {getStatusLabel(checklist.estatus_manager)}
                    </span>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-6 border-b border-gray-200 mb-6">
                {['Respuestas', 'Fotos', 'Revisiones'].map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab.toLowerCase())}
                        className={`pb-3 px-2 font-medium transition-all ${activeTab === tab.toLowerCase()
                                ? 'text-[#e31837] border-b-2 border-[#e31837]'
                                : 'text-gray-400 hover:text-gray-600'
                            }`}
                    >
                        {tab}
                    </button>
                ))}
            </div>

            {/* Content */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                {activeTab === 'respuestas' && (
                    <div className="space-y-4">
                        {Object.entries(checklist.answers || {}).map(([key, value]: [string, any]) => (
                            <div key={key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                                <span className="font-medium text-gray-700 capitalize">{key.replace(/_/g, ' ')}</span>
                                <span className="font-bold text-gray-900">{value.toString()}</span>
                            </div>
                        ))}
                        {(!checklist.answers || Object.keys(checklist.answers).length === 0) && (
                            <p className="text-gray-400 text-center py-10">No hay respuestas registradas.</p>
                        )}
                    </div>
                )}

                {activeTab === 'fotos' && (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {/* Logic for displaying photos would go here */}
                        <p className="col-span-full text-center text-gray-400 py-10">
                            No hay fotos adjuntas en este reporte.
                        </p>
                    </div>
                )}

                {activeTab === 'revisiones' && (
                    <div className="space-y-6">
                        <div className="border-l-2 border-gray-200 pl-4 py-2">
                            <p className="text-sm text-gray-500">Creado por</p>
                            <p className="font-medium">{checklist.users?.full_name || checklist.created_by}</p>
                            <p className="text-xs text-gray-400">{new Date(checklist.created_at).toLocaleString()}</p>
                        </div>
                        {/* Here we would map over a 'reviews' table or jsonb field if it existed */}
                    </div>
                )}
            </div>
        </div>
    )
}
