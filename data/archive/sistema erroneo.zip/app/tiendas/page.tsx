'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import LoadingScreen from '@/components/LoadingScreen'

function TiendasContent() {
  const [stores, setStores] = useState<any[]>([])
  const [storesWithStats, setStoresWithStats] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedStore, setSelectedStore] = useState<any>(null)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)

      const { data: storesData } = await supabase.from('stores').select('*').order('name', { ascending: true })
      setStores(Array.isArray(storesData) ? storesData : [])

      const storesWithStatsPromises = (Array.isArray(storesData) ? storesData : []).map(async (store) => {
        const [feedbackRes, inspRes, checkRes] = await Promise.all([
          supabase.from('customer_feedback').select('nps_score').eq('store_id', store.id),
          supabase.from('supervisor_inspections').select('overall_score').eq('store_id', store.id),
          supabase.from('assistant_checklists').select('id', { count: 'exact' }).eq('store_id', store.id)
        ])

        const feedbacks = feedbackRes.data || []
        const inspections = inspRes.data || []
        const checklistCount = checkRes.count || 0

        const avgNPS = feedbacks.length > 0
          ? Math.round(feedbacks.reduce((sum, f) => sum + (f.nps_score || 0), 0) / feedbacks.length)
          : 0

        const avgInspection = inspections.length > 0
          ? Math.round(inspections.reduce((sum, i) => sum + (i.overall_score || 0), 0) / inspections.length)
          : 0

        return {
          ...store,
          stats: {
            feedbackCount: feedbacks.length,
            inspectionCount: inspections.length,
            checklistCount,
            avgNPS,
            avgInspection
          }
        }
      })

      const storesWithStatsData = await Promise.all(storesWithStatsPromises)
      setStoresWithStats(storesWithStatsData)

      setLoading(false)
    } catch (err) {
      console.error('Error:', err)
      setLoading(false)
    }
  }

  const filteredStores = storesWithStats.filter(store =>
    store.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.city?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (loading) {
    return <LoadingScreen message="Mapeando Unidades Operativas..." />
  }

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 items-center justify-between hidden md:flex">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Red de Sucursales</h1>
            <p className="text-gray-600 mt-2">Control operativo y supervisión de unidades de negocio.</p>
          </div>
        </div>

        {/* Mobile Header */}
        <div className="mb-8 md:hidden">
          <h1 className="text-2xl font-bold text-gray-900">Red de Sucursales</h1>
          <p className="text-gray-600 mt-1 text-sm">Control operativo y supervisión.</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          {[
            { label: 'Unidades Totales', val: stores.length, gradient: 'from-red-600 to-red-700', icon: '🏪' },
            { label: 'Sucursales Activas', val: stores.filter(s => s.is_active).length, gradient: 'from-emerald-500 to-emerald-600', icon: '🚀' },
            { label: 'Voz del Cliente', val: storesWithStats.reduce((sum, s) => sum + (s.stats?.feedbackCount || 0), 0), gradient: 'from-amber-500 to-amber-600', icon: '💬' },
            { label: 'Control Mensual', val: storesWithStats.reduce((sum, s) => sum + (s.stats?.checklistCount || 0), 0), gradient: 'from-gray-700 to-gray-800', icon: '✅' }
          ].map((s, i) => (
            <div key={i} className="bg-white p-7 rounded-3xl border border-gray-100 shadow-sm">
              <div className="flex items-center justify-between mb-3 text-xl">{s.icon}</div>
              <p className="text-xs font-bold text-gray-500">{s.label}</p>
              <p className="text-3xl font-bold text-gray-900 mt-1 tracking-tight">{s.val}</p>
            </div>
          ))}
        </div>

        {/* Search Bar - Solid Style */}
        <div className="bg-white p-2 rounded-2xl border border-gray-200 shadow-sm flex items-center gap-4">
          <div className="flex-1 relative">
            <span className="absolute left-5 top-1/2 -translate-y-1/2 text-xl opacity-20">🔍</span>
            <input
              type="text"
              placeholder="Filtrar por nombre de unidad, código comercial o ubicación geográfica..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-14 pr-6 py-3.5 bg-gray-50 border-0 rounded-xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
            />
          </div>
        </div>

        {/* Stores Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStores.map((store) => (
            <div
              key={store.id}
              className={`bg-white rounded-[2rem] border border-gray-100 shadow-sm transition-all duration-300 overflow-hidden flex flex-col
                ${!store.is_active ? 'opacity-60 grayscale' : 'hover:border-[#e31837]/30 hover:shadow-md'}
              `}
            >
              <div className="p-8 flex-1">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-xs font-bold text-[#e31837] bg-red-50 px-2 py-0.5 rounded border border-red-100 tracking-tight">COD: {store.code}</span>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 tracking-tight truncate">
                      {store.name}
                    </h3>
                    <p className="text-xs font-medium text-gray-500 flex items-center gap-1.5 mt-1">
                      <span className="w-1.5 h-1.5 bg-gray-300 rounded-full"></span> {store.city}, {store.state}
                    </p>
                  </div>
                  <div className={`px-2.5 py-1 rounded text-xs font-bold tracking-wide border ${store.is_active
                    ? 'bg-emerald-50 border-emerald-100 text-emerald-600'
                    : 'bg-red-50 border-red-100 text-red-600'
                    }`}>
                    {store.is_active ? 'Activa' : 'Inactiva'}
                  </div>
                </div>

                {/* Location Info */}
                <div className="mb-6 bg-gray-50/50 rounded-2xl p-4 border border-gray-100 space-y-2.5">
                  <div className="flex items-start gap-3 text-sm text-gray-600 font-medium">
                    <span className="w-5 text-center grayscale opacity-50">📍</span>
                    <p className="leading-tight italic">{store.address}</p>
                  </div>
                  {store.phone && (
                    <div className="flex items-center gap-3 text-sm text-gray-600 font-medium">
                      <span className="w-5 text-center grayscale opacity-50">📞</span>
                      <p>{store.phone}</p>
                    </div>
                  )}
                </div>

                {/* Supervisor Indicator */}
                {store.supervisor_name && (
                  <div className="mb-6 flex items-center gap-3 px-1">
                    <div className="w-8 h-8 rounded-lg bg-gray-900 flex items-center justify-center text-white font-bold text-xs">
                      {store.supervisor_name[0]}
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 font-semibold">Resp. Unidad</p>
                      <p className="text-sm font-bold text-gray-900 capitalize">
                        {store.supervisor_name.toLowerCase()}
                      </p>
                    </div>
                  </div>
                )}

                {/* Performance Metrics Bar */}
                <div className="grid grid-cols-2 gap-3 mb-8">
                  <div className="bg-white border border-gray-100 rounded-xl p-4 text-center">
                    <p className="text-xs font-bold text-gray-500 mb-1.5">Índice NPS</p>
                    <div className="flex items-center justify-center gap-2">
                      <p className="text-xl font-bold text-gray-900 tracking-tight font-serif">
                        {store.stats?.avgNPS || 0}
                      </p>
                      <div className={`w-1.5 h-1.5 rounded-full ${store.stats?.avgNPS >= 50 ? 'bg-emerald-500' : 'bg-amber-500'}`}></div>
                    </div>
                  </div>
                  <div className="bg-white border border-gray-100 rounded-xl p-4 text-center">
                    <p className="text-xs font-bold text-gray-500 mb-1.5">Auditoría</p>
                    <div className="flex items-center justify-center gap-2">
                      <p className="text-xl font-bold text-gray-900 tracking-tight">
                        {store.stats?.avgInspection || 0}%
                      </p>
                      <div className={`w-1.5 h-1.5 rounded-full ${store.stats?.avgInspection >= 85 ? 'bg-emerald-500' : 'bg-red-500'}`}></div>
                    </div>
                  </div>
                </div>

                {/* Log Action Bar */}
                <div className="flex justify-between items-center py-3 border-t border-gray-50 mb-6">
                  <div className="text-center flex-1">
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wide pb-0.5">Opiniones</p>
                    <p className="text-sm font-bold text-gray-800">{store.stats?.feedbackCount || 0}</p>
                  </div>
                  <div className="w-[1px] h-4 bg-gray-100"></div>
                  <div className="text-center flex-1">
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wide pb-0.5">Audits</p>
                    <p className="text-sm font-bold text-gray-800">{store.stats?.inspectionCount || 0}</p>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedStore(selectedStore?.id === store.id ? null : store)}
                  className="w-full py-3.5 bg-gray-900 text-white text-xs font-bold uppercase tracking-wide rounded-xl transition-all hover:bg-[#e31837] active:scale-95 shadow-lg shadow-gray-100 flex items-center justify-center gap-2"
                >
                  {selectedStore?.id === store.id ? '✕ Cerrar Vista' : 'Métricas Detalladas'}
                </button>
              </div>

              {/* Extended Details Panel */}
              {selectedStore?.id === store.id && (
                <div className="bg-gray-50 p-7 border-t border-gray-100 animate-in slide-in-from-top-2 duration-300">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center py-2 border-b border-gray-200/50">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-tight">Capacidad Logística:</span>
                      <span className="text-xs font-bold text-gray-900 uppercase">{store.capacity || 'Estándar TAG'}</span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-gray-200/50">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-tight">Estatus Operativo:</span>
                      <span className="text-xs font-bold text-gray-900 uppercase">Día {new Date().getDay() + 1} Sincronizado</span>
                    </div>
                    <div className="flex justify-between items-center py-2">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-tight">Fecha de Registro:</span>
                      <span className="text-xs font-bold text-gray-900 uppercase">
                        {new Date(store.created_at).toLocaleDateString('es-MX', { year: 'numeric', month: 'short' })}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {filteredStores.length === 0 && (
          <div className="text-center py-40">
            <span className="text-6xl mb-6 block grayscale opacity-20">🏙️</span>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em]">No se encontraron unidades con los criterios especificados</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default function TiendasPage() {
  return <TiendasContent />
}
