'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'
import { formatDateLA } from '@/lib/checklistPermissions'

function NotificacionesContent() {
  const router = useRouter()
  const { user } = useAuth()
  const [notifications, setNotifications] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<'all' | 'unread' | 'read'>('all')

  // Cargar notificaciones
  useEffect(() => {
    if (user) {
      fetchNotifications()
    }
  }, [filter, user])

  const fetchNotifications = async () => {
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      const res = await fetch(
        `${url}/rest/v1/notifications?user_id=eq.${user?.id}&order=created_at.desc`,
        {
          headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` }
        }
      )

      const data = await res.json()
      setNotifications(Array.isArray(data) ? data : [])
      setLoading(false)
    } catch (err) {
      console.error('❌ Error:', err)
      setLoading(false)
    }
  }

  const markAsRead = async (id: number) => {
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      await fetch(`${url}/rest/v1/notifications?id=eq.${id}`, {
        method: 'PATCH',
        headers: {
          'apikey': key || '',
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({ is_read: true, read_at: new Date().toISOString() })
      })

      fetchNotifications()
    } catch (err) {
      console.error('Error:', err)
    }
  }

  const markAllAsRead = async () => {
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      const unreadIds = notifications.filter(n => !n.is_read).map(n => n.id)

      for (const id of unreadIds) {
        await fetch(`${url}/rest/v1/notifications?id=eq.${id}`, {
          method: 'PATCH',
          headers: {
            'apikey': key || '',
            'Authorization': `Bearer ${key}`,
            'Content-Type': 'application/json',
            'Prefer': 'return=minimal'
          },
          body: JSON.stringify({ is_read: true, read_at: new Date().toISOString() })
        })
      }

      fetchNotifications()
    } catch (err) {
      console.error('Error:', err)
    }
  }

  const deleteNotification = async (id: number) => {
    if (!confirm('¿Eliminar esta notificación?')) return

    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      await fetch(`${url}/rest/v1/notifications?id=eq.${id}`, {
        method: 'DELETE',
        headers: {
          'apikey': key || '',
          'Authorization': `Bearer ${key}`
        }
      })

      fetchNotifications()
    } catch (err) {
      console.error('Error:', err)
    }
  }

  const handleNotificationClick = (notification: any) => {
    if (!notification.is_read) {
      markAsRead(notification.id)
    }

    if (notification.reference_type === 'supervisor_inspection') {
      router.push('/inspecciones')
    } else if (notification.reference_type === 'manager') {
      router.push('/checklists-manager')
    } else {
      router.push('/checklists')
    }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)

    if (diffMins < 1) return 'Justo ahora'
    if (diffMins < 60) return `${diffMins} min`

    const diffHours = Math.floor(diffMins / 60)
    if (diffHours < 24) return `${diffHours}h`

    const diffDays = Math.floor(diffHours / 24)
    return `${diffDays}d`
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center p-20">
        <div className="text-center">
          <div className="text-6xl mb-6 grayscale opacity-20">🔔</div>
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.4em]">Sintonizando Alertas...</p>
        </div>
      </div>
    )
  }

  if (!user) return null

  const unreadCount = notifications.filter(n => !n.is_read).length

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Notificaciones</h1>
            <p className="text-gray-600 mt-2">Alertas globales y seguimiento de eventos críticos.</p>
          </div>
        </div>

        {/* Filtros - Solid Business */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex flex-col sm:flex-row gap-6 items-stretch sm:items-center justify-between">
            <div className="flex gap-2 flex-wrap bg-gray-50 p-1.5 rounded-xl border border-gray-100">
              {[
                { id: 'all', label: 'Todos' },
                { id: 'unread', label: `Pendientes (${unreadCount})` },
                { id: 'read', label: 'Leídos' }
              ].map((f: any) => (
                <button
                  key={f.id}
                  onClick={() => setFilter(f.id)}
                  className={`px-6 py-2 rounded-lg font-black text-[10px] uppercase tracking-widest transition-all ${filter === f.id
                    ? 'bg-white text-[#e31837] shadow-sm'
                    : 'text-gray-400 hover:text-gray-600'
                    }`}>
                  {f.label}
                </button>
              ))}
            </div>

            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="bg-gray-900 text-white px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all hover:bg-[#e31837] shadow-lg shadow-gray-100 active:scale-95 whitespace-nowrap">
                ✓ Validar Todo
              </button>
            )}
          </div>
        </div>

        {/* Lista de Notificaciones */}
        <div className="space-y-4">
          {notifications.length === 0 ? (
            <div className="bg-white border-2 border-dashed border-gray-100 py-32 rounded-[3rem] text-center">
              <div className="text-7xl mb-6 grayscale opacity-10">📭</div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.5em] italic">Bitácora de eventos vacía</p>
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                className={`bg-white rounded-[2rem] shadow-sm p-6 md:p-8 border border-gray-100 transition-all hover:shadow-xl hover:-translate-y-0.5 group ${!notif.is_read ? 'ring-2 ring-[#e31837]/5 bg-red-50/5' : ''
                  }`}>
                <div className="flex items-start gap-6">
                  {/* Icono */}
                  <div className={`flex-shrink-0 w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shadow-inner transition-transform group-hover:scale-110 ${!notif.is_read ? 'bg-[#e31837] text-white' : 'bg-gray-100 text-gray-400'
                    }`}>
                    {notif.type === 'observacion_supervisor' ? '⚠️' : '🔔'}
                  </div>

                  {/* Contenido */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-6 mb-2">
                      <h3 className={`font-black text-lg tracking-tight uppercase italic ${!notif.is_read ? 'text-gray-900' : 'text-gray-400'
                        }`}>
                        {notif.title}
                      </h3>
                      {!notif.is_read && (
                        <div className="w-2.5 h-2.5 bg-[#e31837] rounded-full flex-shrink-0 mt-1.5 animate-pulse shadow-lg shadow-red-200" />
                      )}
                    </div>

                    <p className={`mb-4 text-xs font-medium leading-relaxed ${!notif.is_read ? 'text-gray-700' : 'text-gray-400 opacity-60'}`}>{notif.message}</p>

                    <div className="flex items-center gap-4 text-[9px] font-black text-gray-400 uppercase tracking-widest italic">
                      <span className="bg-gray-50 px-2 py-0.5 rounded text-gray-500">{formatTimeAgo(notif.created_at)}</span>
                      <span>•</span>
                      <span>{formatDateLA(notif.created_at)}</span>
                    </div>

                    {/* Acciones */}
                    <div className="flex flex-wrap gap-3 mt-6">
                      <button
                        onClick={() => handleNotificationClick(notif)}
                        className="bg-gray-900 text-white px-5 py-2.5 rounded-xl font-black text-[9px] uppercase tracking-widest transition-all hover:bg-[#e31837] shadow-sm active:scale-95">
                        Expediente
                      </button>
                      {!notif.is_read && (
                        <button
                          onClick={() => markAsRead(notif.id)}
                          className="bg-white border border-gray-200 text-gray-900 px-5 py-2.5 rounded-xl font-black text-[9px] uppercase tracking-widest transition-all hover:bg-gray-50 shadow-sm active:scale-95">
                          Archivar
                        </button>
                      )}
                      <button
                        onClick={() => deleteNotification(notif.id)}
                        className="text-gray-300 hover:text-red-500 px-3 py-2.5 rounded-xl font-black text-[9px] uppercase tracking-widest transition-all active:scale-95">
                        Eliminar
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}

export default function NotificacionesPage() {
  return <NotificacionesContent />
}