'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function NuevoFeedbackPage() {
  const router = useRouter()
  const [stores, setStores] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  const [formData, setFormData] = useState({
    store_id: '',
    submission_date: new Date().toISOString().split('T')[0],
    nps_score: 8,
    service_rating: 5,
    food_quality_rating: 5,
    cleanliness_rating: 5,
    speed_rating: 5,
    wait_time_minutes: 10,
    customer_comments: ''
  })

  useEffect(() => {
    fetchStores()
  }, [])

  const fetchStores = async () => {
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      const res = await fetch(`${url}/rest/v1/stores?select=*&order=name.asc`, {
        headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` }
      })
      const data = await res.json()
      setStores(Array.isArray(data) ? data : [])
    } catch (err) {
      console.error('Error:', err)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      // Calcular NPS category
      let nps_category = 'passive'
      if (formData.nps_score >= 9) nps_category = 'promoter'
      else if (formData.nps_score <= 6) nps_category = 'detractor'

      const payload = {
        ...formData,
        nps_score: formData.nps_score,
        service_rating: formData.service_rating,
        food_quality_rating: formData.food_quality_rating,
        cleanliness_rating: formData.cleanliness_rating,
        speed_rating: formData.speed_rating,
        wait_time_minutes: formData.wait_time_minutes,
        comments: formData.customer_comments,
        nps_category
      }

      const res = await fetch(`${url}/rest/v1/customer_feedback`, {
        method: 'POST',
        headers: {
          'apikey': key || '',
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify(payload)
      })

      if (res.ok) {
        alert('✅ Feedback registrado exitosamente')
        router.push('/feedback')
      } else {
        alert('❌ Error al registrar feedback')
      }
    } catch (err) {
      console.error('Error:', err)
      alert('❌ Error al registrar feedback')
    }

    setLoading(false)
  }

  return (
    <div className="p-8 lg:p-10 space-y-10 animate-in fade-in duration-700">
      <div className="max-w-4xl mx-auto space-y-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-gray-200 pb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="bg-[#e31837] text-white text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider">Gestión de Datos</span>
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Entrada de Registro</span>
            </div>
            <h1 className="text-4xl font-black text-gray-900 tracking-tighter">
              Nuevo <span className="text-[#e31837]">Feedback</span> de Cliente
            </h1>
            <p className="text-gray-500 mt-1 font-medium">Registrar experiencia del cliente en el sistema.</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-[2rem] border border-gray-200 shadow-sm p-10 space-y-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Tienda *</label>
              <select
                required
                value={formData.store_id}
                onChange={(e) => setFormData({ ...formData, store_id: e.target.value })}
                className="w-full px-6 py-4 bg-gray-50 border-0 rounded-2xl text-sm font-bold text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
              >
                <option value="">Seleccionar tienda</option>
                {stores.map(store => (
                  <option key={store.id} value={store.id}>{store.name}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Fecha de Visita *</label>
              <input
                type="date"
                required
                value={formData.submission_date}
                onChange={(e) => setFormData({ ...formData, submission_date: e.target.value })}
                className="w-full px-6 py-4 bg-gray-50 border-0 rounded-2xl text-sm font-bold text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
              />
            </div>
          </div>

          <div className="space-y-6 pt-6 border-t border-gray-50">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Nivel de Recomendación (NPS)</label>
            <div className="bg-gray-50 p-8 rounded-3xl space-y-6">
              <input
                type="range"
                min="0"
                max="10"
                value={formData.nps_score}
                onChange={(e) => setFormData({ ...formData, nps_score: parseInt(e.target.value) })}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#e31837]"
              />
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-gray-400 uppercase">Nada Probable</span>
                <span className="text-4xl font-black text-[#e31837] tabular-nums">{formData.nps_score}</span>
                <span className="text-[10px] font-bold text-gray-400 uppercase">Muy Probable</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-6 border-t border-gray-50">
            {[
              { label: 'Servicio', key: 'service_rating' },
              { label: 'Calidad', key: 'food_quality_rating' },
              { label: 'Limpieza', key: 'cleanliness_rating' },
              { label: 'Rapidez', key: 'speed_rating' }
            ].map((item) => (
              <div key={item.key} className="space-y-2">
                <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-1">{item.label}</label>
                <input
                  type="number"
                  min="1"
                  max="5"
                  value={(formData as any)[item.key]}
                  onChange={(e) => setFormData({ ...formData, [item.key]: parseInt(e.target.value) })}
                  className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl text-sm font-black text-gray-900 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none text-center"
                />
              </div>
            ))}
          </div>

          <div className="space-y-2 pt-6 border-t border-gray-50">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Comentarios del Cliente</label>
            <textarea
              value={formData.customer_comments}
              onChange={(e) => setFormData({ ...formData, customer_comments: e.target.value })}
              rows={4}
              className="w-full px-6 py-4 bg-gray-50 border-0 rounded-2xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none resize-none"
              placeholder="Escribe aquí las observaciones..."
            />
          </div>

          <div className="flex gap-4 pt-6">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-8 py-4 bg-gray-900 text-white rounded-2xl font-black text-[11px] tracking-widest uppercase transition-all hover:bg-[#e31837] active:scale-95 shadow-xl disabled:bg-gray-300"
            >
              {loading ? 'Guardando...' : 'Finalizar Registro'}
            </button>
            <button
              type="button"
              onClick={() => router.push('/feedback')}
              className="px-8 py-4 bg-white border border-gray-100 text-gray-400 rounded-2xl font-black text-[11px] tracking-widest uppercase transition-all hover:bg-gray-50 active:scale-95 shadow-sm"
            >
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}