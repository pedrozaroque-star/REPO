'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { format } from 'date-fns'
import { es } from 'date-fns/locale'
import FeedbackDetailModal from '@/components/FeedbackDetailModal'

interface Feedback {
  id: number
  submission_date: string
  store_id: string
  customer_name: string
  service_rating: number
  speed_rating: number
  food_quality_rating: number
  cleanliness_rating: number
  nps_score: number
  nps_category: string
  comments: string
  photo_urls: string[] | null
  stores: { name: string } | null
  admin_review_status?: 'pendiente' | 'aprobado' | 'rechazado' | 'corregir'
  admin_review_comments?: string
}

export default function FeedbackAdminPage() {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([])
  const [loading, setLoading] = useState(true)
  const [filterStore, setFilterStore] = useState('')
  const [stores, setStores] = useState<{ id: string, name: string }[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  const [selectedFeedback, setSelectedFeedback] = useState<Feedback | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [filterStatus, setFilterStatus] = useState('all') // 🆕 State for filters

  const ITEMS_PER_PAGE = 50

  useEffect(() => {
    fetchStores()
    fetchFeedback(true)
  }, [])

  useEffect(() => {
    // Reset to page 1 when filters change
    setPage(1)
    fetchFeedback(true)
  }, [filterStore, searchTerm, filterStatus]) // 🆕 Added filterStatus

  const fetchStores = async () => {
    const { data } = await supabase.from('stores').select('id, name').order('name')
    if (data) setStores(data)
  }

  const fetchFeedback = async (reset = false) => {
    if (reset) {
      setLoading(true)
      setFeedbacks([])
    }

    const currentPage = reset ? 1 : page
    const from = (currentPage - 1) * ITEMS_PER_PAGE
    const to = from + ITEMS_PER_PAGE - 1

    let query = supabase
      .from('customer_feedback')
      .select('*, stores(name)')
      .order('submission_date', { ascending: false })
      .range(from, to)

    if (filterStore) {
      query = query.eq('store_id', filterStore)
    }

    // 🆕 Logic for Status Filter
    if (filterStatus === 'pendiente') {
      // Supabase PostgREST supports "or" syntax.
      query = query.or('admin_review_status.eq.pendiente,admin_review_status.is.null')
    } else if (filterStatus === 'aprobado') {
      query = query.eq('admin_review_status', 'aprobado')
    } else if (filterStatus === 'rechazado') {
      query = query.in('admin_review_status', ['rechazado', 'corregir'])
    }


    if (searchTerm) {
      // Search in customer_name, comments, or cast ID to text
      query = query.or(`customer_name.ilike.%${searchTerm}%,comments.ilike.%${searchTerm}%`)
    }

    const { data, error } = await query

    if (data) {
      if (reset) {
        setFeedbacks(data)
      } else {
        // Prevent duplicates when loading more
        setFeedbacks(prev => {
          const existingIds = new Set(prev.map(p => p.id))
          const newItems = data.filter(d => !existingIds.has(d.id))
          return [...prev, ...newItems]
        })
      }

      // If we got fewer items than requested, we've reached the end
      setHasMore(data.length === ITEMS_PER_PAGE)
      if (!reset) setPage(currentPage + 1)
    }

    if (error) console.error('Error fetching feedback:', error)
    setLoading(false)
  }

  const loadMore = () => {
    setPage(prev => prev + 1)
    fetchFeedback(false)
  }

  const handleOpenModal = (feedback: Feedback) => {
    setSelectedFeedback(feedback)
    setIsModalOpen(true)
  }

  const getNpsColor = (score: number) => {
    if (score >= 9) return 'bg-emerald-100 text-emerald-700 border-emerald-200'
    if (score >= 7) return 'bg-amber-100 text-amber-700 border-amber-200'
    return 'bg-red-100 text-red-700 border-red-200'
  }

  return (
    <div className="h-[calc(100vh-2rem)] flex flex-col p-6 overflow-hidden">
      <div className="max-w-[94%] mx-auto w-full flex flex-col h-full gap-6">

        {/* 1. Header (Fixed Top) */}
        <div className="flex-none">
          <h1 className="text-3xl font-bold text-gray-900">Control de Feedback</h1>
          <p className="text-gray-600 mt-2">Monitoreo de experiencia y calidad en tiempo real.</p>
        </div>

        {/* 2. Stats Cards */}
        <div className="flex-none grid grid-cols-2 lg:grid-cols-5 gap-4">
          {[
            {
              label: 'NPS Global',
              value: feedbacks.length > 0 ? Math.round((feedbacks.reduce((sum, f) => sum + (f.nps_score || 0), 0) / feedbacks.length) * 10) : 0,
              max: 100,
              color: 'text-gray-900',
              icon: '📊'
            },
            {
              label: 'Servicio',
              value: feedbacks.length > 0 ? (feedbacks.reduce((sum, f) => sum + (f.service_rating || 0), 0) / feedbacks.length).toFixed(1) : '0.0',
              max: 5,
              color: 'text-[#e31837]',
              icon: '👤'
            },
            {
              label: 'Rapidez',
              value: feedbacks.length > 0 ? (feedbacks.reduce((sum, f) => sum + (f.speed_rating || 0), 0) / feedbacks.length).toFixed(1) : '0.0',
              max: 5,
              color: 'text-amber-500',
              icon: '⚡'
            },
            {
              label: 'Calidad',
              value: feedbacks.length > 0 ? (feedbacks.reduce((sum, f) => sum + (f.food_quality_rating || 0), 0) / feedbacks.length).toFixed(1) : '0.0',
              max: 5,
              color: 'text-orange-500',
              icon: '🍔'
            },
            {
              label: 'Limpieza',
              value: feedbacks.length > 0 ? (feedbacks.reduce((sum, f) => sum + (f.cleanliness_rating || 0), 0) / feedbacks.length).toFixed(1) : '0.0',
              max: 5,
              color: 'text-emerald-500',
              icon: '✨'
            }
          ].map((stat, idx) => (
            <div key={idx} className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex flex-col items-center justify-center text-center transition-all hover:shadow-md">
              <span className="text-2xl mb-2 grayscale opacity-80">{stat.icon}</span>
              <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">{stat.label}</p>
              <div className="flex items-baseline gap-1">
                <span className={`text-3xl font-black ${stat.color} tracking-tight`}>{stat.value}</span>
                <span className="text-xs text-gray-300 font-bold">/{stat.max}</span>
              </div>
            </div>
          ))}
        </div>

        {/* 3. Filters & Actions (Fixed) */}
        <div className="flex-none flex flex-col xl:flex-row xl:items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
          {/* 💅 Coquette Status Filters */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setFilterStatus('all')}
              className={`whitespace-nowrap px-5 py-2.5 rounded-full text-xs font-black tracking-widest uppercase transition-all shadow-sm border ${filterStatus === 'all'
                ? 'bg-gray-900 text-white border-gray-900 scale-105 shadow-gray-200'
                : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
            >
              Todos
            </button>
            <button
              onClick={() => setFilterStatus('pendiente')}
              className={`whitespace-nowrap px-5 py-2.5 rounded-full text-xs font-black tracking-widest uppercase transition-all shadow-sm border flex items-center gap-2 ${filterStatus === 'pendiente'
                ? 'bg-amber-100 text-amber-700 border-amber-200 scale-105 shadow-amber-100'
                : 'bg-white text-gray-500 border-gray-200 hover:border-amber-200 hover:text-amber-600'
                }`}
            >
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              Pendientes
            </button>
            <button
              onClick={() => setFilterStatus('aprobado')}
              className={`whitespace-nowrap px-5 py-2.5 rounded-full text-xs font-black tracking-widest uppercase transition-all shadow-sm border flex items-center gap-2 ${filterStatus === 'aprobado'
                ? 'bg-emerald-100 text-emerald-700 border-emerald-200 scale-105 shadow-emerald-100'
                : 'bg-white text-gray-500 border-gray-200 hover:border-emerald-200 hover:text-emerald-600'
                }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              Aprobados
            </button>
            <button
              onClick={() => setFilterStatus('rechazado')}
              className={`whitespace-nowrap px-5 py-2.5 rounded-full text-xs font-black tracking-widest uppercase transition-all shadow-sm border flex items-center gap-2 ${filterStatus === 'rechazado'
                ? 'bg-red-100 text-red-700 border-red-200 scale-105 shadow-red-100'
                : 'bg-white text-gray-500 border-gray-200 hover:border-red-200 hover:text-red-600'
                }`}
            >
              <span className="w-2 h-2 rounded-full bg-red-400" />
              Rechazados
            </button>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
            <div className="relative w-full sm:w-auto">
              <input
                type="text"
                placeholder="Buscar cliente..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full sm:w-48 xl:w-64 bg-white border border-gray-200 rounded-xl pl-10 pr-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none shadow-sm h-[42px]"
              />
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
            </div>

            <div className="relative w-full sm:w-auto">
              <select
                value={filterStore}
                onChange={(e) => setFilterStore(e.target.value)}
                className="w-full sm:w-48 xl:w-64 appearance-none bg-white border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-bold text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none shadow-sm cursor-pointer h-[42px]"
              >
                <option value="">Todas las Sucursales</option>
                {stores.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
              <div className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 text-xs text-[8px]">▼</div>
            </div>
          </div>
        </div>

        {/* 4. Content (Flexible & Scrollable) */}
        <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden min-h-0">
          <div className="h-full overflow-y-auto custom-scrollbar text-sm">
            <table className="w-full text-left">
              <thead>
                <tr className="sticky top-0 z-10 bg-gray-50 border-b border-gray-100 text-xs text-gray-500 font-bold uppercase tracking-wider shadow-sm">
                  <th className="px-6 py-4 w-10"></th>{/* Status Icon */}
                  <th className="px-6 py-4">Fecha</th>
                  <th className="px-6 py-4">Sucursal / Cliente</th>
                  <th className="px-6 py-4 text-center">NPS</th>
                  <th className="px-6 py-4 text-center">Calif. Promedio</th>
                  <th className="px-6 py-4 w-1/3">Comentario</th>
                  <th className="px-6 py-4 text-center">Evidencia</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {feedbacks.map(f => {
                  const avgRating = ((f.service_rating + f.speed_rating + f.food_quality_rating + f.cleanliness_rating) / 4).toFixed(1)
                  return (
                    <tr
                      key={f.id}
                      onClick={() => handleOpenModal(f)}
                      className="hover:bg-gray-50 transition-colors cursor-pointer group"
                    >
                      <td className="px-6 py-4 text-center">
                        {f.admin_review_status === 'aprobado' ? (
                          <span title="Aprobado" className="text-lg">✅</span>
                        ) : f.admin_review_status === 'rechazado' || f.admin_review_status === 'corregir' ? (
                          <span title="Rechazado" className="text-lg animate-pulse">⚠️</span>
                        ) : (
                          <span title="Pendiente" className="text-lg opacity-20 grayscale">⏳</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                        {format(new Date(f.submission_date), 'dd MMM HH:mm', { locale: es })}
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-bold text-gray-900 group-hover:text-[#e31837] transition-colors">{f.stores?.name || '---'}</div>
                        <div className="text-xs text-gray-500 font-medium capitalize flex items-center gap-1">
                          {f.customer_name ? (
                            <span className="text-gray-700">{f.customer_name.toLowerCase()}</span>
                          ) : (
                            <span className="italic text-gray-400">Anónimo</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className={`inline-flex items-center justify-center w-8 h-8 rounded-lg border text-sm font-black ${getNpsColor(f.nps_score)}`}>
                          {f.nps_score}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <span className="text-[#fdc82f] text-base">★</span>
                          <span className="font-bold text-gray-900 text-base">{avgRating}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-gray-600 text-sm line-clamp-2 leading-relaxed">
                          {f.comments || <span className="text-gray-300 italic">Sin observaciones.</span>}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        {f.photo_urls && f.photo_urls.length > 0 ? (
                          <span className="inline-flex items-center justify-center px-3 py-1 rounded-full bg-blue-50 text-blue-600 border border-blue-100 text-xs font-bold gap-1 group-hover:bg-blue-100 transition-colors">
                            📷 {f.photo_urls.length}
                          </span>
                        ) : (
                          <span className="text-gray-300 text-xs">-</span>
                        )}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>

            {loading && feedbacks.length === 0 && (
              <div className="flex justify-center py-20">
                <div className="w-10 h-10 border-4 border-[#e31837]/20 border-t-[#e31837] rounded-full animate-spin"></div>
              </div>
            )}

            {!loading && feedbacks.length === 0 && (
              <div className="text-center py-20">
                <div className="text-4xl mb-4 opacity-10">💬</div>
                <p className="text-gray-400 font-medium uppercase tracking-wide text-xs">No hay opiniones registradas con estos filtros.</p>
              </div>
            )}

            {/* Load More Button */}
            {hasMore && !loading && feedbacks.length > 0 && (
              <div className="p-4 border-t border-gray-100 bg-gray-50/50 flex justify-center">
                <button
                  onClick={loadMore}
                  className="px-6 py-2.5 bg-white border border-gray-300 text-gray-600 font-bold rounded-xl shadow-sm hover:bg-gray-50 hover:text-gray-900 transition-all active:scale-95 text-sm"
                >
                  Cargar más registros (+{ITEMS_PER_PAGE})
                </button>
              </div>
            )}

            {loading && feedbacks.length > 0 && (
              <div className="p-4 border-t border-gray-100 flex justify-center">
                <span className="text-gray-400 text-xs animate-pulse">Cargando más...</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <FeedbackDetailModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        feedback={selectedFeedback}
      />
    </div>
  )
}
