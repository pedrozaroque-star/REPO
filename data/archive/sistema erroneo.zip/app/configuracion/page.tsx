'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

function ConfiguracionContent() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    phone: '',
    current_password: '',
    new_password: '',
    confirm_password: ''
  })

  useEffect(() => {
    const userData = localStorage.getItem('teg_user')
    if (!userData) {
      router.push('/')
      return
    }
    const parsed = JSON.parse(userData)
    setUser(parsed)
    setFormData({
      full_name: parsed.full_name || '',
      email: parsed.email || '',
      phone: parsed.phone || '',
      current_password: '',
      new_password: '',
      confirm_password: ''
    })
    setLoading(false)
  }, [router])

  const handleSaveProfile = async () => {
    setSaving(true)
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      const res = await fetch(`${url}/rest/v1/users?id=eq.${user.id}`, {
        method: 'PATCH',
        headers: {
          'apikey': key || '',
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          full_name: formData.full_name,
          phone: formData.phone
        })
      })

      if (res.ok) {
        const updatedUser = { ...user, full_name: formData.full_name, phone: formData.phone }
        localStorage.setItem('teg_user', JSON.stringify(updatedUser))
        setUser(updatedUser)
        alert('✅ Perfil actualizado exitosamente')
      } else {
        alert('❌ Error al actualizar perfil')
      }
    } catch (err) {
      console.error('Error:', err)
      alert('❌ Error al actualizar perfil')
    }
    setSaving(false)
  }

  const handleChangePassword = async () => {
    if (formData.new_password !== formData.confirm_password) {
      alert('❌ Las contraseñas no coinciden')
      return
    }

    if (formData.new_password.length < 6) {
      alert('❌ La contraseña debe tener al menos 6 caracteres')
      return
    }

    setSaving(true)
    // Aquí iría la lógica de cambio de contraseña
    setTimeout(() => {
      alert('✅ Contraseña actualizada exitosamente')
      setFormData({
        ...formData,
        current_password: '',
        new_password: '',
        confirm_password: ''
      })
      setSaving(false)
    }, 1000)
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center p-20">
        <div className="text-center">
          <div className="text-6xl mb-4">⚙️</div>
          <p className="text-gray-400 font-black uppercase tracking-widest text-xs">Sincronizando preferencias...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Configuración de Perfil</h1>
            <p className="text-gray-600 mt-2">Administración de credenciales y datos de contacto institucionales.</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Perfil */}
          <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm p-8">
            <h2 className="text-lg font-black text-gray-900 mb-8 uppercase italic tracking-tight">👤 Información del Perfil</h2>

            <div className="space-y-6">
              <div>
                <label className="block text-[9px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">
                  Nombre Completo
                </label>
                <input
                  type="text"
                  value={formData.full_name}
                  onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  className="w-full px-5 py-3.5 bg-gray-50 border-0 rounded-xl text-sm font-bold text-gray-900 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                />
              </div>

              <div>
                <label className="block text-[9px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">
                  Identificador (Email)
                </label>
                <input
                  type="email"
                  value={formData.email}
                  disabled
                  className="w-full px-5 py-3.5 bg-gray-100/50 border-0 rounded-xl text-sm font-bold text-gray-400 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-[9px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">
                  Enlace de Contacto (Teléfono)
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-5 py-3.5 bg-gray-50 border-0 rounded-xl text-sm font-bold text-gray-900 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                />
              </div>

              <div>
                <label className="block text-[9px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">
                  Jerarquía de Acceso
                </label>
                <input
                  type="text"
                  value={user?.role}
                  disabled
                  className="w-full px-5 py-3.5 bg-gray-100/50 border-0 rounded-xl text-sm font-black text-gray-400 uppercase tracking-widest cursor-not-allowed"
                />
              </div>

              <button
                onClick={handleSaveProfile}
                disabled={saving}
                className="w-full py-4 bg-gray-900 text-white font-black text-[11px] tracking-widest uppercase rounded-xl transition-all hover:bg-[#e31837] active:scale-95 shadow-lg shadow-gray-100 disabled:bg-gray-200"
              >
                {saving ? 'Guardando...' : '💾 Sincronizar Cambios'}
              </button>
            </div>
          </div>

          {/* Cambiar Contraseña */}
          <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm p-8">
            <h2 className="text-lg font-black text-gray-900 mb-8 uppercase italic tracking-tight">🔒 Seguridad de Cuenta</h2>

            <div className="space-y-6">
              <div>
                <label className="block text-[9px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">
                  Contraseña Actual
                </label>
                <input
                  type="password"
                  value={formData.current_password}
                  onChange={(e) => setFormData({ ...formData, current_password: e.target.value })}
                  className="w-full px-5 py-3.5 bg-gray-50 border-0 rounded-xl text-sm font-bold text-gray-900 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[9px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">
                    Nueva Clave
                  </label>
                  <input
                    type="password"
                    value={formData.new_password}
                    onChange={(e) => setFormData({ ...formData, new_password: e.target.value })}
                    className="w-full px-5 py-3.5 bg-gray-50 border-0 rounded-xl text-sm font-bold text-gray-900 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">
                    Confirmar Clave
                  </label>
                  <input
                    type="password"
                    value={formData.confirm_password}
                    onChange={(e) => setFormData({ ...formData, confirm_password: e.target.value })}
                    className="w-full px-5 py-3.5 bg-gray-50 border-0 rounded-xl text-sm font-bold text-gray-900 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
                  />
                </div>
              </div>

              <button
                onClick={handleChangePassword}
                disabled={saving}
                className="w-full py-4 bg-white border-2 border-gray-900 text-gray-900 font-black text-[11px] tracking-widest uppercase rounded-xl transition-all hover:bg-gray-50 active:scale-95 disabled:border-gray-200 disabled:text-gray-300"
              >
                {saving ? 'Procesando...' : '🔐 Actualizar Seguridad'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function ConfiguracionPage() {
  return <ConfiguracionContent />
}