'use client'

export default function Loading() {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Subtle Background Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gray-50 rounded-full blur-3xl opacity-50 -mr-48 -mt-48"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-red-50 rounded-full blur-3xl opacity-30 -ml-48 -mb-48"></div>

      <div className="relative flex flex-col items-center space-y-12 animate-in fade-in zoom-in duration-1000">
        {/* Main Logo Container */}
        <div className="flex flex-col items-center">
          <img
            src="/logo.png"
            alt="Tacos Gavilán"
            className="h-28 w-auto object-contain mb-8 drop-shadow-sm"
          />

          {/* Tagline Image */}
          <div className="relative">
            <img
              src="/ya esta.png"
              alt="Ya está!"
              className="h-10 w-auto object-contain opacity-90"
            />
            {/* Serious Accent Line */}
            <div className="h-[3px] w-full bg-[#fdc82f] rounded-full mt-2"></div>
          </div>
        </div>

        {/* Corporate Loading Indicator */}
        <div className="flex flex-col items-center gap-6 w-64">
          <div className="w-full h-1 bg-gray-100 rounded-full overflow-hidden shadow-inner">
            <div className="h-full bg-[#e31837] w-1/3 rounded-full animate-loading-bar"></div>
          </div>
          <div className="flex flex-col items-center space-y-1">
            <p className="text-[10px] font-black text-gray-900 uppercase tracking-[0.3em]">
              Autenticando Acceso
            </p>
            <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">
              Conexión Segura TAG v2.5
            </p>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes loading-bar {
          0% { transform: translateX(-110%); }
          100% { transform: translateX(310%); }
        }
        .animate-loading-bar {
          animation: loading-bar 1.5s infinite cubic-bezier(0.65, 0, 0.35, 1);
        }
      `}</style>
    </div>
  )
}