'use client'

import { useEffect, useState } from 'react'
import UserModal from '@/components/UserModal'
import { supabase } from '@/lib/supabase'
import LoadingScreen from '@/components/LoadingScreen'

function UsuariosContent() {
  const [users, setUsers] = useState<any[]>([])
  const [stores, setStores] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [roleFilter, setRoleFilter] = useState('all')

  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<any>(null)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      const { data: usersData, error: userError } = await supabase
        .from('users')
        .select('*')
        .order('full_name')

      if (userError) throw userError

      const { data: storesData, error: storeError } = await supabase
        .from('stores')
        .select('id, name')
        .order('name')

      if (storeError) throw storeError

      setUsers(usersData || [])
      setStores(storesData || [])
    } catch (err: any) {
      console.error('Error cargando datos:', err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleSaveUser = async (formData: any, isEdit: boolean) => {
    try {
      const role = formData.role
      const cleanData = {
        full_name: formData.full_name,
        role: role,
        email: formData.email,
        is_active: formData.is_active,
        store_id: ['manager', 'asistente'].includes(role) && formData.store_id
          ? parseInt(formData.store_id)
          : null,
        store_scope: role === 'supervisor'
          ? formData.store_scope
          : null
      }

      if (isEdit) {
        const { error } = await supabase
          .from('users')
          .update(cleanData)
          .eq('id', formData.id)

        if (error) throw error

        if (formData.password && formData.password.trim() !== '') {
          const { error: rpcError } = await supabase.rpc('admin_reset_password_by_email', {
            target_email: formData.email,
            new_password: formData.password
          })
          if (rpcError) console.warn('No se pudo actualizar password via RPC:', rpcError.message)
        }
      } else {
        const { error } = await supabase.rpc('create_new_user', {
          email: formData.email,
          password: formData.password,
          full_name: formData.full_name,
          role: formData.role,
          store_id: cleanData.store_id
        })

        if (error) throw error

        if (role === 'supervisor' && cleanData.store_scope) {
          await supabase
            .from('users')
            .update({ store_scope: cleanData.store_scope })
            .eq('email', formData.email)
        }
      }

      fetchData()
      setIsModalOpen(false)
      setEditingUser(null)

    } catch (err: any) {
      console.error(err)
      alert('❌ Error: ' + err.message)
    }
  }

  const filteredUsers = users.filter(user => {
    const searchLower = searchTerm.toLowerCase()
    const matchesSearch =
      user.full_name?.toLowerCase().includes(searchLower) ||
      user.email?.toLowerCase().includes(searchLower)

    const matchesRole = roleFilter === 'all' || user.role === roleFilter
    return matchesSearch && matchesRole
  })

  const roleColors: any = {
    admin: 'bg-gray-900 border-gray-900 text-white',
    supervisor: 'bg-red-50 border-red-100 text-[#e31837]',
    manager: 'bg-gray-100 border-gray-200 text-gray-800',
    asistente: 'bg-emerald-50 border-emerald-100 text-emerald-700'
  }

  const getLocationLabel = (user: any) => {
    if (user.role === 'admin') return 'Acceso de red total'
    if (user.role === 'supervisor') {
      if (!user.store_scope || user.store_scope.length === 0) return 'Sin jurisdicción'
      if (user.store_scope.length === 1) return user.store_scope[0]
      return `${user.store_scope.length} Unidades asignadas`
    }
    const store = stores.find(s => s.id === user.store_id)
    return store ? store.name : 'Sin unidad comercial'
  }

  if (loading) {
    return <LoadingScreen message="Autenticando Roles..." />
  }

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Gestión de Usuarios</h1>
            <p className="text-gray-600 mt-2">Administración técnica de accesos, roles y jerarquías operativas.</p>
          </div>
          <div className="flex space-x-3">
            <button
              onClick={() => { setEditingUser(null); setIsModalOpen(true); }}
              className="px-6 py-3 bg-[#e31837] hover:bg-red-700 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transition-all flex items-center gap-2"
            >
              <span>👤</span> Agregar Usuario
            </button>
          </div>
        </div>
      </div>

      {/* Filter Bar - Solid Style */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <span className="absolute left-5 top-1/2 -translate-y-1/2 text-xl opacity-20">🔍</span>
          <input
            type="text"
            placeholder="Filtrar por nombre completo o identificador de correo..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-14 pr-6 py-3.5 bg-gray-50 border-0 rounded-xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
          />
        </div>
        <div className="md:w-64">
          <select
            value={roleFilter}
            onChange={e => setRoleFilter(e.target.value)}
            className="w-full py-3.5 px-6 bg-gray-50 border-0 rounded-xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none cursor-pointer"
          >
            <option value="all">Todos los Perfiles</option>
            <option value="admin">Administrador</option>
            <option value="supervisor">Supervisor</option>
            <option value="manager">Manager</option>
            <option value="asistente">Asistente</option>
          </select>
        </div>
      </div>

      {/* User Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.map(user => (
          <div
            key={user.id}
            className={`bg-white p-6 rounded-xl border border-gray-200 shadow-sm transition-all hover:shadow-md ${!user.is_active ? 'opacity-60 grayscale' : ''}`}
          >
            <div className="flex items-center gap-4 mb-6">
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-xl ${user.role === 'admin' ? 'bg-gray-900' :
                user.role === 'supervisor' ? 'bg-[#e31837]' :
                  user.role === 'manager' ? 'bg-gray-700' : 'bg-emerald-600'
                }`}>
                {user.full_name?.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 overflow-hidden">
                <h3 className="font-bold text-gray-900 truncate uppercase tracking-tight">{user.full_name}</h3>
                <p className="text-xs text-gray-400 truncate">{user.email}</p>
              </div>
              <button
                onClick={() => { setEditingUser(user); setIsModalOpen(true); }}
                className="w-8 h-8 rounded-lg bg-gray-50 text-gray-400 border border-gray-100 flex items-center justify-center hover:bg-gray-100 transition-colors"
              >
                ✏️
              </button>
            </div>

            <div className="space-y-3 pt-4 border-t border-gray-50">
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-400 font-medium uppercase tracking-wider">Perfil</span>
                <span className={`px-2.5 py-1 rounded text-xs font-bold uppercase tracking-wider border ${roleColors[user.role]}`}>
                  {user.role}
                </span>
              </div>
              <div className="flex justify-between items-start text-xs">
                <span className="text-gray-400 font-medium uppercase tracking-wider mt-0.5">Asignación</span>
                <span className="text-gray-900 font-bold text-right max-w-[150px] leading-tight">
                  {getLocationLabel(user)}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-400 font-medium uppercase tracking-wider">Estado</span>
                <div className="flex items-center gap-1.5">
                  <span className={`w-1.5 h-1.5 rounded-full ${user.is_active ? 'bg-emerald-500' : 'bg-gray-300'}`}></span>
                  <span className={`font-bold ${user.is_active ? 'text-emerald-600' : 'text-gray-400'}`}>
                    {user.is_active ? 'Activo' : 'Desactivado'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function UsuariosPage() {
  return <UsuariosContent />
}
