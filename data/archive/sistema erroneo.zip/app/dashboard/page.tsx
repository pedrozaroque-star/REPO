'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import LoadingScreen from '@/components/LoadingScreen'

function DashboardContent() {
  const router = useRouter()
  const [stats, setStats] = useState({
    totalStores: 0,
    totalUsers: 0,
    totalFeedbacks: 0,
    totalInspections: 0,
    totalChecklists: 0,
    avgNPS: 0,
    avgInspectionScore: 0,
    recentActivity: [] as any[]
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStats()
  }, [])

  const fetchStats = async () => {
    try {
      const [
        { count: storesCount },
        { count: usersCount },
        { data: feedbacks },
        { data: inspections },
        { count: assistantCheckCount },
        { count: managerCheckCount },
        { data: recentData }
      ] = await Promise.all([
        supabase.from('stores').select('*', { count: 'exact', head: true }),
        supabase.from('users').select('*', { count: 'exact', head: true }),
        supabase.from('customer_feedback').select('nps_score'),
        supabase.from('supervisor_inspections').select('overall_score'),
        supabase.from('assistant_checklists').select('*', { count: 'exact', head: true }),
        supabase.from('manager_checklists').select('*', { count: 'exact', head: true }),
        supabase.from('supervisor_inspections')
          .select('*, stores(name), users(full_name)')
          .order('inspection_date', { ascending: false })
          .limit(5)
      ])

      const validFeedbacks = feedbacks || []
      const validInspections = inspections || []

      const avgNPS = validFeedbacks.length > 0
        ? Math.round(validFeedbacks.reduce((sum, f) => sum + (f.nps_score || 0), 0) / validFeedbacks.length)
        : 0

      const avgInspectionScore = validInspections.length > 0
        ? Math.round(validInspections.reduce((sum, i) => sum + (i.overall_score || 0), 0) / validInspections.length)
        : 0

      setStats({
        totalStores: storesCount || 0,
        totalUsers: usersCount || 0,
        totalFeedbacks: validFeedbacks.length,
        totalInspections: validInspections.length,
        totalChecklists: (assistantCheckCount || 0) + (managerCheckCount || 0),
        avgNPS,
        avgInspectionScore,
        recentActivity: recentData || []
      })

      setLoading(false)
    } catch (err) {
      console.error('Error:', err)
      setLoading(false)
    }
  }

  if (loading) {
    return <LoadingScreen message="Sincronizando Sistema..." />
  }

  return (
    <div className="p-6">
      <div className="max-w-[98%] mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Panel de Control</h1>
            <p className="text-gray-500 mt-1">Visión general del rendimiento y actividad reciente.</p>
          </div>
          <button
            onClick={() => router.push('/reportes')}
            className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-all shadow-sm flex items-center gap-2"
          >
            📊 Ver Reportes
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <p className="text-sm font-medium text-gray-500">Tiendas Totales</p>
            <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalStores}</p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <p className="text-sm font-medium text-gray-500">Usuarios Activos</p>
            <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalUsers}</p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <p className="text-sm font-medium text-gray-500">Score de Inspección (Avg)</p>
            <p className="text-3xl font-bold text-[#e31837] mt-2">{stats.avgInspectionScore}%</p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <p className="text-sm font-medium text-gray-500">NPS Global</p>
            <p className="text-3xl font-bold text-amber-500 mt-2">{stats.avgNPS}%</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Activity */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-50">
              <h2 className="text-lg font-bold text-gray-900">Actividad Reciente</h2>
            </div>
            <div className="divide-y divide-gray-50">
              {stats.recentActivity.map((activity) => (
                <div key={activity.id} className="p-4 hover:bg-gray-50 transition-all">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-bold text-gray-900">{activity.stores?.name}</p>
                      <p className="text-xs text-gray-500 mt-1">Inspecionada por {activity.users?.full_name}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-lg font-bold ${activity.overall_score >= 90 ? 'text-emerald-600' : 'text-[#e31837]'}`}>
                        {activity.overall_score}%
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              {stats.recentActivity.length === 0 && (
                <div className="p-12 text-center text-gray-400">
                  <p>No hay actividad reciente para mostrar.</p>
                </div>
              )}
            </div>
          </div>

          {/* Shortcuts */}
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Accesos Rápidos</h2>
              <div className="grid grid-cols-1 gap-3">
                <button
                  onClick={() => router.push('/horarios')}
                  className="p-3 text-left rounded-xl bg-gray-50 hover:bg-gray-100 transition-all text-sm font-bold text-gray-700"
                >
                  📅 Gestión de Horarios
                </button>
                <button
                  onClick={() => router.push('/checklists')}
                  className="p-3 text-left rounded-xl bg-gray-50 hover:bg-gray-100 transition-all text-sm font-bold text-gray-700"
                >
                  📋 Checklists Diarios
                </button>
                <button
                  onClick={() => router.push('/inspecciones')}
                  className="p-3 text-left rounded-xl bg-gray-50 hover:bg-gray-100 transition-all text-sm font-bold text-gray-700"
                >
                  🔎 Auditorías de Campo
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function DashboardPage() {
  return <DashboardContent />
}
