'use client'

import { useEffect, useState } from 'react'
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { supabase } from '@/lib/supabase'
import LoadingScreen from '@/components/LoadingScreen'

function EstadisticasContent() {
  const [stats, setStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStats()
  }, [])

  const fetchStats = async () => {
    try {
      const [feedbacksRes, inspRes, checkRes] = await Promise.all([
        supabase.from('customer_feedback').select('*, stores(name)'),
        supabase.from('supervisor_inspections').select('*, stores(name)'),
        supabase.from('assistant_checklists').select('checklist_type')
      ])

      const feedbacks = feedbacksRes.data || []
      const inspections = inspRes.data || []
      const checklists = checkRes.data || []

      setStats({
        feedbacksByStore: processFeedbacksByStore(feedbacks),
        inspectionsByStore: processInspectionsByStore(inspections),
        checklistsByType: processChecklistsByType(checklists),
        npsDistribution: processNPSDistribution(feedbacks)
      })
    } catch (err) {
      console.error('Error:', err)
    } finally {
      setLoading(false)
    }
  }

  const processFeedbacksByStore = (feedbacks: any[]) => {
    const grouped = feedbacks.reduce((acc, f) => {
      const store = f.stores?.name || 'Sede Remota'
      if (!acc[store]) acc[store] = { count: 0, totalNPS: 0 }
      acc[store].count++
      acc[store].totalNPS += f.nps_score || 0
      return acc
    }, {})

    return Object.entries(grouped)
      .map(([name, data]: [string, any]) => ({
        name: name.length > 12 ? name.substring(0, 12) + '..' : name,
        feedbacks: data.count,
        avgNPS: Math.round(data.totalNPS / data.count)
      }))
      .sort((a, b) => b.feedbacks - a.feedbacks)
      .slice(0, 8)
  }

  const processInspectionsByStore = (inspections: any[]) => {
    const grouped = inspections.reduce((acc, i) => {
      const store = i.stores?.name || 'Sede Remota'
      if (!acc[store]) acc[store] = { count: 0, totalScore: 0 }
      acc[store].count++
      acc[store].totalScore += i.overall_score || 0
      return acc
    }, {})

    return Object.entries(grouped)
      .map(([name, data]: [string, any]) => ({
        name: name.length > 12 ? name.substring(0, 12) + '..' : name,
        inspecciones: data.count,
        avgScore: Math.round(data.totalScore / data.count)
      }))
      .sort((a, b) => b.inspecciones - a.inspecciones)
      .slice(0, 8)
  }

  const processChecklistsByType = (checklists: any[]) => {
    const types = ['daily', 'temperaturas', 'producto_sobrante', 'recorrido', 'cierre', 'apertura']
    return types.map(type => ({
      name: type.charAt(0).toUpperCase() + type.slice(1).replace('_', ' '),
      value: checklists.filter(c => c.checklist_type === type).length
    }))
  }

  const processNPSDistribution = (feedbacks: any[]) => {
    return [
      { category: 'Promotores', value: feedbacks.filter(f => f.nps_score >= 9).length, color: '#e31837' },
      { category: 'Pasivos', value: feedbacks.filter(f => f.nps_score >= 7 && f.nps_score <= 8).length, color: '#fdc82f' },
      { category: 'Detractores', value: feedbacks.filter(f => f.nps_score <= 6).length, color: '#1a1a1a' }
    ]
  }

  if (loading) {
    return <LoadingScreen message="Sincronizando Métrica Global..." />
  }

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Estadísticas Globales</h1>
            <p className="text-gray-600 mt-2">Seguimiento analítico de desempeño y calidad de red.</p>
          </div>
          <div className="flex items-center gap-3 bg-white px-4 py-2.5 rounded-xl border border-gray-100 shadow-sm">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Motor de Análisis Activo</p>
          </div>
        </div>

        <div className="space-y-10">
          {/* NPS Card */}
          <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-10">
              <div>
                <h2 className="text-xl font-black text-gray-900 tracking-tight uppercase italic">Opinión del Consumidor <span className="text-gray-300 font-normal not-italic mx-2">|</span> <span className="text-[#e31837]">Voz de Marca</span></h2>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em] mt-1">Comparativa de participación por unidad</p>
              </div>
            </div>
            <div className="h-[380px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.feedbacksByStore} margin={{ top: 20, right: 10, left: 10, bottom: 40 }}>
                  <CartesianGrid strokeDasharray="2 2" vertical={false} stroke="#f3f4f6" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" tick={{ fontSize: 9, fontWeight: 900, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 9, fontWeight: 900, fill: '#cbd5e1' }} />
                  <Tooltip cursor={{ fill: '#f8fafb' }} contentStyle={{ borderRadius: '0.75rem', border: '1px solid #f3f4f6', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  <Legend iconType="rect" wrapperStyle={{ paddingTop: 30, fontSize: 10, fontWeight: 900, textTransform: 'uppercase' }} />
                  <Bar dataKey="feedbacks" fill="#e31837" name="Participaciones" radius={[4, 4, 0, 0]} barSize={35} />
                  <Bar dataKey="avgNPS" fill="#1a1a1a" name="Promedio NPS" radius={[4, 4, 0, 0]} barSize={35} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Quality Line Chart */}
          <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-10">
              <div>
                <h2 className="text-xl font-black text-gray-900 tracking-tight uppercase italic">Rendimiento Operativo <span className="text-gray-300 font-normal not-italic mx-2">|</span> <span className="text-[#fdc82f]">Auditoría</span></h2>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em] mt-1">Evolución de inspecciones y efectividad %</p>
              </div>
            </div>
            <div className="h-[380px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={stats.inspectionsByStore} margin={{ top: 20, right: 30, left: 20, bottom: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" tick={{ fontSize: 9, fontWeight: 900, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 9, fontWeight: 900, fill: '#cbd5e1' }} />
                  <Tooltip contentStyle={{ borderRadius: '0.75rem', border: '1px solid #f3f4f6', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  <Legend iconType="circle" wrapperStyle={{ paddingTop: 30, fontSize: 10, fontWeight: 900, textTransform: 'uppercase' }} />
                  <Line type="monotone" dataKey="inspecciones" stroke="#e31837" strokeWidth={4} dot={{ r: 5, fill: '#e31837', strokeWidth: 2, stroke: '#fff' }} activeDot={{ r: 8 }} name="Frecuencia Auditoría" />
                  <Line type="monotone" dataKey="avgScore" stroke="#fdc82f" strokeWidth={4} dot={{ r: 5, fill: '#fdc82f', strokeWidth: 2, stroke: '#fff' }} activeDot={{ r: 8 }} name="Efectividad Media %" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pb-10">
            {/* Checklists Pie */}
            <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-sm flex flex-col items-center">
              <h2 className="text-lg font-black text-gray-900 mb-8 tracking-tight uppercase italic">Estructura Operativa</h2>
              <div className="h-[320px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={stats.checklistsByType}
                      cx="50%"
                      cy="50%"
                      innerRadius={70}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                      nameKey="name"
                      stroke="none"
                    >
                      {stats.checklistsByType.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={['#e31837', '#fdc82f', '#1a1a1a', '#666666', '#999999', '#cccccc'][index % 6]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: '0.75rem', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* NPS Distribution */}
            <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-sm flex flex-col items-center justify-center overflow-hidden">
              <h2 className="text-lg font-black text-gray-900 mb-8 tracking-tight uppercase italic">Fidelidad Global</h2>
              <div className="h-[320px] w-full relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={stats.npsDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={0}
                      outerRadius={110}
                      dataKey="value"
                      nameKey="category"
                      label={({ percent }) => `${((percent || 0) * 100).toFixed(0)}%`}
                      stroke="#fff"
                      strokeWidth={4}
                    >
                      {stats.npsDistribution.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: '0.75rem', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function EstadisticasPage() {
  return <EstadisticasContent />
}
