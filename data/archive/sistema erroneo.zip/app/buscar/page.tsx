'use client'

import { useState } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'

function BuscarContent() {
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get('q') || ''

  const [query, setQuery] = useState(initialQuery)
  const [results, setResults] = useState<any>({
    stores: [],
    users: [],
    inspections: [],
    feedbacks: [],
    checklists: []
  })
  const [loading, setLoading] = useState(false)
  const [searched, setSearched] = useState(false)

  const handleSearch = async () => {
    if (!query.trim()) return

    setLoading(true)
    setSearched(true)

    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      // Buscar en tiendas
      const storesRes = await fetch(
        `${url}/rest/v1/stores?or=(name.ilike.*${query}*,city.ilike.*${query}*,code.ilike.*${query}*)&limit=10`,
        { headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` } }
      )
      const stores = await storesRes.json()

      // Buscar en usuarios
      const usersRes = await fetch(
        `${url}/rest/v1/users?or=(full_name.ilike.*${query}*,email.ilike.*${query}*)&limit=10`,
        { headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` } }
      )
      const users = await usersRes.json()

      // Buscar en inspecciones
      const inspRes = await fetch(
        `${url}/rest/v1/supervisor_inspections?select=*,stores(name),users(full_name)&limit=10`,
        { headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` } }
      )
      const inspections = await inspRes.json()

      // Buscar en feedbacks
      const feedbacksRes = await fetch(
        `${url}/rest/v1/customer_feedback?select=*,stores(name)&limit=10`,
        { headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` } }
      )
      const feedbacks = await feedbacksRes.json()

      // Buscar en checklists
      const checklistsRes = await fetch(
        `${url}/rest/v1/assistant_checklists?select=*,stores(name)&limit=10`,
        { headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` } }
      )
      const checklists = await checklistsRes.json()

      setResults({
        stores: Array.isArray(stores) ? stores : [],
        users: Array.isArray(users) ? users : [],
        inspections: Array.isArray(inspections) ? inspections : [],
        feedbacks: Array.isArray(feedbacks) ? feedbacks : [],
        checklists: Array.isArray(checklists) ? checklists : []
      })
    } catch (err) {
      console.error('Error:', err)
    }

    setLoading(false)
  }

  const totalResults = results.stores.length + results.users.length +
    results.inspections.length + results.feedbacks.length +
    results.checklists.length

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Buscador Global</h1>
            <p className="text-gray-600 mt-2">Localización centralizada de registros, usuarios y transacciones.</p>
          </div>
        </div>
        {/* Search Bar - Modernized */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <span className="absolute left-5 top-1/2 -translate-y-1/2 text-xl opacity-20">🔍</span>
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Busca por nombre, ID, ciudad o correo..."
                className="w-full pl-14 pr-6 py-4 bg-gray-50 border-0 rounded-[1.5rem] text-sm font-bold text-gray-900 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
              />
            </div>
            <button
              onClick={handleSearch}
              disabled={loading}
              className="px-10 py-4 bg-gray-900 text-white font-black text-[11px] tracking-widest uppercase rounded-[1.5rem] transition-all hover:bg-[#e31837] shadow-lg shadow-gray-100 disabled:bg-gray-200"
            >
              {loading ? 'Consultando...' : 'Ejecutar Búsqueda'}
            </button>
          </div>
        </div>

        {/* Results */}
        {searched && !loading && (
          <div className="space-y-10 animate-in slide-in-from-bottom-2 duration-700 pb-10">
            {totalResults === 0 ? (
              <div className="text-center py-20 bg-white border-2 border-dashed border-gray-100 rounded-[3rem]">
                <div className="text-6xl mb-6 grayscale opacity-20">🌑</div>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.4em]">Sin coincidencias para la consulta técnica</p>
              </div>
            ) : (
              <>
                <div className="bg-gray-900 text-white rounded-[1rem] px-6 py-4 inline-block shadow-xl">
                  <p className="text-[10px] font-black uppercase tracking-widest">
                    Expedientes Procesados: <span className="text-[#fdc82f] ml-1">{totalResults}</span>
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Tiendas */}
                  {results.stores.length > 0 && (
                    <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm p-8">
                      <h2 className="text-sm font-black text-gray-900 mb-6 uppercase italic tracking-tight flex items-center gap-2">
                        <span className="text-xl">🏪</span> UNIDADES ({results.stores.length})
                      </h2>
                      <div className="space-y-3">
                        {results.stores.map((store: any) => (
                          <Link
                            key={store.id}
                            href="/tiendas"
                            className="block p-5 bg-gray-50/50 hover:bg-white border border-transparent hover:border-gray-100 rounded-2xl transition-all group"
                          >
                            <p className="font-black text-gray-900 group-hover:text-[#e31837] transition-colors uppercase tracking-tight italic">{store.name}</p>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter mt-1">{store.address}, {store.city}</p>
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Usuarios */}
                  {results.users.length > 0 && (
                    <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm p-8">
                      <h2 className="text-sm font-black text-gray-900 mb-6 uppercase italic tracking-tight flex items-center gap-2">
                        <span className="text-xl">👥</span> STAFF ({results.users.length})
                      </h2>
                      <div className="space-y-3">
                        {results.users.map((user: any) => (
                          <Link
                            key={user.id}
                            href="/usuarios"
                            className="block p-5 bg-gray-50/50 hover:bg-white border border-transparent hover:border-gray-100 rounded-2xl transition-all group"
                          >
                            <p className="font-black text-gray-900 group-hover:text-[#e31837] transition-colors uppercase tracking-tight italic">{user.full_name}</p>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter mt-1">{user.email} <span className="mx-2 text-gray-200">/</span> {user.role}</p>
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Inspecciones */}
                  {results.inspections.length > 0 && (
                    <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm p-8">
                      <h2 className="text-sm font-black text-gray-900 mb-6 uppercase italic tracking-tight flex items-center gap-2">
                        <span className="text-xl">📋</span> AUDITORÍAS ({results.inspections.length})
                      </h2>
                      <div className="space-y-3">
                        {results.inspections.map((insp: any) => (
                          <Link
                            key={insp.id}
                            href="/inspecciones"
                            className="block p-5 bg-gray-50/50 hover:bg-white border border-transparent hover:border-gray-100 rounded-2xl transition-all group"
                          >
                            <div className="flex justify-between items-center mb-1">
                              <p className="font-black text-gray-900 group-hover:text-[#e31837] transition-colors uppercase tracking-tight italic">{insp.stores?.name}</p>
                              <span className="text-xs font-black text-gray-900 tabular-nums italic">{insp.overall_score}%</span>
                            </div>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter italic">
                              {new Date(insp.inspection_date).toLocaleDateString('es-MX')} <span className="mx-2 text-gray-200">/</span> EXAMINÓ: {insp.users?.full_name}
                            </p>
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Feedbacks */}
                  {results.feedbacks.length > 0 && (
                    <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm p-8">
                      <h2 className="text-sm font-black text-gray-900 mb-6 uppercase italic tracking-tight flex items-center gap-2">
                        <span className="text-xl">💬</span> SATISFACCIÓN ({results.feedbacks.length})
                      </h2>
                      <div className="space-y-3">
                        {results.feedbacks.map((fb: any) => (
                          <Link
                            key={fb.id}
                            href="/feedback"
                            className="block p-5 bg-gray-50/50 hover:bg-white border border-transparent hover:border-gray-100 rounded-2xl transition-all group"
                          >
                            <div className="flex justify-between items-center mb-1">
                              <p className="font-black text-gray-900 group-hover:text-[#e31837] transition-colors uppercase tracking-tight italic">{fb.stores?.name}</p>
                              <span className="text-[10px] font-black bg-[#fdc82f]/10 text-gray-900 px-2 rounded tracking-widest">NPS: {fb.nps_score}</span>
                            </div>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter italic">
                              {new Date(fb.submission_date).toLocaleDateString('es-MX')}
                            </p>
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        )}

        {!searched && (
          <div className="text-center py-32 bg-white border-2 border-dashed border-gray-100 rounded-[3.5rem]">
            <div className="text-7xl mb-6 grayscale opacity-10">🔎</div>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.5em] italic">Introducir parámetros para análisis de red</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default function BuscarPage() {
  return <BuscarContent />
}