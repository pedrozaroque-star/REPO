'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'
import InspectionForm from '@/components/inspections/InspectionForm'
import { supabase } from '@/lib/supabase'
import { canEditChecklist } from '@/lib/checklistPermissions'

export default function EditarInspeccionPage() {
  const { id } = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const [inspection, setInspection] = useState<any>(null)
  const [stores, setStores] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (user && id) fetchData()
  }, [user, id])

  if (!user) return null

  const fetchData = async () => {
    try {
      const { data: storesData } = await supabase.from('stores').select('*').order('name')
      setStores(storesData || [])

      const { data: item, error: dbError } = await supabase
        .from('supervisor_inspections')
        .select('*')
        .eq('id', id)
        .single()

      if (dbError || !item) throw new Error('Inspección no encontrada')

      const dateToCheck = item.created_at || item.inspection_date

      const permissions = canEditChecklist(
        dateToCheck,
        user.role,
        item.inspector_id,
        user.id,
        item.start_time,
        item.estatus_admin
      )

      if (!permissions.canEdit) {
        throw new Error(permissions.reason)
      }

      setInspection(item)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <div className="flex h-screen items-center justify-center">Cargando...</div>

  if (error) return (
    <div className="flex h-[80vh] items-center justify-center flex-col animate-in fade-in duration-500">
      <div className="bg-white p-12 rounded-[2.5rem] border border-gray-100 shadow-sm text-center max-w-md">
        <div className="text-6xl mb-6">🔒</div>
        <h2 className="text-2xl font-black text-gray-900 tracking-tight mb-2">Acceso Denegado</h2>
        <p className="text-gray-500 font-medium mb-8 leading-relaxed">{error}</p>
        <button
          onClick={() => router.push('/inspecciones')}
          className="w-full bg-gray-900 text-white px-8 py-4 rounded-2xl font-black text-[11px] tracking-widest uppercase hover:bg-[#e31837] transition-all shadow-xl active:scale-95"
        >
          Volver al Historial
        </button>
      </div>
    </div>
  )

  return (
    <div className="p-8 lg:p-10 space-y-10 animate-in fade-in duration-700">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Aviso de bloqueo por revisión 🔒 */}
        <div className="p-6 bg-amber-50 border border-amber-200 rounded-[2rem] flex items-start gap-4 animate-in slide-in-from-top duration-700">
          <div className="text-2xl mt-0.5">ℹ️</div>
          <div>
            <p className="text-sm font-bold text-amber-900 leading-snug">Restricción de Auditoría</p>
            <p className="text-xs font-medium text-amber-700 mt-1 leading-relaxed">
              Esta inspección quedará bloqueada para edición una vez que sea validada por el Admin.
              Por favor revisa que todos los hallazgos estén bien documentados antes de cerrar.
            </p>
          </div>
        </div>

        <InspectionForm user={user} initialData={inspection} stores={stores} />
      </div>
    </div>
  )
}