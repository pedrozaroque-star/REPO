'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/ProtectedRoute'
import ReviewModal from '@/components/ReviewModal'
import { getStatusColor, getStatusLabel, formatDateLA, canEditChecklist } from '@/lib/checklistPermissions'
import { supabase } from '@/lib/supabase'
import LoadingScreen from '@/components/LoadingScreen'

function InspeccionesContent() {
  const router = useRouter()
  const { user } = useAuth()
  const [inspections, setInspections] = useState<any[]>([])
  const [stats, setStats] = useState({
    total: 0,
    pendientes: 0,
    cerrados: 0,
    avgOverall: 0,
    avgServicio: 0,
    avgCarnes: 0,
    avgAlimentos: 0,
    avgTortillas: 0,
    avgLimpieza: 0,
    avgBitacoras: 0,
    avgAseo: 0
  })
  const [loading, setLoading] = useState(true)
  const [storeFilter, setStoreFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [stores, setStores] = useState<any[]>([])
  const [showReviewModal, setShowReviewModal] = useState(false)

  useEffect(() => {
    if (user) fetchData()
  }, [storeFilter, statusFilter, user])

  const fetchData = async () => {
    try {
      setLoading(true)

      const { data: storesData } = await supabase.from('stores').select('*').order('name', { ascending: true })
      setStores(Array.isArray(storesData) ? storesData : [])

      let query = supabase
        .from('supervisor_inspections')
        .select(`
          *,
          stores (name, code),
          users (full_name)
        `)
        .order('inspection_date', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(100)

      if (storeFilter !== 'all') {
        query = query.eq('store_id', storeFilter)
      }

      const { data: inspData, error } = await query
      if (error) throw error

      let formattedData = Array.isArray(inspData) ? inspData.map(item => ({
        ...item,
        store_name: item.stores?.name || 'N/A',
        supervisor_name: item.users?.full_name || item.supervisor_name
      })) : []

      if (statusFilter !== 'all') {
        formattedData = formattedData.filter(item => {
          const status = item.estatus_admin || 'pendiente'
          return status === statusFilter
        })
      }

      setInspections(formattedData)

      const { data: allInsp } = await supabase.from('supervisor_inspections').select('overall_score,servicio_score,carnes_score,alimentos_score,tortillas_score,limpieza_score,bitacoras_score,aseo_score,estatus_admin')
      const allInspArray = Array.isArray(allInsp) ? allInsp : []

      const calcAvg = (field: string) =>
        allInspArray.length > 0
          ? Math.round((allInspArray.reduce((sum: number, i: any) => sum + (i[field] || 0), 0) / allInspArray.length) * 10) / 10
          : 0

      setStats({
        total: allInspArray.length,
        pendientes: allInspArray.filter(i => (i.estatus_admin || 'pendiente') === 'pendiente').length,
        cerrados: allInspArray.filter(i => (i.estatus_admin || 'pendiente') === 'cerrado').length,
        avgOverall: calcAvg('overall_score'),
        avgServicio: calcAvg('servicio_score'),
        avgCarnes: calcAvg('carnes_score'),
        avgAlimentos: calcAvg('alimentos_score'),
        avgTortillas: calcAvg('tortillas_score'),
        avgLimpieza: calcAvg('limpieza_score'),
        avgBitacoras: calcAvg('bitacoras_score'),
        avgAseo: calcAvg('aseo_score')
      })

      setLoading(false)
    } catch (err) {
      console.error('Error:', err)
      setLoading(false)
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-600'
    if (score >= 80) return 'text-[#fdc82f]'
    if (score >= 70) return 'text-gray-900'
    return 'text-[#e31837]'
  }

  const getStatusBadge = (item: any) => {
    const status = item.estatus_admin || 'pendiente'
    const colorClass = getStatusColor(status)
    const label = getStatusLabel(status)

    return (
      <span className={`px-2.5 py-1 rounded-md text-xs font-bold capitalize tracking-wide border border-current bg-opacity-5 transition-all ${colorClass}`}>
        {label.toLowerCase()}
      </span>
    )
  }

  const canReview = () => {
    return user?.role?.toLowerCase() === 'admin'
  }

  const canCreate = () => {
    const role = user?.role?.toLowerCase()
    return role === 'supervisor'
  }

  if (loading) {
    return <LoadingScreen message="Sincronizando Auditoría de Campo..." />
  }

  if (!user) return null

  return (
    <div className="p-6">
      <div className="max-w-[94%] mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="w-16 h-16 rounded-2xl bg-gray-900 flex items-center justify-center shadow-lg">
              <span className="text-3xl">📋</span>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Log de Inspecciones</h1>
              <p className="text-gray-600 mt-1">Monitoreo de estándares operativos y de servicio.</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {canReview() && inspections.length > 0 && (
              <button
                onClick={() => setShowReviewModal(true)}
                className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-all shadow-sm flex items-center gap-2"
              >
                ✓ Revisión Administrativa
              </button>
            )}
            {canCreate() && (
              <button
                onClick={() => router.push('/inspecciones/nueva')}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-all shadow-sm flex items-center gap-2"
              >
                ➕ Nueva Inspección
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-10 gap-4 mb-8">
          {[
            { l: 'Total', v: stats.total },
            { l: 'Pend.', v: stats.pendientes },
            { l: 'Global', v: stats.avgOverall },
            { l: 'Serv.', v: stats.avgServicio },
            { l: 'Carnes', v: stats.avgCarnes },
            { l: 'Alim.', v: stats.avgAlimentos },
            { l: 'Tort.', v: stats.avgTortillas },
            { l: 'Limp.', v: stats.avgLimpieza },
            { l: 'Bitac.', v: stats.avgBitacoras },
            { l: 'Aseo', v: stats.avgAseo }
          ].map((s, i) => (
            <div key={i} className="bg-white p-3 rounded-xl border border-gray-100 shadow-sm text-center font-medium">
              <p className="text-[10px] text-gray-400 uppercase font-bold truncate mb-1">{s.l}</p>
              <p className="text-lg font-bold text-gray-900 tabular-nums">{s.v}</p>
            </div>
          ))}
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-wrap gap-6 items-center justify-between mb-8">
          <div className="flex items-center gap-6">
            <div className="relative">
              <select
                value={storeFilter}
                onChange={(e) => setStoreFilter(e.target.value)}
                className="appearance-none bg-gray-50 border border-gray-200 rounded-lg px-4 py-2 pr-10 text-sm font-medium text-gray-700 focus:ring-2 focus:ring-red-500 outline-none cursor-pointer"
              >
                <option value="all">Todas las Tiendas</option>
                {stores.map(store => (
                  <option key={store.id} value={store.id}>{store.name.toUpperCase()}</option>
                ))}
              </select>
              <span className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-xs">▼</span>
            </div>

            {canReview() && (
              <div className="flex bg-gray-100 p-1 rounded-lg gap-1 border border-gray-200">
                {['all', 'pendiente', 'cerrado'].map(f => (
                  <button
                    key={f}
                    onClick={() => setStatusFilter(f)}
                    className={`px-4 py-1.5 rounded-md text-xs font-bold uppercase transition-all ${statusFilter === f
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                      }`}
                  >
                    {f === 'all' ? 'Todos' : f}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Expedientes:</span>
            <span className="px-3 py-1 bg-gray-900 text-white rounded-lg text-xs font-bold">{inspections.length}</span>
          </div>
        </div>

        {/* Table Section */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100 flex-1 flex flex-col min-h-0">
          <div className="overflow-y-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50 border-b border-gray-100 sticky top-0 z-10">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Fecha / Hora</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Inspector</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider hidden md:table-cell">Métricas</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Hallazgos</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Resultado</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-center">Estatus</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {inspections.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-gray-500 font-medium">
                      No se encontraron registros de auditoría.
                    </td>
                  </tr>
                ) : (
                  inspections.map((item) => {
                    const permissions = canEditChecklist(
                      item.inspection_date || item.created_at,
                      user.role || '',
                      item.inspector_id,
                      user.id,
                      item.start_time,
                      item.estatus_admin
                    )

                    return (
                      <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex flex-col">
                            <span className="text-sm font-semibold text-gray-900">{formatDateLA(item.inspection_date || item.created_at)}</span>
                            <span className="text-xs text-brand font-bold uppercase">{item.store_name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-col">
                            <span className="text-sm text-gray-900 font-medium">{item.supervisor_name}</span>
                            <span className="text-[10px] text-gray-400 font-bold uppercase">ID: {item.stores?.code}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 hidden md:table-cell">
                          <div className="flex items-center gap-4">
                            <div className="text-center">
                              <p className="text-[10px] text-gray-400 uppercase font-bold">Gral</p>
                              <p className={`text-lg font-bold ${getScoreColor(item.overall_score)}`}>{item.overall_score}</p>
                            </div>
                            <div className="flex gap-1 opacity-50">
                              {[item.servicio_score, item.limpieza_score].map((s, i) => (
                                <div key={i} className={`w-1.5 h-5 rounded-full ${s >= 90 ? 'bg-emerald-500' : s >= 80 ? 'bg-amber-400' : 'bg-brand'}`}></div>
                              ))}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          {item.observaciones ? (
                            <p className="text-xs text-gray-600 line-clamp-1 max-w-[150px] italic">
                              {item.observaciones}
                            </p>
                          ) : (
                            <span className="text-[10px] text-gray-300 font-bold uppercase">— Sin Obs —</span>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <div className="w-12 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${item.overall_score >= 90 ? 'bg-emerald-500' : item.overall_score >= 80 ? 'bg-amber-400' : 'bg-brand'}`}
                                style={{ width: `${item.overall_score}%` }}
                              ></div>
                            </div>
                            <span className={`text-sm font-bold ${getScoreColor(item.overall_score)}`}>
                              {item.overall_score}%
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-center">
                          {getStatusBadge(item)}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => router.push(`/inspecciones/ver/${item.id}`)}
                              className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                              title="Ver Ficha"
                            >
                              👁️
                            </button>
                            {permissions.canEdit && (
                              <button
                                onClick={() => router.push(`/inspecciones/editar/${item.id}`)}
                                className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                                title="Editar"
                              >
                                ✏️
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {showReviewModal && user && (
        <ReviewModal
          isOpen={showReviewModal}
          onClose={() => setShowReviewModal(false)}
          checklists={inspections}
          checklistType="supervisor"
          currentUser={{
            id: user.id,
            name: (user as any).name || user.email,
            email: user.email,
            role: user.role
          }}
          onSave={() => {
            setShowReviewModal(false)
            fetchData()
          }}
        />
      )}
    </div>
  )
}

export default function InspeccionesPage() {
  return <InspeccionesContent />
}
