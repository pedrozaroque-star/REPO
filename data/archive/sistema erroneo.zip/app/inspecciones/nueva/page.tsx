'use client'

import { useEffect, useState } from 'react'
import { useAuth } from '@/components/ProtectedRoute'
import InspectionForm from '@/components/inspections/InspectionForm'
import { supabase } from '@/lib/supabase'

export default function NuevaInspeccionPage() {
  const { user } = useAuth()
  const [stores, setStores] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStores = async () => {
      const { data } = await supabase.from('stores').select('*').order('name')
      setStores(data || [])
      setLoading(false)
    }
    fetchStores()
  }, [])

  if (loading) return <div className="flex h-screen items-center justify-center">Cargando...</div>

  return (
    <div className="p-8 lg:p-10 space-y-10 animate-in fade-in duration-700">
      <div className="max-w-7xl mx-auto">
        <InspectionForm user={user} stores={stores} />
      </div>
    </div>
  )
}