'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/components/ProtectedRoute'

// --- CONFIGURACIÓN DE DATOS ---
const PRESETS = [
    { id: 'apertura', label: 'Apertura', start: '08:00', end: '16:00', color: 'bg-amber-100 text-amber-800 border-amber-300' },
    { id: 'am', label: 'Mañana', start: '09:00', end: '17:00', color: 'bg-emerald-100 text-emerald-800 border-emerald-300' },
    { id: 'inter', label: 'Intermedio', start: '14:00', end: '22:00', color: 'bg-blue-100 text-blue-800 border-blue-300' },
    { id: 'pm', label: 'Tarde/Noche', start: '17:00', end: '01:00', color: 'bg-indigo-100 text-indigo-800 border-indigo-300' },
    { id: 'cierre', label: 'Cierre', start: '17:00', end: '02:00', color: 'bg-purple-100 text-purple-800 border-purple-300' },
    { id: 'cierre_fds', label: 'Cierre FDS', start: '17:00', end: '04:00', color: 'bg-fuchsia-100 text-fuchsia-800 border-fuchsia-300' },
    { id: 'visita', label: 'Visita Sup.', start: '09:00', end: '17:00', color: 'bg-cyan-50 text-cyan-700 border-cyan-300 border-dashed' },
]

// --- UTILIDADES ---
const getMonday = (d: Date) => {
    const date = new Date(d);
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(date.setDate(diff));
}
const addDays = (d: Date, days: number) => {
    const result = new Date(d);
    result.setDate(result.getDate() + days);
    return result;
}
const formatDateISO = (d: Date) => d.toISOString().split('T')[0];
const formatDateNice = (d: Date) => {
    const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    return `${d.getDate()} ${months[d.getMonth()]}`;
}
const getDayName = (d: Date) => ['DOM', 'LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB'][d.getDay()];

// --- SEMÁFORO (LÓGICA OPERATIVA) ---
const calculateDailyStatus = (dateStr: string, shifts: any[], users: any[]) => {
    // 1. Filtrar turnos del día
    const dayShifts = shifts.filter(s => s.date === dateStr);

    // CASO 1: Tienda sola (Nadie programado)
    if (dayShifts.length === 0) {
        return {
            status: 'empty',
            label: 'VACÍO',
            color: 'bg-gray-100 text-gray-400 border-gray-200'
        };
    }

    // 2. Analizar Cobertura de Turnos (Sin importar el rango/rol)
    // Se considera "AM" si alguien entra temprano (antes de la 1 PM)
    const hasMorning = dayShifts.some(s => {
        const startHour = parseInt(s.start_time?.split(':')[0] || '0');
        return startHour < 13;
    });

    // Se considera "PM" si alguien cubre la tarde/noche
    // Criterio: Entra tarde (>= 2 PM) O sale tarde (>= 8 PM) O es turno nocturno (cierre otro día)
    const hasEvening = dayShifts.some(s => {
        const start = parseInt(s.start_time?.split(':')[0] || '0');
        const end = parseInt(s.end_time?.split(':')[0] || '0');
        return start >= 14 || end >= 20 || end < start;
    });

    // CASO 2: Cobertura Total (Hay alguien en AM y alguien en PM)
    if (hasMorning && hasEvening) {
        return {
            status: 'ok',
            label: 'CUBIERTO',
            color: 'bg-emerald-500 text-white shadow-emerald-200 shadow-md'
        };
    }

    // CASO 3: Falta algún turno
    return {
        status: 'bad',
        label: !hasMorning ? 'FALTA AM' : 'FALTA PM',
        color: 'bg-red-500 text-white shadow-red-200 shadow-md'
    };
}

// --- COMPONENTE PRINCIPAL ---
function ScheduleManager() {
    const { user } = useAuth()
    const canEdit = ['admin', 'supervisor'].some(role => user?.role?.toLowerCase().includes(role));

    const [viewMode, setViewMode] = useState<'dashboard' | 'editor'>('dashboard');
    const [currentDate, setCurrentDate] = useState(new Date())
    const [stores, setStores] = useState<any[]>([])
    const [selectedStoreId, setSelectedStoreId] = useState<string>('')

    const [allSchedules, setAllSchedules] = useState<any[]>([])
    const [allUsers, setAllUsers] = useState<any[]>([])
    const [localUsers, setLocalUsers] = useState<any[]>([])
    const [localSchedules, setLocalSchedules] = useState<any[]>([])
    const [loading, setLoading] = useState(true)
    const [editingShift, setEditingShift] = useState<any>(null);

    // --- ESTADOS PARA DRAG & DROP (COPIAR) ---
    const [isDragging, setIsDragging] = useState(false);
    const [dragSource, setDragSource] = useState<any>(null);

    const weekStart = getMonday(currentDate)
    const weekDays = Array.from({ length: 7 }).map((_, i) => addDays(weekStart, i))

    useEffect(() => {
        async function init() {
            const { data } = await supabase.from('stores').select('*').order('name')
            if (data && data.length > 0) {
                setStores(data)
                setSelectedStoreId(String(data[0].id))
            }
        }
        init()
    }, [])

    useEffect(() => { loadGlobalData() }, [currentDate, viewMode])

    useEffect(() => {
        if (selectedStoreId && viewMode === 'editor') filterLocalData()
    }, [selectedStoreId, allSchedules, allUsers, viewMode])

    // Listener global para soltar el click
    useEffect(() => {
        const handleMouseUp = () => {
            setIsDragging(false);
            setDragSource(null);
        };
        window.addEventListener('mouseup', handleMouseUp);
        return () => window.removeEventListener('mouseup', handleMouseUp);
    }, []);

    const loadGlobalData = async () => {
        setLoading(true)
        try {
            const startStr = formatDateISO(weekStart)
            const endStr = formatDateISO(addDays(weekStart, 6))
            const { data: sData } = await supabase.from('schedules').select('*').gte('date', startStr).lte('date', endStr)
            setAllSchedules(sData || [])
            const { data: uData } = await supabase.from('users').select('id, full_name, role, store_id').eq('is_active', true)
            setAllUsers(uData || [])
        } catch (e) { console.error(e) } finally { setLoading(false) }
    }

    const filterLocalData = () => {
        const currentStore = stores.find(s => String(s.id) === String(selectedStoreId));
        const supId = currentStore?.supervisor_id;
        const filteredUsers = allUsers.filter(u =>
            String(u.store_id) === String(selectedStoreId) || String(u.id) === String(supId)
        ).sort((a, b) => {
            const isLeaderA = ['manager', 'sup', 'gerente'].some(r => a.role.toLowerCase().includes(r));
            const isLeaderB = ['manager', 'sup', 'gerente'].some(r => b.role.toLowerCase().includes(r));
            if (isLeaderA && !isLeaderB) return -1;
            if (!isLeaderA && isLeaderB) return 1;
            return a.full_name.localeCompare(b.full_name);
        });
        setLocalUsers(filteredUsers);
        const filteredSchedules = allSchedules.filter(s => String(s.store_id) === String(selectedStoreId));
        setLocalSchedules(filteredSchedules);
    }

    // --- DRAG & DROP ---
    const handleCellMouseDown = (e: React.MouseEvent, user: any, date: Date, shift: any) => {
        if (e.shiftKey && canEdit) {
            e.preventDefault();
            setIsDragging(true);
            setDragSource(shift);
        } else {
            openEditModal(user, date, shift);
        }
    };

    const handleCellMouseEnter = async (user: any, date: Date) => {
        if (isDragging && canEdit) {
            await duplicateShift(user, date, dragSource);
        }
    };

    const duplicateShift = async (targetUser: any, targetDate: Date, sourceShift: any) => {
        const dateStr = formatDateISO(targetDate);
        const isDelete = !sourceShift;

        const tempSchedules = allSchedules.filter(s => !(String(s.user_id) === String(targetUser.id) && s.date === dateStr));

        if (!isDelete) {
            tempSchedules.push({
                user_id: targetUser.id,
                store_id: parseInt(selectedStoreId),
                date: dateStr,
                shift_label: sourceShift.shift_label,
                start_time: sourceShift.start_time,
                end_time: sourceShift.end_time,
                role: targetUser.role
            });
        }
        setAllSchedules([...tempSchedules]);

        if (isDelete) {
            await supabase.from('schedules').delete().match({ user_id: targetUser.id, date: dateStr });
        } else {
            await supabase.from('schedules').upsert({
                user_id: targetUser.id,
                store_id: parseInt(selectedStoreId),
                date: dateStr,
                shift_label: sourceShift.shift_label,
                start_time: sourceShift.start_time,
                end_time: sourceShift.end_time,
                role: targetUser.role
            }, { onConflict: 'user_id, date' });
        }
    };

    // --- GUARDADO ---
    const saveShift = async () => {
        if (!editingShift || !canEdit) return;
        const dateStr = formatDateISO(editingShift.date);
        const isDelete = !editingShift.start || !editingShift.end;

        let labelToSave = 'Custom';
        const preset = PRESETS.find(p => p.start === editingShift.start && p.end === editingShift.end);
        if (preset) labelToSave = preset.label;
        else if (editingShift.presetId === 'visita') labelToSave = 'Visita Sup.';

        const newEntry = {
            user_id: parseInt(editingShift.userId),
            store_id: parseInt(selectedStoreId),
            date: dateStr,
            shift_label: labelToSave,
            start_time: editingShift.start,
            end_time: editingShift.end,
            role: editingShift.userRole
        }

        const tempSchedules = allSchedules.filter(s => !(String(s.user_id) === String(editingShift.userId) && s.date === dateStr));
        if (!isDelete) tempSchedules.push(newEntry);
        setAllSchedules(tempSchedules);
        setEditingShift(null);

        if (isDelete) await supabase.from('schedules').delete().match({ user_id: editingShift.userId, date: dateStr })
        else await supabase.from('schedules').upsert(newEntry, { onConflict: 'user_id, date' })
    }

    const openEditModal = (user: any, date: Date, currentShift: any) => {
        if (!canEdit) return;
        setEditingShift({
            userId: user.id, userName: user.full_name, userRole: user.role,
            date: date, start: currentShift?.start_time || '', end: currentShift?.end_time || '',
            presetId: currentShift ? 'custom' : 'off'
        })
    }

    // --- RENDERIZADO ---

    const renderDashboard = () => (
        <div className="animate-in fade-in duration-500">
            {/* Royal Floating Dashboard Header */}
            <div className="glass-panel sticky top-4 z-40 p-6 rounded-[2rem] shadow-royal-lg flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12 transition-all duration-500">
                <div className="flex items-center gap-6">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-950 flex items-center justify-center shadow-royal-lg transform -rotate-3 hover:rotate-0 transition-transform duration-500">
                        <span className="text-3xl">🗓️</span>
                    </div>
                    <div>
                        <div className="flex items-center gap-2 mb-1">
                            <span className="bg-brand text-white text-[9px] font-black px-2 py-0.5 rounded-lg uppercase tracking-widest font-jakarta">Estructura Operativa</span>
                            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em] font-jakarta">Live Coverage</span>
                        </div>
                        <h2 className="text-4xl font-black text-slate-900 tracking-tight font-outfit uppercase">Panel de <span className="text-brand">Cobertura</span></h2>
                        <p className="text-slate-500 text-sm font-medium font-jakarta mt-1">
                            {canEdit ? 'Gestión ejecutiva de fuerza y turnos.' : 'Monitor de programación estratégica.'}
                        </p>
                    </div>
                </div>

                <div className="flex items-center gap-4">
                    {/* Selector de Fecha Royal */}
                    <div className="flex items-center bg-slate-50/80 backdrop-blur-md rounded-2xl p-1.5 shadow-inner border border-slate-100">
                        <button onClick={(e) => { e.stopPropagation(); setCurrentDate(addDays(currentDate, -7)); }} className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-slate-900 hover:text-white transition-all text-slate-400 font-bold text-lg active:scale-95 shadow-sm">◀</button>
                        <span className="px-8 font-black text-[12px] uppercase tracking-[0.2em] text-slate-600 font-outfit min-w-[200px] text-center">
                            {formatDateNice(weekStart)} — {formatDateNice(addDays(weekStart, 6))}
                        </span>
                        <button onClick={(e) => { e.stopPropagation(); setCurrentDate(addDays(currentDate, 7)); }} className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-slate-900 hover:text-white transition-all text-slate-400 font-bold text-lg active:scale-95 shadow-sm">▶</button>
                    </div>

                    <div className="hidden lg:flex items-center gap-3 bg-white px-5 py-3 rounded-2xl border border-slate-100 shadow-royal">
                        <div className="w-2.5 h-2.5 rounded-full bg-brand animate-pulse"></div>
                        <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest font-jakarta">Faltantes Críticos</span>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20 px-4">
                {stores.map(store => {
                    const storeShifts = allSchedules.filter(s => String(s.store_id) === String(store.id));
                    const weekStatuses = weekDays.map(d => calculateDailyStatus(formatDateISO(d), storeShifts, allUsers));
                    const hasRisk = weekStatuses.some(s => s.status === 'bad');

                    return (
                        <div
                            key={store.id}
                            onClick={() => { setSelectedStoreId(String(store.id)); setViewMode('editor'); }}
                            className={`group glass-panel rounded-[2.5rem] p-10 transition-all duration-700 cursor-pointer hover:-translate-y-2 relative overflow-hidden
                            ${hasRisk ? 'border-brand/20 shadow-red-100/50 bg-red-50/30' : 'hover:border-slate-300 hover:shadow-royal-lg'}
                        `}
                        >
                            {/* Decorative Background Blob */}
                            <div className={`absolute -top-20 -right-20 w-52 h-52 blur-[80px] rounded-full opacity-20 transition-all duration-700 group-hover:opacity-40
                                ${hasRisk ? 'bg-brand' : 'bg-slate-400 group-hover:bg-brand'}
                            `}></div>

                            {hasRisk && (
                                <div className="absolute top-0 right-0 bg-brand text-white text-[10px] font-black px-6 py-2 rounded-bl-3xl tracking-[0.3em] uppercase shadow-lg animate-pulse z-10">
                                    CRÍTICO
                                </div>
                            )}

                            <div className="relative z-10">
                                <div className="flex items-center gap-6 mb-10">
                                    <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center text-3xl shadow-royal transition-all duration-700 group-hover:scale-110 group-hover:rotate-6
                                    ${hasRisk ? 'bg-brand text-white' : 'bg-white text-slate-900 group-hover:bg-slate-900 group-hover:text-white'}`}>
                                        🏪
                                    </div>
                                    <div>
                                        <h3 className="font-black text-slate-900 text-2xl tracking-tighter font-outfit uppercase group-hover:text-brand transition-colors">
                                            {store.name}
                                        </h3>
                                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.3em] mt-2 font-jakarta flex items-center gap-2">
                                            <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                                            {store.supervisor_name || 'Sin Asignar'}
                                        </p>
                                    </div>
                                </div>

                                <div className="space-y-4">
                                    <div className="flex justify-between items-center px-1">
                                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-jakarta">Salud Semanal</span>
                                        <span className={`text-[10px] font-black uppercase tracking-widest font-jakarta ${hasRisk ? 'text-brand' : 'text-emerald-500'}`}>
                                            {hasRisk ? 'Acción Requerida' : 'Operación Óptima'}
                                        </span>
                                    </div>
                                    <div className="flex justify-between items-end gap-2 px-1">
                                        {weekStatuses.map((st, idx) => (
                                            <div key={idx} className="flex flex-col items-center gap-3 w-full group/day">
                                                <div className={`w-full h-2 rounded-full transition-all duration-500 relative
                                                    ${st.status === 'ok' ? 'bg-emerald-400 shadow-sm shadow-emerald-100' : st.status === 'bad' ? 'bg-brand shadow-sm shadow-red-100' : 'bg-slate-100'}
                                                `}>
                                                    {st.status === 'bad' && <div className="absolute -top-1 -left-1 -right-1 -bottom-1 border border-brand/50 rounded-full animate-ping opacity-20"></div>}
                                                </div>
                                                <span className="text-[9px] font-black text-slate-300 uppercase tracking-tighter group-hover/day:text-slate-900 transition-colors font-outfit">
                                                    {['L', 'M', 'M', 'J', 'V', 'S', 'D'][idx]}
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* Luxury Action Indicator */}
                            <div className="absolute bottom-6 right-10 opacity-0 group-hover:opacity-100 group-hover:right-8 transition-all duration-500">
                                <span className="text-slate-900 font-black text-sm tracking-widest uppercase flex items-center gap-2 font-outfit">
                                    GESTIONAR <span className="text-brand">→</span>
                                </span>
                            </div>
                        </div>
                    )
                })}
            </div>
        </div>
    );

    const renderEditor = () => {
        const currentStore = stores.find(s => String(s.id) === String(selectedStoreId));

        return (
            <div className="animate-in slide-in-from-bottom-2 duration-700 space-y-6">
                {/* Royal Floating Header */}
                <div className="glass-panel sticky top-4 z-40 p-4 rounded-[1.5rem] shadow-royal-lg flex items-center justify-between mx-auto w-full transition-all duration-500">
                    <div className="flex items-center gap-6">
                        <button
                            onClick={() => setViewMode('dashboard')}
                            className="group w-11 h-11 flex items-center justify-center rounded-xl bg-slate-900 text-white hover:bg-brand transition-all shadow-lg active:scale-95"
                        >
                            <span className="text-xl group-hover:-translate-x-1 transition-transform">←</span>
                        </button>
                        <div>
                            <h2 className="text-2xl font-black text-slate-900 tracking-tight font-outfit uppercase leading-tight">
                                {currentStore?.name}
                            </h2>
                            <p className="text-[10px] text-brand/70 font-bold uppercase tracking-[0.2em] font-jakarta">
                                {canEdit ? 'Shift + Arrastrar para clonar' : 'Acceso de Lectura Segura'}
                            </p>
                        </div>
                    </div>

                    <div className="flex items-center gap-3">
                        {/* Selector de Fecha Estilizado */}
                        <div className="flex items-center bg-slate-50/50 rounded-xl p-1 border border-slate-100 shadow-inner">
                            <button onClick={() => setCurrentDate(addDays(currentDate, -7))} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-900 hover:text-white transition-all text-slate-400 font-bold">◀</button>
                            <span className="px-4 font-bold text-[11px] uppercase tracking-wide text-slate-600 font-jakarta min-w-[120px] text-center">
                                {formatDateNice(weekStart)} <span className="text-slate-200">/</span> {formatDateNice(addDays(weekStart, 6))}
                            </span>
                            <button onClick={() => setCurrentDate(addDays(currentDate, 7))} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-900 hover:text-white transition-all text-slate-400 font-bold">▶</button>
                        </div>

                        <div className="h-8 w-[1px] bg-slate-100 mx-2 hidden md:block" />

                        <select
                            value={selectedStoreId}
                            onChange={(e) => setSelectedStoreId(e.target.value)}
                            className="hidden md:block text-[10px] font-bold uppercase tracking-widest bg-slate-100 text-slate-900 border-0 rounded-xl px-4 py-3 cursor-pointer hover:bg-slate-200 focus:ring-4 focus:ring-slate-900/10 transition-all outline-none font-jakarta shadow-sm"
                        >
                            {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                        </select>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-4">
                    <div className="lg:col-span-5 glass-panel p-6 rounded-[2rem] shadow-royal">
                        <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-4 font-jakarta">Simbología Técnica</h3>
                        <div className="flex flex-wrap gap-2">
                            {[
                                { l: 'CUBIERTO', c: 'bg-emerald-500 shadow-emerald-200' },
                                { l: 'ALERTA CAPACIDAD', c: 'bg-brand shadow-red-200' },
                                { l: 'SIN PROGRAMAR', c: 'bg-slate-100 text-slate-400 border border-slate-200 shadow-none' }
                            ].map(s => (
                                <span key={s.l} className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg transition-all hover:scale-105 cursor-default ${s.c} ${!s.c.includes('text') && 'text-white'}`}>
                                    {s.l}
                                </span>
                            ))}
                        </div>
                    </div>
                    <div className="lg:col-span-7 glass-panel p-6 rounded-[2rem] shadow-royal overflow-hidden">
                        <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-4 font-jakarta">Plantillas de Turno</h3>
                        <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
                            {PRESETS.map(p => (
                                <span key={p.id} className={`flex-none px-3 py-2 rounded-xl text-[9px] font-black border uppercase tracking-tight transition-all hover:shadow-md cursor-default ${p.color}`}>
                                    {p.label}
                                </span>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="glass-panel rounded-[2.5rem] shadow-royal-lg overflow-hidden select-none border-0 mb-20 bg-white/40">
                    <div className="overflow-x-auto custom-scrollbar">
                        <table className="w-full border-separate border-spacing-0">
                            <thead>
                                <tr>
                                    <th className="p-10 text-left min-w-[320px] sticky left-0 glass-panel bg-white/95 z-30 border-r border-slate-100 relative">
                                        <div className="relative z-10">
                                            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.5em] font-jakarta">Estructura de Personal</span>
                                            <div className="flex items-center gap-2 mt-2">
                                                <span className="w-8 h-1 bg-brand rounded-full"></span>
                                                <span className="w-2 h-1 bg-slate-200 rounded-full"></span>
                                            </div>
                                        </div>
                                    </th>
                                    {weekDays.map(day => {
                                        const dateStr = formatDateISO(day);
                                        const status = calculateDailyStatus(dateStr, localSchedules, localUsers);
                                        const isToday = formatDateISO(new Date()) === dateStr;
                                        return (
                                            <th key={day.toISOString()} className={`p-8 min-w-[180px] border-r border-slate-100 last:border-0 transition-colors ${isToday ? 'bg-brand/5' : 'bg-transparent'}`}>
                                                <div className="flex flex-col items-center gap-1.5">
                                                    <span className={`text-[11px] font-bold uppercase tracking-[0.2em] font-jakarta ${isToday ? 'text-brand' : 'text-slate-400'}`}>
                                                        {getDayName(day)}
                                                    </span>
                                                    <div className="relative">
                                                        <span className="text-4xl font-black text-slate-900 tracking-tighter tabular-nums font-outfit relative z-10">{day.getDate()}</span>
                                                        {isToday && <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-brand rounded-full"></span>}
                                                    </div>
                                                    <div className={`mt-4 px-4 py-2 rounded-xl text-[10px] font-black tracking-widest w-full text-center uppercase shadow-sm border border-white/50 transition-all ${status.color.includes('emerald') ? 'bg-emerald-500 text-white' : status.color.includes('red') ? 'bg-brand text-white' : 'bg-slate-100 text-slate-400'}`}>
                                                        {status.label}
                                                    </div>
                                                </div>
                                            </th>
                                        )
                                    })}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50">
                                {localUsers.map(user => (
                                    <tr key={user.id} className="group hover:bg-gray-50/50 transition-all duration-300">
                                        <td className="p-8 sticky left-0 glass-panel bg-white/95 z-20 border-r border-slate-100 backdrop-blur-md transition-all group-hover:bg-slate-50/80">
                                            <div className="flex items-center gap-5">
                                                <div className="relative group/avatar">
                                                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-lg font-black text-white shadow-royal-lg transition-all duration-500 group-hover/avatar:rotate-12
                                                    ${['manager', 'admin', 'sup'].some(r => user.role.toLowerCase().includes(r))
                                                            ? 'bg-gradient-to-br from-slate-800 to-slate-950 font-outfit' : 'bg-gradient-to-br from-slate-400 to-slate-600 font-outfit'}`}>
                                                        {user.full_name.substring(0, 1).toUpperCase()}
                                                    </div>
                                                    {['manager', 'sup'].some(r => user.role.toLowerCase().includes(r)) && (
                                                        <div className="absolute -top-2 -right-2 bg-accent-gold text-white text-[10px] w-6 h-6 rounded-lg flex items-center justify-center shadow-lg border-2 border-white animate-float">★</div>
                                                    )}
                                                </div>
                                                <div className="flex flex-col gap-1">
                                                    <span className="font-black text-slate-900 text-base tracking-tight leading-tight font-outfit uppercase">
                                                        {user.full_name}
                                                    </span>
                                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-jakarta border-l-2 border-slate-200 pl-2 ml-0.5">{user.role}</span>
                                                </div>
                                            </div>
                                        </td>
                                        {weekDays.map(day => {
                                            const dateStr = formatDateISO(day);
                                            const isToday = formatDateISO(new Date()) === dateStr;
                                            const currentShift = localSchedules.find(s => String(s.user_id) === String(user.id) && s.date === dateStr);

                                            let cardContent = <div className="w-1.5 h-1.5 rounded-full bg-gray-200 opacity-20 group-hover:opacity-100 transition-opacity"></div>;
                                            let cardClass = "bg-transparent hover:bg-gray-100/50 border border-transparent";

                                            if (currentShift) {
                                                const preset = PRESETS.find(p => p.start === currentShift.start_time && p.end === currentShift.end_time);
                                                const color = preset ? preset.color : 'bg-white border-gray-900 text-gray-900 shadow-xl';

                                                cardClass = `${color} border-2 shadow-sm scale-95 group-hover:scale-100 transition-all duration-300`;
                                                cardContent = (
                                                    <div className="flex flex-col items-center justify-center w-full h-full p-2">
                                                        <span className="text-[11px] font-bold uppercase tracking-wide leading-none mb-1.5">{preset ? preset.label : 'PERSONAL'}</span>
                                                        <span className="text-[10px] font-bold tabular-nums opacity-70">
                                                            {currentShift.start_time?.slice(0, 5)} — {currentShift.end_time?.slice(0, 5)}
                                                        </span>
                                                    </div>
                                                );
                                            }
                                            return (
                                                <td
                                                    key={day.toISOString()}
                                                    className={`p-4 h-[110px] border-r border-slate-50 last:border-0 transition-all ${isToday ? 'bg-brand/[0.02]' : ''}`}
                                                    onMouseDown={(e) => handleCellMouseDown(e, user, day, currentShift)}
                                                    onMouseEnter={() => handleCellMouseEnter(user, day)}
                                                >
                                                    <div className={`w-full h-full rounded-[1.5rem] flex items-center justify-center transition-all duration-500 cursor-pointer overflow-hidden relative group/card ${cardClass} ${!canEdit && 'cursor-default hover:scale-100'}`}>
                                                        <div className="absolute inset-0 bg-white/10 opacity-0 group-hover/card:opacity-100 transition-opacity" />
                                                        {cardContent}
                                                    </div>
                                                </td>
                                            );
                                        })}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="p-6">
            <div className="max-w-[98%] mx-auto">

                {loading ? (
                    <div className="flex flex-col items-center justify-center h-96 gap-6">
                        <div className="w-12 h-12 border-4 border-gray-900 border-t-[#e31837] rounded-full animate-spin"></div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.4em]">Sincronizando Sistema de Turnos...</p>
                    </div>
                ) : (
                    viewMode === 'dashboard' ? renderDashboard() : renderEditor()
                )}

                {/* MODAL MODERNIZADO */}
                {editingShift && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/60 backdrop-blur-md p-4 animate-in fade-in duration-300">
                        <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-lg overflow-hidden transform transition-all border border-white">
                            <div className="bg-gray-50 px-8 py-8 border-b border-gray-100 flex justify-between items-center">
                                <div>
                                    <h3 className="text-2xl font-black text-gray-900 tracking-tight uppercase">{editingShift.userName}</h3>
                                    <p className="text-[11px] text-[#e31837] font-bold uppercase tracking-widest mt-1">Programación: {formatDateNice(editingShift.date)} • {getDayName(editingShift.date)}</p>
                                </div>
                                <button onClick={() => setEditingShift(null)} className="w-10 h-10 flex items-center justify-center rounded-full bg-white text-gray-400 hover:text-red-500 hover:rotate-90 transition-all text-2xl shadow-sm">&times;</button>
                            </div>

                            <div className="p-8 space-y-8">
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                    <button
                                        onClick={() => setEditingShift({ ...editingShift, start: '', end: '', presetId: 'off' })}
                                        className={`p-4 rounded-xl border-2 text-[11px] font-bold uppercase tracking-wide transition-all ${!editingShift.start ? 'bg-gray-900 text-white border-gray-900 shadow-lg' : 'bg-white text-gray-400 border-gray-100 hover:border-gray-200'}`}
                                    >
                                        DESCANSO
                                    </button>

                                    {PRESETS.map(p => (
                                        <button
                                            key={p.id}
                                            onClick={() => setEditingShift({ ...editingShift, start: p.start, end: p.end, presetId: p.id })}
                                            className={`p-3 rounded-xl border-2 text-[10px] font-bold uppercase tracking-tight transition-all flex flex-col items-center justify-center gap-1.5
                               ${editingShift.start === p.start && editingShift.end === p.end
                                                    ? `bg-gray-900 text-white border-gray-900 shadow-lg scale-105`
                                                    : `${p.color} border-transparent hover:border-gray-200`
                                                }`}
                                        >
                                            <span>{p.label}</span>
                                            <span className="opacity-70 text-[9px] font-bold tabular-nums">{p.start} - {p.end}</span>
                                        </button>
                                    ))}
                                </div>

                                <div className="pt-8 border-t border-gray-100">
                                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-[0.3em] mb-4 block">Ajuste de Precisión (Custom)</label>
                                    <div className="flex gap-6">
                                        <div className="flex-1">
                                            <span className="text-[10px] font-bold text-gray-300 mb-2 block uppercase tracking-widest">Entrada</span>
                                            <input
                                                type="time"
                                                value={editingShift.start}
                                                onChange={(e) => setEditingShift({ ...editingShift, start: e.target.value })}
                                                className="w-full p-4 bg-gray-50 border-0 rounded-2xl text-xl font-black tabular-nums text-gray-900 focus:ring-2 focus:ring-[#e31837]/10 outline-none"
                                            />
                                        </div>
                                        <div className="flex items-center text-gray-200 pt-6 text-xl">➜</div>
                                        <div className="flex-1">
                                            <span className="text-[10px] font-bold text-gray-300 mb-2 block uppercase tracking-widest">Salida</span>
                                            <input
                                                type="time"
                                                value={editingShift.end}
                                                onChange={(e) => setEditingShift({ ...editingShift, end: e.target.value })}
                                                className="w-full p-4 bg-gray-50 border-0 rounded-2xl text-xl font-black tabular-nums text-gray-900 focus:ring-2 focus:ring-[#e31837]/10 outline-none"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="p-6 bg-gray-50 border-t border-gray-100 px-8 flex justify-end gap-4">
                                <button onClick={() => setEditingShift(null)} className="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-gray-400 hover:text-gray-600 transition-colors">Abortar</button>
                                <button onClick={saveShift} className="px-8 py-3.5 text-[11px] font-bold uppercase tracking-widest text-white bg-gray-900 hover:bg-[#e31837] rounded-xl shadow-xl transition-all active:scale-95">
                                    Confirmar Turno
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    )
}

export default function HorariosPage() {
    return <ScheduleManager />
}