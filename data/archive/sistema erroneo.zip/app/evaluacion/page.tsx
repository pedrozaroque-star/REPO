'use client'

import { useState, useEffect } from 'react'
import { useSearchParams } from 'next/navigation'

type Language = 'es' | 'en'

interface Store {
  id: string
  name: string
  latitude: number | null
  longitude: number | null
}

const ROLES = ['Cajero(a)', 'Cocinero', 'Shift Leader', 'Asistente', 'Manager', 'Supervisor']
const LEAD_ROLES = new Set(['shift leader', 'asistente', 'manager', 'supervisor'])

const isLeadRole = (role: string): boolean => {
  return LEAD_ROLES.has(role.toLowerCase().trim())
}

export default function StaffEvaluationPage() {
  const searchParams = useSearchParams()
  const storeParam = searchParams.get('store')

  const [showSplash, setShowSplash] = useState(true)
  const [showThanks, setShowThanks] = useState(false)
  const [lang, setLang] = useState<Language>('es')
  const [stores, setStores] = useState<Store[]>([])
  const [loading, setLoading] = useState(false)
  const [selectedStore, setSelectedStore] = useState(storeParam || '')
  const [evaluatedRole, setEvaluatedRole] = useState('')
  const [detectingLocation, setDetectingLocation] = useState(false)
  const [gpsExecuted, setGpsExecuted] = useState(false)

  const [formData, setFormData] = useState({
    evaluator_name: '',
    evaluated_name: '',
    evaluated_role: '',

    // Q1: Trabajo en equipo
    q1_1: 0, q1_2: 0, q1_3: 0, q1_4: 0, q1_5: 0,
    // Q2: Liderazgo
    q2_1: 0, q2_2: 0, q2_3: 0, q2_4: 0, q2_5: 0,
    // Q3: Desempeño
    q3_1: 0, q3_2: 0, q3_3: 0, q3_4: 0, q3_5: 0,
    // Q4: Actitud
    q4_1: 0, q4_2: 0, q4_3: 0, q4_4: 0, q4_5: 0,
    // Q5: Desarrollo
    q5_1: 0, q5_2: 0, q5_3: 0, q5_4: 0, q5_5: 0,

    fortalezas: '',
    areas_mejora: '',
    recomendaria: 'si',
    desempeno_general: 0,
    comentarios: '',
    photos: [] as File[]
  })

  const [photoPreviews, setPhotoPreviews] = useState<string[]>([])

  useEffect(() => {
    fetchStores()
  }, [])

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 3500)
    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    setEvaluatedRole(formData.evaluated_role)
  }, [formData.evaluated_role])

  // GPS Login from Clientes
  useEffect(() => {
    if (!showSplash && stores.length > 0 && !gpsExecuted && !storeParam) {
      setGpsExecuted(true)
      setTimeout(() => {
        detectLocation()
      }, 500)
    }
  }, [showSplash, stores.length, gpsExecuted, storeParam])

  const fetchStores = async () => {
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      // Added latitude, longitude to select
      const res = await fetch(`${url}/rest/v1/stores?select=id,name,latitude,longitude&order=name.asc`, {
        headers: { 'apikey': key || '', 'Authorization': `Bearer ${key}` }
      })
      const data = await res.json()

      const storesWithNumbers = (Array.isArray(data) ? data : []).map(store => ({
        ...store,
        latitude: store.latitude ? parseFloat(store.latitude) : null,
        longitude: store.longitude ? parseFloat(store.longitude) : null
      }))

      setStores(storesWithNumbers)
    } catch (err) {
      console.error('❌ Error cargando tiendas:', err)
    }
  }

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371
    const dLat = (lat2 - lat1) * Math.PI / 180
    const dLon = (lon2 - lon1) * Math.PI / 180
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }

  const detectLocation = () => {
    if (!navigator.geolocation) {
      alert('Tu navegador no soporta geolocalización')
      return
    }

    setDetectingLocation(true)

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userLat = position.coords.latitude
        const userLon = position.coords.longitude

        let closestStore: Store | null = null
        let minDistance = Infinity

        stores.forEach(store => {
          if (store.latitude && store.longitude) {
            const distance = calculateDistance(userLat, userLon, store.latitude, store.longitude)
            if (distance < minDistance) {
              minDistance = distance
              closestStore = store
            }
          }
        })

        const MAX_DISTANCE_KM = 4.02 // 2.5 miles

        if (closestStore && minDistance <= MAX_DISTANCE_KM) {
          setSelectedStore((closestStore as Store).id)
        }

        setDetectingLocation(false)
      },
      (error) => {
        let errorMsg = ''
        switch (error.code) {
          case 1: errorMsg = 'Permiso denegado.'
            break
          case 2: errorMsg = 'Ubicación no disponible.'
            break
          case 3: errorMsg = 'Tiempo agotado.'
            break
        }
        if (errorMsg) alert(errorMsg)
        setDetectingLocation(false)
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    )
  }

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return
    const files = Array.from(e.target.files).slice(0, 10)
    setFormData({ ...formData, photos: files })

    const previews: string[] = []
    let loaded = 0

    files.forEach(file => {
      const reader = new FileReader()
      reader.onload = (e) => {
        if (e.target?.result) {
          previews.push(e.target.result as string)
          loaded++
          if (loaded === files.length) {
            setPhotoPreviews([...previews])
          }
        }
      }
      reader.readAsDataURL(file)
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedStore) {
      alert(texts[lang].errStore)
      return
    }
    if (!formData.evaluated_name.trim()) {
      alert(texts[lang].errName)
      return
    }
    if (!formData.evaluated_role) {
      alert(texts[lang].errRole)
      return
    }
    if (!formData.desempeno_general || formData.desempeno_general < 1) {
      alert(texts[lang].errGeneral)
      return
    }

    // Validation Logic
    const isLead = isLeadRole(formData.evaluated_role)
    let answered = 0
    let required = 0

      // Q1: 4 for all + 1 LEAD
      ;[formData.q1_1, formData.q1_2, formData.q1_3, formData.q1_4].forEach(v => { required++; if (v > 0) answered++ })
    if (isLead) { required++; if (formData.q1_5 > 0) answered++ }

    // Q2: 5 only LEAD
    if (isLead) {
      ;[formData.q2_1, formData.q2_2, formData.q2_3, formData.q2_4, formData.q2_5].forEach(v => { required++; if (v > 0) answered++ })
    }

    // Q3: 4 for all + 1 LEAD
    ;[formData.q3_1, formData.q3_2, formData.q3_3, formData.q3_4].forEach(v => { required++; if (v > 0) answered++ })
    if (isLead) { required++; if (formData.q3_5 > 0) answered++ }

    // Q4: 1,4 all; 2,3,5 LEAD
    if (formData.q4_1 > 0) answered++; required++
    if (isLead) { required++; if (formData.q4_2 > 0) answered++ }
    if (isLead) { required++; if (formData.q4_3 > 0) answered++ }
    if (formData.q4_4 > 0) answered++; required++
    if (isLead) { required++; if (formData.q4_5 > 0) answered++ }

    // Q5: 5 for all
    ;[formData.q5_1, formData.q5_2, formData.q5_3, formData.q5_4, formData.q5_5].forEach(v => { required++; if (v > 0) answered++ })

    if (answered < required * 0.8) {
      alert(texts[lang].errMinQuestions)
      return
    }

    setLoading(true)

    try {
      let photoUrls: string[] = []
      if (formData.photos && formData.photos.length > 0) {
        const { uploadPhotos } = await import('@/lib/uploadPhotos')
        const prefix = `${selectedStore}_${formData.evaluated_name.replace(/\\s+/g, '_')}`
        photoUrls = await uploadPhotos(formData.photos, 'staff-photos', prefix)
      }

      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      const payload = {
        store_id: selectedStore,
        evaluation_date: new Date().toISOString(),
        evaluator_name: formData.evaluator_name || null,
        evaluated_name: formData.evaluated_name,
        evaluated_role: formData.evaluated_role,

        q1_1: formData.q1_1 || null, q1_2: formData.q1_2 || null, q1_3: formData.q1_3 || null,
        q1_4: formData.q1_4 || null, q1_5: formData.q1_5 || null,
        q2_1: formData.q2_1 || null, q2_2: formData.q2_2 || null, q2_3: formData.q2_3 || null,
        q2_4: formData.q2_4 || null, q2_5: formData.q2_5 || null,
        q3_1: formData.q3_1 || null, q3_2: formData.q3_2 || null, q3_3: formData.q3_3 || null,
        q3_4: formData.q3_4 || null, q3_5: formData.q3_5 || null,
        q4_1: formData.q4_1 || null, q4_2: formData.q4_2 || null, q4_3: formData.q4_3 || null,
        q4_4: formData.q4_4 || null, q4_5: formData.q4_5 || null,
        q5_1: formData.q5_1 || null, q5_2: formData.q5_2 || null, q5_3: formData.q5_3 || null,
        q5_4: formData.q5_4 || null, q5_5: formData.q5_5 || null,

        fortalezas: formData.fortalezas || null,
        areas_mejora: formData.areas_mejora || null,
        recomendaria: formData.recomendaria,
        desempeno_general: formData.desempeno_general,
        comentarios: formData.comentarios || null,
        language: lang,
        photo_urls: photoUrls.length > 0 ? photoUrls : null
      }

      const res = await fetch(`${url}/rest/v1/staff_evaluations`, {
        method: 'POST',
        headers: {
          'apikey': key || '',
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify(payload)
      })

      if (res.ok) {
        setShowThanks(true)
      } else {
        alert(texts[lang].submitError)
      }
    } catch (err) {
      alert(texts[lang].submitError)
    }

    setLoading(false)
  }

  const texts = {
    es: {
      title: 'Te escuchamos',
      subtitle: 'Ayudamos a mejorar juntos.',
      store: 'Sucursal',
      storePlaceholder: 'Selecciona…',
      detectBtn: 'Detectar GPS',
      detecting: 'Detectando...',
      evaluator: 'Tu nombre (opcional)',
      evaluatorPlaceholder: 'Ej. Juan P.',
      evaluatedName: 'Nombre del evaluado *',
      evaluatedNamePlaceholder: 'Ej. María L.',
      evaluatedRole: 'Rol del evaluado *',
      evaluatedRolePlaceholder: 'Selecciona…',

      cat1: '1. Trabajo en equipo',
      q1_1: '¿Se comunica de manera clara?',
      q1_2: '¿Escucha a los demás?',
      q1_3: '¿Apoya cuando está ocupado?',
      q1_4: '¿Fomenta ambiente positivo?',
      q1_5: '¿Resuelve conflictos? (Líder)',

      cat2: '2. Liderazgo (Solo Leads)',
      q2_1: '¿Motiva al equipo?',
      q2_2: '¿Da feedback constructivo?',
      q2_3: '¿Es justo asignando tareas?',
      q2_4: '¿Apoya en dificultades?',
      q2_5: '¿Es ejemplo a seguir?',

      cat3: '3. Desempeño y Eficiencia',
      q3_1: '¿Cumple sin supervisión?',
      q3_2: '¿Mantiene limpieza?',
      q3_3: '¿Sigue procedimientos?',
      q3_4: '¿Rápido y preciso?',
      q3_5: '¿Tiene iniciativa? (Líder)',

      cat4: '4. Actitud',
      q4_1: '¿Actitud positiva?',
      q4_2: '¿Respetuoso sin favoritismos? (Líder)',
      q4_3: '¿Representa bien la marca? (Líder)',
      q4_4: '¿Recibe críticas bien?',
      q4_5: '¿Contribuye al ambiente? (Líder)',

      cat5: '5. Desarrollo',
      q5_1: '¿Interés en aprender?',
      q5_2: '¿Busca crecer?',
      q5_3: '¿Ayuda a entrenar?',
      q5_4: '¿Aplica lo aprendido?',
      q5_5: '¿Abierto a cambios?',

      fortalezas: 'Fortalezas',
      fortalezasPlaceholder: '¿Qué hace bien?',
      areasMejora: 'Áreas de mejora',
      areasMejoraPlaceholder: '¿Qué puede mejorar?',
      recomendaria: '¿Lo recomiendas?',
      yes: 'Sí',
      no: 'No',
      general: 'Desempeño general (1-10)',
      generalPlaceholder: '1-10',
      comentarios: 'Comentarios',
      comentariosPlaceholder: 'Opcional',
      photos: 'Evidencias',
      photosHint: 'Max 10 fotos',

      hint: '1 = Deficiente · 5 = Excelente',
      send: 'Enviar Evaluación',
      sending: 'Enviando...',
      thanks: '¡GRACIAS!',
      thanksMsg: 'Evaluación registrada correctamente.',
      errStore: 'Selecciona sucursal',
      errName: 'Ingresa nombre del evaluado',
      errRole: 'Selecciona rol del evaluado',
      errGeneral: 'Califica desempeño general',
      errMinQuestions: 'Responde al menos 80% de las preguntas',
      submitError: 'Error al enviar.',
      leadOnly: 'SOLO LÍDER'
    },
    en: {
      title: 'We Listen',
      subtitle: 'Improving together.',
      store: 'Location',
      storePlaceholder: 'Select…',
      detectBtn: 'Detect GPS',
      detecting: 'Detecting...',
      evaluator: 'Your name (optional)',
      evaluatorPlaceholder: 'E.g. John P.',
      evaluatedName: 'Evaluated Name *',
      evaluatedNamePlaceholder: 'E.g. Mary L.',
      evaluatedRole: 'Evaluated Role *',
      evaluatedRolePlaceholder: 'Select…',

      cat1: '1. Teamwork',
      q1_1: 'Communicates clearly?',
      q1_2: 'Listens to others?',
      q1_3: 'Supports when busy?',
      q1_4: 'Positive environment?',
      q1_5: 'Resolves conflicts? (Lead)',

      cat2: '2. Leadership (Leads Only)',
      q2_1: 'Motivates team?',
      q2_2: 'Constructive feedback?',
      q2_3: 'Fair task assignment?',
      q2_4: 'Supports in difficulties?',
      q2_5: 'Leads by example?',

      cat3: '3. Performance',
      q3_1: 'Works without supervision?',
      q3_2: 'Maintains cleanliness?',
      q3_3: 'Follows procedures?',
      q3_4: 'Fast and precise?',
      q3_5: 'Shows initiative? (Lead)',

      cat4: '4. Attitude',
      q4_1: 'Positive attitude?',
      q4_2: 'Respectful/No favorites? (Lead)',
      q4_3: 'Represents brand well? (Lead)',
      q4_4: 'Receives criticism well?',
      q4_5: 'Contributes to environment? (Lead)',

      cat5: '5. Development',
      q5_1: 'Interested in learning?',
      q5_2: 'Seeks growth?',
      q5_3: 'Helps train?',
      q5_4: 'Applies learning?',
      q5_5: 'Open to change?',

      fortalezas: 'Strengths',
      fortalezasPlaceholder: 'What do they do well?',
      areasMejora: 'Areas for improvement',
      areasMejoraPlaceholder: 'What to improve?',
      recomendaria: 'Recommend?',
      yes: 'Yes',
      no: 'No',
      general: 'Overall (1-10)',
      generalPlaceholder: '1-10',
      comentarios: 'Comments',
      comentariosPlaceholder: 'Optional',
      photos: 'Evidence',
      photosHint: 'Max 10 photos',

      hint: '1 = Poor · 5 = Excellent',
      send: 'Submit Evaluation',
      sending: 'Sending...',
      thanks: 'THANK YOU!',
      thanksMsg: 'Evaluation recorded.',
      errStore: 'Select location',
      errName: 'Enter evaluated name',
      errRole: 'Select evaluated role',
      errGeneral: 'Rate overall performance',
      errMinQuestions: 'Answer at least 80% of questions',
      submitError: 'Error submitting.',
      leadOnly: 'LEAD ONLY'
    }
  }

  const t = texts[lang]
  const isLead = isLeadRole(evaluatedRole)

  const StarIcon = ({ filled, onClick }: { filled: boolean, onClick: () => void }) => (
    <button
      type="button"
      onClick={onClick}
      className={`transition-all duration-300 transform hover:scale-110 focus:outline-none ${filled ? 'text-[#fdc82f]' : 'text-white/20 hover:text-white/40'}`}
    >
      <svg viewBox="0 0 24 24" className="w-8 h-8 md:w-9 md:h-9 fill-current">
        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
      </svg>
    </button>
  )

  const QuestionRow = ({ code, label, value, onChange, showForLead = false }: any) => {
    if (showForLead && !isLead) return null

    return (
      <div className={`p-4 rounded-xl border transition-all ${value > 0 ? 'bg-[#fdc82f]/5 border-[#fdc82f]/20' : 'bg-white/5 border-white/5'}`}>
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium text-white/90">
            {label} {showForLead && <span className="text-[#fdc82f] text-[10px] uppercase ml-1 tracking-wider border border-[#fdc82f] px-1 rounded">Lead</span>}
          </label>
          <div className="flex justify-between items-center px-1">
            <span className="text-[10px] text-white/20 font-mono">1</span>
            <div className="flex gap-2 text-white">
              {[1, 2, 3, 4, 5].map(val => (
                <StarIcon key={val} filled={value >= val} onClick={() => onChange(val)} />
              ))}
            </div>
            <span className="text-[10px] text-white/20 font-mono">5</span>
          </div>
        </div>
      </div>
    )
  }

  // Premium Splash
  if (showSplash) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#50050a] overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>
        <style dangerouslySetInnerHTML={{
          __html: `
          @keyframes dropIn {
            0% { transform: translateY(-800px) rotateY(0deg); opacity: 0; }
            60% { transform: translateY(20px) rotateY(1440deg); opacity: 1; }
            80% { transform: translateY(-10px) rotateY(1440deg); }
            100% { transform: translateY(0) rotateY(1440deg); }
          }
          @keyframes ripple {
            0% { transform: scale(0); opacity: 0.8; }
            100% { transform: scale(4); opacity: 0; }
          }
        `}} />
        <div className="relative z-10 flex flex-col items-center">
          <div
            className="w-48 h-48 rounded-full bg-gradient-to-br from-[#fdc82f] to-[#e69b00] p-1.5 shadow-[0_0_60px_rgba(253,200,47,0.4)]"
            style={{ animation: 'dropIn 1.5s cubic-bezier(0.34, 1.56, 0.64, 1) forwards' }}
          >
            <div className="w-full h-full rounded-full bg-white flex items-center justify-center overflow-hidden border-4 border-[#fffbeb]">
              <img src="/logo.png" alt="TAG" className="w-[85%] h-[85%] object-contain" />
            </div>
          </div>
          <div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full border border-white/50"
            style={{ animation: 'ripple 2s infinite linear', animationDelay: '1.2s' }}
          ></div>
        </div>
      </div>
    )
  }

  // Premium Thanks
  if (showThanks) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-[#50050a] to-[#1a0103] text-white p-6">
        <div className="absolute inset-0 opacity-10 bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>
        <div className="relative z-10 flex flex-col items-center text-center animate-in fade-in zoom-in duration-700">
          <div className="w-32 h-32 rounded-full bg-[#fdc82f] flex items-center justify-center shadow-[0_0_50px_rgba(253,200,47,0.5)] mb-8">
            <span className="text-6xl text-[#50050a]">✓</span>
          </div>
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#fdc82f] to-[#fffbeb] mb-4 tracking-tight">
            {t.thanks}
          </h1>
          <p className="text-lg text-white/80 font-light max-w-md leading-relaxed">
            {t.thanksMsg}
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#50050a] via-[#3a0305] to-[#1a0103] text-white font-sans selection:bg-[#fdc82f] selection:text-[#50050a]">
      <nav className="sticky top-0 z-40 backdrop-blur-md bg-[#50050a]/80 border-b border-white/5">
        <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-white p-1 shadow-lg">
              <img src="/logo.png" alt="Logo" className="w-full h-full object-contain" />
            </div>
            <span className="font-bold tracking-wide text-xs md:text-sm">TAG · STAFF</span>
          </div>
          <button
            onClick={() => setLang(lang === 'es' ? 'en' : 'es')}
            className="px-3 py-1 rounded-full bg-white/10 border border-white/10 text-xs font-bold hover:bg-white/20 transition-all"
          >
            {lang === 'es' ? 'EN' : 'ES'}
          </button>
        </div>
      </nav>

      <main className="max-w-md mx-auto px-4 py-8 pb-32 space-y-8">
        <div className="text-center space-y-2 animate-in slide-in-from-bottom-4 duration-700">
          <h1 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white to-white/70">
            {t.title}
          </h1>
          <p className="text-white/60 text-sm font-light">
            {t.subtitle}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 animate-in slide-in-from-bottom-8 duration-1000 delay-150">

          {/* Store + GPS */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl space-y-4">
            <label className="block text-xs font-bold uppercase tracking-widest text-[#fdc82f] mb-1">
              {t.store}
            </label>
            <div className="relative">
              <select
                value={selectedStore}
                onChange={(e) => setSelectedStore(e.target.value)}
                className="w-full appearance-none bg-black/20 border border-white/10 rounded-xl px-4 py-4 text-white placeholder-white/30 focus:outline-none focus:border-[#fdc82f] focus:ring-1 focus:ring-[#fdc82f] transition-all"
                required
              >
                <option value="" className="bg-[#3a0305] text-white/50">{t.storePlaceholder}</option>
                {stores.map(s => (
                  <option key={s.id} value={s.id} className="bg-[#3a0305] text-white">{s.name}</option>
                ))}
              </select>
              <div className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-white/50">▼</div>
            </div>
            <button
              type="button"
              onClick={detectLocation}
              disabled={detectingLocation}
              className="w-full py-3 rounded-xl border border-[#fdc82f]/30 bg-[#fdc82f]/10 text-[#fdc82f] font-bold text-sm hover:bg-[#fdc82f]/20 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              {detectingLocation ? <span className="animate-spin">◌</span> : <span>📍</span>}
              {detectingLocation ? t.detecting : t.detectBtn}
            </button>
          </div>

          {/* Evaluator/Evaluated Info */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-xl space-y-5">
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-[#fdc82f] mb-2">{t.evaluator}</label>
              <input type="text" value={formData.evaluator_name} onChange={(e) => setFormData({ ...formData, evaluator_name: e.target.value })}
                className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-[#fdc82f] outline-none" placeholder={t.evaluatorPlaceholder} />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-[#fdc82f] mb-2">{t.evaluatedName}</label>
              <input type="text" value={formData.evaluated_name} onChange={(e) => setFormData({ ...formData, evaluated_name: e.target.value })}
                className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-[#fdc82f] outline-none" placeholder={t.evaluatedNamePlaceholder} />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-[#fdc82f] mb-2">{t.evaluatedRole}</label>
              <div className="relative">
                <select value={formData.evaluated_role} onChange={(e) => setFormData({ ...formData, evaluated_role: e.target.value })}
                  className="w-full appearance-none bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-[#fdc82f] outline-none" >
                  <option value="" className="bg-[#3a0305] text-white/50">{t.evaluatedRolePlaceholder}</option>
                  {ROLES.map(role => <option key={role} value={role} className="bg-[#3a0305] text-white">{role}</option>)}
                </select>
                <div className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-white/50">▼</div>
              </div>
            </div>
          </div>

          {[
            {
              cat: t.cat1, q: [
                { k: 'q1_1', l: t.q1_1 }, { k: 'q1_2', l: t.q1_2 }, { k: 'q1_3', l: t.q1_3 }, { k: 'q1_4', l: t.q1_4 }, { k: 'q1_5', l: t.q1_5, lead: true }
              ]
            },
            {
              cat: t.cat2, lead: true, class: 'border-[#fdc82f]/30 bg-[#fdc82f]/5', q: [
                { k: 'q2_1', l: t.q2_1, lead: true }, { k: 'q2_2', l: t.q2_2, lead: true }, { k: 'q2_3', l: t.q2_3, lead: true }, { k: 'q2_4', l: t.q2_4, lead: true }, { k: 'q2_5', l: t.q2_5, lead: true }
              ]
            },
            {
              cat: t.cat3, q: [
                { k: 'q3_1', l: t.q3_1 }, { k: 'q3_2', l: t.q3_2 }, { k: 'q3_3', l: t.q3_3 }, { k: 'q3_4', l: t.q3_4 }, { k: 'q3_5', l: t.q3_5, lead: true }
              ]
            },
            {
              cat: t.cat4, q: [
                { k: 'q4_1', l: t.q4_1 }, { k: 'q4_2', l: t.q4_2, lead: true }, { k: 'q4_3', l: t.q4_3, lead: true }, { k: 'q4_4', l: t.q4_4 }, { k: 'q4_5', l: t.q4_5, lead: true }
              ]
            },
            {
              cat: t.cat5, q: [
                { k: 'q5_1', l: t.q5_1 }, { k: 'q5_2', l: t.q5_2 }, { k: 'q5_3', l: t.q5_3 }, { k: 'q5_4', l: t.q5_4 }, { k: 'q5_5', l: t.q5_5 }
              ]
            }
          ].map((section, idx) => {
            if (section.lead && !isLead) return null
            return (
              <div key={idx} className={`rounded-2xl p-6 shadow-xl space-y-4 backdrop-blur-xl border ${section.class || 'bg-white/5 border-white/10'}`}>
                <h3 className="text-lg font-black text-white">{section.cat}</h3>
                <div className="space-y-3">
                  {section.q.map((q) => (
                    <QuestionRow key={q.k} code={q.k} label={q.l} value={formData[q.k as keyof typeof formData]}
                      onChange={(v: number) => setFormData({ ...formData, [q.k]: v })}
                      showForLead={q.lead} />
                  ))}
                </div>
              </div>
            )
          })}

          {/* Qualitative */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-xl space-y-6">
            {[
              { k: 'fortalezas', l: t.fortalezas, p: t.fortalezasPlaceholder },
              { k: 'areas_mejora', l: t.areasMejora, p: t.areasMejoraPlaceholder },
              { k: 'comentarios', l: t.comentarios, p: t.comentariosPlaceholder }
            ].map((field) => (
              <div key={field.k}>
                <label className="block text-xs font-bold uppercase tracking-widest text-[#fdc82f] mb-2">{field.l}</label>
                <textarea rows={2} value={formData[field.k as keyof typeof formData] as string}
                  onChange={(e) => setFormData({ ...formData, [field.k]: e.target.value })}
                  placeholder={field.p}
                  className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-[#fdc82f] outline-none resize-none" />
              </div>
            ))}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-[#fdc82f] mb-2">{t.recomendaria}</label>
                <div className="relative">
                  <select value={formData.recomendaria} onChange={(e) => setFormData({ ...formData, recomendaria: e.target.value })}
                    className="w-full appearance-none bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-[#fdc82f] outline-none">
                    <option value="si" className="bg-[#3a0305]">{t.yes}</option>
                    <option value="no" className="bg-[#3a0305]">{t.no}</option>
                  </select>
                  <div className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-white/50">▼</div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-[#fdc82f] mb-2">{t.general}</label>
                <input type="number" min="1" max="10" value={formData.desempeno_general || ''}
                  onChange={(e) => setFormData({ ...formData, desempeno_general: parseInt(e.target.value) })}
                  placeholder={t.generalPlaceholder}
                  className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-[#fdc82f] outline-none" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-[#fdc82f] mb-4 flex justify-between">
                <span>{t.photos}</span>
                <span className="text-white/40 text-[10px]">Max 10</span>
              </label>
              <div className="grid grid-cols-4 gap-2 mb-3">
                {photoPreviews.map((src, i) => (
                  <div key={i} className="aspect-square rounded-lg overflow-hidden border border-white/10">
                    <img src={src} className="w-full h-full object-cover" />
                  </div>
                ))}
                <label className="aspect-square rounded-lg border-2 border-dashed border-white/20 flex flex-col items-center justify-center cursor-pointer hover:bg-white/5 hover:border-[#fdc82f]/50 transition-all group">
                  <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">📷</span>
                  <span className="text-[9px] text-white/40">Agregar</span>
                  <input type="file" multiple accept="image/*" className="hidden" onChange={handlePhotoChange} />
                </label>
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-5 rounded-2xl bg-gradient-to-r from-[#e31837] to-[#b91c1c] text-white font-black text-lg tracking-widest uppercase shadow-[0_10px_30px_rgba(227,24,55,0.3)] hover:shadow-[0_10px_40px_rgba(227,24,55,0.5)] active:scale-95 transition-all disabled:opacity-50 disabled:grayscale"
          >
            {loading ? t.sending : t.send}
          </button>

          <div className="pt-8 text-center opacity-30">
            <img src="/logo.png" className="h-8 mx-auto grayscale mb-4" />
          </div>

        </form>
      </main>
    </div>
  )
}