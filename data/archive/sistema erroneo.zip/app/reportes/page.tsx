'use client'

import * as XLSX from 'xlsx'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

function ReportesContent() {
  const [stores, setStores] = useState<any[]>([])
  const [selectedStore, setSelectedStore] = useState('all')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [report, setReport] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchStores()

    const today = new Date()
    const monthAgo = new Date()
    monthAgo.setDate(today.getDate() - 30)

    setDateTo(today.toISOString().split('T')[0])
    setDateFrom(monthAgo.toISOString().split('T')[0])
  }, [])

  const fetchStores = async () => {
    try {
      const { data } = await supabase.from('stores').select('*').order('name', { ascending: true })
      setStores(Array.isArray(data) ? data : [])
    } catch (err) {
      console.error('Error:', err)
    }
  }

  const generateReport = async () => {
    setLoading(true)
    try {
      let queryFeedback = supabase.from('customer_feedback').select('*').gte('submission_date', dateFrom).lte('submission_date', `${dateTo}T23:59:59`)
      let queryInsp = supabase.from('supervisor_inspections').select('*').gte('inspection_date', dateFrom).lte('inspection_date', dateTo)
      let queryCheck = supabase.from('assistant_checklists').select('*').gte('submission_date', dateFrom).lte('submission_date', `${dateTo}T23:59:59`)

      if (selectedStore !== 'all') {
        queryFeedback = queryFeedback.eq('store_id', selectedStore)
        queryInsp = queryInsp.eq('store_id', selectedStore)
        queryCheck = queryCheck.eq('store_id', selectedStore)
      }

      const [feedbackRes, inspRes, checkRes] = await Promise.all([queryFeedback, queryInsp, queryCheck])

      const feedbacksArray = feedbackRes.data || []
      const inspectionsArray = inspRes.data || []
      const checklistsArray = checkRes.data || []

      const npsScores = feedbacksArray.filter(f => f.nps_score != null).map(f => f.nps_score)
      const avgNPS = npsScores.length > 0
        ? Math.round(npsScores.reduce((a, b) => a + b, 0) / npsScores.length)
        : 0

      const promoters = feedbacksArray.filter(f => f.nps_category === 'promoter').length
      const detractors = feedbacksArray.filter(f => f.nps_category === 'detractor').length
      const npsScore = feedbacksArray.length > 0
        ? Math.round(((promoters - detractors) / feedbacksArray.length) * 100)
        : 0

      const avgInspection = inspectionsArray.length > 0
        ? Math.round(inspectionsArray.reduce((sum, i) => sum + (i.overall_score || 0), 0) / inspectionsArray.length)
        : 0

      const getAvg = (arr: any[], key: string) => arr.length > 0 ? (arr.reduce((sum, f) => sum + (f[key] || 0), 0) / arr.length).toFixed(1) : 0

      setReport({
        feedbacks: {
          total: feedbacksArray.length,
          avgNPS,
          npsScore,
          promoters,
          detractors,
          avgService: getAvg(feedbacksArray, 'service_rating'),
          avgQuality: getAvg(feedbacksArray, 'food_quality_rating'),
          avgCleanliness: getAvg(feedbacksArray, 'cleanliness_rating'),
          avgSpeed: getAvg(feedbacksArray, 'speed_rating')
        },
        inspections: {
          total: inspectionsArray.length,
          avgScore: avgInspection
        },
        checklists: {
          total: checklistsArray.length,
          byType: {
            daily: checklistsArray.filter(c => c.checklist_type === 'daily').length,
            temperaturas: checklistsArray.filter(c => c.checklist_type === 'temperaturas').length,
            sobrante: checklistsArray.filter(c => c.checklist_type === 'producto_sobrante').length,
            recorrido: checklistsArray.filter(c => c.checklist_type === 'recorrido').length,
            cierre: checklistsArray.filter(c => c.checklist_type === 'cierre').length,
            apertura: checklistsArray.filter(c => c.checklist_type === 'apertura').length
          }
        }
      })
    } catch (err) {
      console.error('Error:', err)
    } finally {
      setLoading(false)
    }
  }

  const exportToExcel = () => {
    if (!report) return
    const wb = XLSX.utils.book_new()
    const summaryData = [
      ['REPORTE OPERATIVO TACOS GAVILAN'],
      [`Período: ${dateFrom} a ${dateTo}`],
      [`Unidad: ${selectedStore === 'all' ? 'Todas' : stores.find(s => s.id === selectedStore)?.name}`],
      [''],
      ['MÉTRICAS DE SATISFACCIÓN (NPS)'],
      ['Total Feedbacks', report.feedbacks.total],
      ['Puntaje NPS', report.feedbacks.npsScore],
      ['Promedio Calificación', report.feedbacks.avgNPS],
      [''],
      ['AUDITORÍAS DE CONTROL'],
      ['Total Inspecciones', report.inspections.total],
      ['Puntaje Promedio', report.inspections.avgScore + '%'],
      [''],
      ['CUMPLIMIENTO OPERATIVO (CHECKLISTS)'],
      ['Total Ejecuciones', report.checklists.total],
      ['Apertura', report.checklists.byType.apertura],
      ['Daily', report.checklists.byType.daily],
      ['Temperaturas', report.checklists.byType.temperaturas],
      ['Recorrido', report.checklists.byType.recorrido],
      ['Sobrante', report.checklists.byType.sobrante],
      ['Cierre', report.checklists.byType.cierre]
    ]
    const ws = XLSX.utils.aoa_to_sheet(summaryData)
    XLSX.utils.book_append_sheet(wb, ws, 'Resumen Operativo')
    XLSX.writeFile(wb, `Reporte_TEG_${dateFrom}.xlsx`)
  }

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Analítica Avanzada</h1>
            <p className="text-gray-600 mt-2">Métricas e indicadores clave de rendimiento del sistema.</p>
          </div>
          <div className="flex space-x-3">
            <button
              onClick={() => window.print()}
              className="px-6 py-3 bg-white border-2 border-gray-300 hover:border-[#e31837] text-gray-700 hover:text-[#e31837] font-semibold rounded-lg transition-all flex items-center gap-2"
            >
              📥 Exportar
            </button>
          </div>
        </div>

        {/* Filters - Solid Corporate */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-gray-500 ml-1">Unidad de Negocio</label>
              <select
                value={selectedStore}
                onChange={(e) => setSelectedStore(e.target.value)}
                className="w-full px-5 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none cursor-pointer"
              >
                <option value="all">Sede Central (Global)</option>
                {stores.map(store => (
                  <option key={store.id} value={store.id}>{store.name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-gray-500 ml-1">Fecha de Inicio</label>
              <input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="w-full px-5 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-gray-500 ml-1">Fecha de Cierre</label>
              <input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="w-full px-5 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-[#e31837]/10 transition-all outline-none"
              />
            </div>
            <div className="flex items-end">
              <button
                onClick={generateReport}
                disabled={loading}
                className="w-full py-3.5 bg-gray-900 text-white rounded-xl font-bold text-xs tracking-wide transition-all hover:bg-[#e31837] disabled:bg-gray-100 disabled:text-gray-400 shadow-md"
              >
                {loading ? 'Procesando...' : 'Generar Reporte'}
              </button>
            </div>
          </div>
        </div>

        {report ? (
          <div className="space-y-10 animate-in fade-in slide-in-from-bottom-2 duration-700 pb-10">

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-lg font-bold text-gray-900 tracking-tight">Auditoría por Categoría <span className="text-gray-400 font-medium text-sm ml-2">(Escala 0.0-5.0)</span></h3>
                </div>
                <div className="h-[320px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={[
                      { label: 'SERVICIO', val: parseFloat(report.feedbacks.avgService), color: '#e31837' },
                      { label: 'CALIDAD', val: parseFloat(report.feedbacks.avgQuality), color: '#fdc82f' },
                      { label: 'LIMPIEZA', val: parseFloat(report.feedbacks.avgCleanliness), color: '#1a1a1a' },
                      { label: 'TIEMPO', val: parseFloat(report.feedbacks.avgSpeed), color: '#666666' }
                    ]} barGap={0}>
                      <CartesianGrid strokeDasharray="2 2" vertical={false} stroke="#f3f4f6" />
                      <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 700, fill: '#6b7280' }} />
                      <YAxis hide domain={[0, 5]} />
                      <Tooltip cursor={{ fill: '#f9fafb' }} contentStyle={{ borderRadius: '0.75rem', border: '1px solid #f3f4f6', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                      <Bar dataKey="val" radius={[4, 4, 0, 0]} barSize={50}>
                        {[0, 1, 2, 3].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={['#e31837', '#fdc82f', '#1a1a1a', '#666666'][index]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm flex flex-col justify-center text-center relative overflow-hidden group">
                <div className="relative z-10">
                  <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center text-4xl font-bold text-gray-900 mx-auto mb-6 border-4 border-white shadow-xl">
                    {report.feedbacks.npsScore}
                  </div>
                  <p className="text-xs font-bold text-[#e31837] mb-1">Puntaje Neto</p>
                  <h4 className="text-2xl font-bold text-gray-900 tracking-tight mb-4">Índice NPS</h4>
                  <p className="text-xs font-medium text-gray-500 max-w-[200px] mx-auto">Basado en {report.feedbacks.total} encuestas de satisfacción procesadas.</p>
                </div>
              </div>
            </div>

            {/* Stats Grid - Solid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'Auditorías', val: report.inspections.total, sub: 'Visitas Técnicas', accent: '#e31837' },
                { label: 'Calidad Operativa', val: `${report.inspections.avgScore}%`, sub: 'Score Inspección', accent: '#e31837' },
                { label: 'Checklists Ok', val: report.checklists.total, sub: 'Cumplimiento', accent: '#fdc82f' },
                { label: 'Promotores', val: report.feedbacks.promoters, sub: 'Clientes Leales', accent: '#10b981' }
              ].map((m, i) => (
                <div key={i} className="bg-white p-7 rounded-[2rem] border border-gray-100 shadow-sm relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-12 h-1 bg-gray-100" style={{ backgroundColor: m.accent + '20' }}></div>
                  <p className="text-sm font-semibold text-gray-500 mb-1">{m.label}</p>
                  <h4 className={`text-4xl font-bold text-gray-900 tracking-tight`}>{m.val}</h4>
                  <div className="mt-4 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: m.accent }}></div>
                    <span className="text-xs font-medium text-gray-400 uppercase tracking-wide">{m.sub}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Tasks Breakdown */}
            <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-sm">
              <div className="flex justify-between items-center mb-10">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 tracking-tight">Logística de Cumplimiento</h3>
                  <p className="text-xs font-medium text-gray-400 mt-1">Sincronización de tareas por categoría</p>
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-5">
                {[
                  { label: 'Apertura', val: report.checklists.byType.apertura, icon: '☀️' },
                  { label: 'Daily', val: report.checklists.byType.daily, icon: '📝' },
                  { label: 'Control Fío', val: report.checklists.byType.temperaturas, icon: '🌡️' },
                  { label: 'Recorrido', val: report.checklists.byType.recorrido, icon: '🚶' },
                  { label: 'Merma', val: report.checklists.byType.sobrante, icon: '🍖' },
                  { label: 'Cierre', val: report.checklists.byType.cierre, icon: '🌙' }
                ].map((c, i) => (
                  <div key={i} className="bg-gray-50/50 border border-gray-100 p-6 rounded-2xl text-center transition-all hover:bg-white hover:border-[#e31837]/20 hover:shadow-sm">
                    <span className="text-xl block mb-2">{c.icon}</span>
                    <p className="text-[9px] font-black text-gray-400 uppercase tracking-tighter mb-1">{c.label}</p>
                    <p className="text-xl font-black text-gray-900">{c.val}</p>
                  </div>
                ))}
              </div>
            </div>

          </div>
        ) : !loading && (
          <div className="bg-white border-2 border-dashed border-gray-100 py-32 rounded-[3.5rem] text-center">
            <span className="text-6xl mb-6 block grayscale opacity-20">📊</span>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.4em]">Configurar parámetros para consulta de datos</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default function ReportesPage() {
  return <ReportesContent />
}
