import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
const JWT_SECRET = process.env.JWT_SECRET || 'gavilanes-secret-key-2025' // Fallback si no hay env

const supabase = createClient(supabaseUrl, supabaseAnonKey)

export async function POST(req: Request) {
  try {
    const { email, password } = await req.json()

    // 1. Buscar usuario
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .single()

    if (error || !user) {
      return NextResponse.json({ error: 'Credenciales inválidas' }, { status: 401 })
    }

    if (!user.active) {
      return NextResponse.json({ error: 'Usuario inactivo' }, { status: 403 })
    }

    // 2. Verificar contraseña
    // Primero intentamos comparación directa (legacy)
    let isValid = false
    if (user.password === password) {
      isValid = true
      // Opcional: Podríamos hashear la contraseña aquí si quisiéramos migrar
    } else {
      // Si no es directa, comparamos hash
      isValid = await bcrypt.compare(password, user.password)
    }

    if (!isValid) {
      return NextResponse.json({ error: 'Credenciales inválidas' }, { status: 401 })
    }

    // 3. Generar token
    const token = jwt.sign(
      {
        id: user.id,
        email: user.email,
        role: user.role,
        store_id: user.store_id
      },
      JWT_SECRET,
      { expiresIn: '8h' }
    )

    // 4. Retornar éxito
    const userData = {
      id: user.id,
      email: user.email,
      name: user.full_name,
      role: user.role,
      store_scope: user.store_scope,
      store_id: user.store_id
    }

    return NextResponse.json({
      token,
      user: userData
    })

  } catch (err) {
    console.error('Login error:', err)
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 })
  }
}