import os
import shutil
import time

def cleanup():
    target_dirs = [
        r"c:\Users\pedro\Desktop\teg-modernizado\app\(admin)",
        r"c:\Users\pedro\Desktop\teg-modernizado\app\checklists_BACKUP",
        r"c:\Users\pedro\Desktop\teg-modernizado\app\test-dates"
    ]
    
    for d in target_dirs:
        if os.path.exists(d):
            new_name = d + "_to_be_deleted_" + str(int(time.time()))
            try:
                print(f"Attempting to rename {d} to {new_name}")
                os.rename(d, new_name)
                print(f"Successfully renamed {d}")
            except Exception as e:
                print(f"Failed to rename {d}: {e}")
                # Try to rename files inside
                for root, dirs, files in os.walk(d):
                    for f in files:
                        if f in ["page.tsx", "layout.tsx"]:
                            f_path = os.path.join(root, f)
                            new_f_path = f_path + ".bak"
                            try:
                                os.rename(f_path, new_f_path)
                                print(f"Renamed {f_path} to {new_f_path}")
                            except Exception as fe:
                                print(f"Failed to rename {f_path}: {fe}")

if __name__ == "__main__":
    cleanup()
