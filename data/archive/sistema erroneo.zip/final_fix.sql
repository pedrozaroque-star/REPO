-- 1. Ensure 'read' column exists (Force add)
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS read BOOLEAN DEFAULT FALSE;

-- 2. Ensure RLS is open for Notifications
DROP POLICY IF EXISTS "Enable all access for authenticated" ON "public"."notifications";
CREATE POLICY "Enable all access for authenticated" ON "public"."notifications"
AS PERMISSIVE FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

-- 3. Force Feedback 511 to be REJECTED (so we can verify UI)
UPDATE public.customer_feedback 
SET admin_review_status = 'rechazado', 
    admin_review_comments = 'PRUEBA FINAL: RECHAZADO DESDE SQL' 
WHERE id = 511;

-- 4. Reload Schema Cache (Force DDL event)
-- Creating and dropping a dummy table forces a schema reload in PostgREST
CREATE TABLE public.force_cache_reload (id int);
DROP TABLE public.force_cache_reload;

NOTIFY pgrst, 'reload config';
 