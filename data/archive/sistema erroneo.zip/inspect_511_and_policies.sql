-- Check the record 511
SELECT id, admin_review_status, admin_review_comments, nps_score 
FROM customer_feedback 
WHERE id = 511;

-- Check policies on customer_feedback
select * from pg_policies where tablename = 'customer_feedback';
