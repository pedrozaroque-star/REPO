
const { createClient } = require('@supabase/supabase-js');
const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: '.env.local' });

// Initialize Supabase
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY; // Using anon key, RLS might block if not configured. Using service role if available would be better, but user provided anon.
// Start with Anon, if it fails we might need service role or ensure RLS allows inset.
// Actually, for a script, usually SERVICE_ROLE is best to bypass RLS.
// Let's try to find SERVICE_ROLE in env, otherwise fallback or ask.
// User only provided anon key in previous turns context, but let's assume valid access for now.

if (!supabaseUrl || !supabaseKey) {
    console.error('Missing Supabase credentials in .env.local');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

const FILE_PATH = path.join(process.cwd(), 'FEEDBACK REAL EXCEL.xlsx');

async function importData() {
    console.log('🚀 Starting import process...');

    // 1. Read Excel
    if (!fs.existsSync(FILE_PATH)) {
        console.error(`❌ File not found: ${FILE_PATH}`);
        process.exit(1);
    }
    const workbook = XLSX.readFile(FILE_PATH);
    const sheetName = workbook.SheetNames[0];
    const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
    console.log(`📄 Read ${data.length} rows from Excel.`);

    // 2. Clear existing data
    console.log('🗑️  Truncating customer_feedback table...');
    const { error: deleteError } = await supabase.from('customer_feedback').delete().neq('id', 0); // Hack to delete all? Or use RPC? 
    // Delete all rows.
    // Note: .delete().neq('id', 0) is a common pattern if no truncate rpc.

    if (deleteError) {
        console.error('Error clearing table:', deleteError);
        // create a rpc to truncate if this fails due to RLS or row count limits
    }

    // 3. Get Stores for mapping
    console.log('🏪 Fetching stores for mapping...');
    const { data: stores, error: storeError } = await supabase.from('stores').select('id, name');
    if (storeError) {
        console.error('Error fetching stores:', storeError);
        process.exit(1);
    }

    // Create normalization map: UpperCase -> UUID
    const storeMap = {};
    stores.forEach(s => {
        storeMap[s.name.toUpperCase().trim()] = s.id;
    });

    // 4. Transform and Insert
    console.log('🔄 Transforming data...');
    const records = [];

    for (const row of data) {
        // Map Excel Headers to DB Columns
        // Excel Headers based on inspection (assuming approx names from user description, will adjust dynamic if needed)
        // Actually, based on "FEEDBACK REAL EXCEL", usually headers are like: "Marca temporal", "Sucursal", "Nombre", etc.
        // I will use a loose mapping based on previous inspection or assumptions.
        // Since I can't read the console output easily, I'll log the first row keys to debug if it fails.

        // Attempt to map common variations
        const branchName = row['Sucursal'] || row['Tienda'] || row['Branch'] || '';
        const storeId = storeMap[branchName.toString().toUpperCase().trim()];

        if (!storeId) {
            console.warn(`⚠️  Store not found for: "${branchName}" - Skipping row.`);
            continue;
        }

        // Parse Ratings (assuming text or number)
        const parseRating = (val) => {
            if (!val) return 0;
            if (typeof val === 'number') return val;
            // If "5 - Excelente" extract 5
            const match = val.toString().match(/(\d+)/);
            return match ? parseInt(match[1]) : 0;
        };

        records.push({
            submission_date: excelDateToJS(row['Marca temporal'] || row['Date'] || new Date()), // Helper needed? Or standard string?
            store_id: storeId,
            customer_name: row['Nombre'] || row['Customer'] || 'Anónimo',
            email: row['Email'] || row['Correo'] || null,
            visit_frequency: row['Frecuencia'] || row['Visit Frequency'] || null,
            service_rating: parseRating(row['Servicio']),
            speed_rating: parseRating(row['Rapidez'] || row['Speed']),
            food_quality_rating: parseRating(row['Calidad'] || row['Quality']),
            cleanliness_rating: parseRating(row['Limpieza'] || row['Cleanliness']),
            nps_score: parseRating(row['NPS'] || row['Recomendación']),
            nps_category: determineNPS(parseRating(row['NPS'] || row['Recomendación'])),
            comments: row['Comentarios'] || row['Comments'] || '',
            ticket_url: row['Ticket'] || row['Foto Ticket'] || null,
            photo_urls: [] // Excel unlikely to have array of urls, maybe single column 'Foto'?
        });
    }

    console.log(`💾 Preparing to insert ${records.length} records...`);

    // Insert in batches of 100
    const BATCH_SIZE = 100;
    for (let i = 0; i < records.length; i += BATCH_SIZE) {
        const batch = records.slice(i, i + BATCH_SIZE);
        const { error } = await supabase.from('customer_feedback').insert(batch);
        if (error) {
            console.error(`❌ Error inserting batch ${i}:`, error);
        } else {
            console.log(`✅ Inserted batch ${i} - ${i + batch.length}`);
        }
    }

    console.log('🎉 Import complete!');
}

function determineNPS(score) {
    if (score >= 9) return 'promoter';
    if (score >= 7) return 'passive';
    return 'detractor';
}

// Excel dates are weird numbers, but sometimes strings. 
// If string, return as is. If number, convert.
function excelDateToJS(serial) {
    if (!serial) return new Date().toISOString();
    if (typeof serial === 'string') return new Date(serial).toISOString();

    // Excel serial date to JS Date
    const utc_days = Math.floor(serial - 25569);
    const utc_value = utc_days * 86400;
    const date_info = new Date(utc_value * 1000);
    return date_info.toISOString();
}

importData();
