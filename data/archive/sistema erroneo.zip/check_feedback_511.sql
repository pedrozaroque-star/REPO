SELECT id, admin_review_status, admin_review_comments, nps_score 
FROM customer_feedback 
WHERE id = 511;
