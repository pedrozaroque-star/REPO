SELECT id, photo_urls, array_length(photo_urls, 1) as count 
FROM customer_feedback 
WHERE photo_urls IS NOT NULL 
LIMIT 3;
