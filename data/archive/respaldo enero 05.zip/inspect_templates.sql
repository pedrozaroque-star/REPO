-- Get current checklist templates and their questions
SELECT id, name, type, questions
FROM checklist_templates;
