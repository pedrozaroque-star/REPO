print("Hello from Python")
