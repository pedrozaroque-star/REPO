'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import ProtectedRoute, { useAuth } from '@/components/ProtectedRoute'
import ChecklistReviewModal from '@/components/ChecklistReviewModal'
import { getSupabaseClient } from '@/lib/supabase'
import { getStatusColor, getStatusLabel, formatDateLA, canEditChecklist } from '@/lib/checklistPermissions'

function InspeccionesContent() {
  const router = useRouter()
  const { user } = useAuth()
  const [inspections, setInspections] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [storeFilter, setStoreFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [stores, setStores] = useState<any[]>([])

  // Modal State
  const [selectedInspection, setSelectedInspection] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const [errorMsg, setErrorMsg] = useState<string | null>(null)

  useEffect(() => {
    if (user) fetchData()
  }, [storeFilter, statusFilter, user])

  const fetchData = async () => {
    try {
      setLoading(true)
      setErrorMsg(null)

      const supabase = await getSupabaseClient()

      // Asegurar que el cliente reconozca el token antes de la primera petición RLS
      const token = localStorage.getItem('teg_token')
      if (token) {
        await supabase.auth.setSession({ access_token: token, refresh_token: '' })
      }

      // 1. Obtener tiendas y usuarios para mapeo manual
      const { data: storesList, error: storesListError } = await supabase.from('stores').select('*').order('name', { ascending: true })
      if (storesListError) console.error('❌ Error fetching stores list:', storesListError);

      const { data: usersList, error: usersListError } = await supabase.from('users').select('id, full_name')
      if (usersListError) console.error('❌ Error fetching users list:', usersListError);

      setStores(storesList || [])


      // 2. Obtener inspecciones básicas (Sin Joins complejos que puedan fallar por RLS o FKs)

      let query = supabase
        .from('supervisor_inspections')
        .select('*')
        .order('inspection_date', { ascending: false })

      if (storeFilter !== 'all') {
        query = query.eq('store_id', storeFilter)
      } else if (user?.role === 'manager' || user?.role === 'gerente') {
        // [FIX] Managers solo ven SU tienda
        if (user.store_id) query = query.eq('store_id', user.store_id)
      } else {

      }

      const { data: rawData, error: rawError } = await query

      if (rawError) {
        console.error('❌ Error de consulta de inspecciones:', rawError)
        throw rawError
      }


      // 3. Mapeo manual de datos
      const mappedData = (rawData || []).map(item => {
        const store = (storesList || []).find(s => s.id === item.store_id)
        const user = (usersList || []).find(u => u.id === item.inspector_id)

        return {
          ...item,
          store_name: store?.name || 'N/A',
          supervisor_name: user?.full_name || item.supervisor_name || 'Desconocido',
          checklist_type: 'supervisor',
          checklist_date: item.inspection_date,
          score: item.overall_score,
          photo_urls: item.photos || []
        }
      })

      // 4. Filtrar por estado si aplica
      const finalData = statusFilter !== 'all'
        ? mappedData.filter(item => (item.estatus_admin || 'pendiente') === statusFilter)
        : mappedData

      setInspections(finalData)
    } catch (error: any) {
      console.error('Error fetching data:', error)

      // Manejo específico de error de sesión (JWT Inválido)
      if (error?.code === 'PGRST301' || error?.message?.includes('JWT')) {
        setErrorMsg('Tu sesión ha expirado. Redirigiendo al login...')
        setTimeout(() => {
          localStorage.removeItem('teg_token')
          localStorage.removeItem('teg_user')
          window.location.href = '/login'
        }, 2000)
        return
      }

      setErrorMsg(error.message || 'Error al cargar inspecciones')
    } finally {
      setLoading(false)
    }
  }

  const handleRowClick = (inspection: any) => {
    setSelectedInspection(inspection)
    setIsModalOpen(true)
  }

  // --- RENDER ---
  if (loading) return <div className="flex h-screen items-center justify-center">Cargando inspecciones...</div>

  return (
    <div className="flex bg-transparent h-screen overflow-hidden pt-16 lg:pt-0 font-sans">
      <div className="flex-1 flex flex-col h-full w-full relative">

        {/* 1. STICKY HEADER (Matches Reportes Design) */}
        <div className="bg-white border-b border-gray-200 px-4 md:px-8 py-4 flex flex-col md:flex-row justify-between items-center gap-4 sticky top-14 lg:top-0 z-20 shadow-sm shrink-0">
          <div className="w-full md:w-auto">
            <h1 className="text-xl md:text-2xl font-black text-gray-900 leading-none">Inspecciones de Supervisor</h1>
            <p className="text-xs font-bold text-gray-400 mt-1 uppercase tracking-wide">Auditoría y control de calidad</p>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            <button
              onClick={() => router.push('/inspecciones/nueva')}
              className="bg-gray-900 hover:bg-black text-white px-5 py-2.5 rounded-lg font-bold shadow-lg transition-all flex items-center justify-center gap-2 w-full md:w-auto text-sm"
            >
              <span>+</span> Nueva Inspección
            </button>
          </div>
        </div>

        {/* 2. SCROLLABLE CONTENT (Stats + Filters + List) */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">

          {/* STATS CARDS */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white rounded-xl shadow-sm p-4 border border-indigo-100 border-l-4 border-l-indigo-500">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Total</p>
              <p className="text-2xl font-black text-gray-900 mt-0.5">{inspections.length}</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-4 border border-green-100 border-l-4 border-l-green-500">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Promedio</p>
              <p className="text-2xl font-black text-gray-900 mt-0.5">
                {inspections.length > 0
                  ? Math.round(inspections.reduce((acc, curr) => acc + (curr.overall_score || 0), 0) / inspections.length) + '%'
                  : 'N/A'}
              </p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-4 border border-yellow-100 border-l-4 border-l-yellow-500">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Pendientes</p>
              <p className="text-2xl font-black text-gray-900 mt-0.5">
                {inspections.filter(i => (i.estatus_admin || 'pendiente') === 'pendiente').length}
              </p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-4 border border-blue-100 border-l-4 border-l-blue-500">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Aprobados</p>
              <p className="text-2xl font-black text-gray-900 mt-0.5">
                {inspections.filter(i => i.estatus_admin === 'aprobado').length}
              </p>
            </div>
          </div>

          {/* FILTERS */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all uppercase tracking-wide ${statusFilter === 'all' ? 'bg-gray-800 text-white shadow-md transform scale-105' : 'bg-white text-gray-500 border border-gray-200 hover:bg-gray-50'}`}
            >
              Todos
            </button>
            <button
              onClick={() => setStatusFilter('pendiente')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all uppercase tracking-wide ${statusFilter === 'pendiente' ? 'bg-yellow-400 text-yellow-900 shadow-md transform scale-105' : 'bg-white text-gray-500 border border-gray-200 hover:bg-yellow-50 hover:text-yellow-600'}`}
            >
              Pendientes
            </button>
            <button
              onClick={() => setStatusFilter('aprobado')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all uppercase tracking-wide ${statusFilter === 'aprobado' ? 'bg-green-500 text-white shadow-md transform scale-105' : 'bg-white text-gray-500 border border-gray-200 hover:bg-green-50 hover:text-green-600'}`}
            >
              Aprobados
            </button>
            <button
              onClick={() => setStatusFilter('rechazado')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all uppercase tracking-wide ${statusFilter === 'rechazado' ? 'bg-red-500 text-white shadow-md transform scale-105' : 'bg-white text-gray-500 border border-gray-200 hover:bg-red-50 hover:text-red-600'}`}
            >
              Rechazados
            </button>
          </div>


          {/* DESKTOP TABLE VIEW (HIDDEN ON MOBILE) */}
          <div className="hidden lg:flex bg-white rounded-xl shadow-sm border border-gray-200 flex-col overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse relative">
                <thead className="bg-gray-50 border-b border-gray-200 text-xs uppercase text-gray-500 font-bold">
                  <tr>
                    <th className="p-4">Tienda</th>
                    <th className="p-4">Supervisor</th>
                    <th className="p-4 text-center">Fecha</th>
                    <th className="p-4 text-center">Turno</th>
                    <th className="p-4 text-center">Duración</th>
                    <th className="p-4 text-center">Score</th>
                    <th className="p-4 text-center">Estado</th>
                    <th className="p-4 text-center">Evidencia</th>
                    <th className="p-4 text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="text-sm divide-y divide-gray-100">
                  {errorMsg ? (
                    <tr>
                      <td colSpan={9} className="p-8 text-center text-red-500 font-bold">
                        {errorMsg}
                      </td>
                    </tr>
                  ) : inspections.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-8 text-center text-gray-400 italic">No se encontraron inspecciones.</td>
                    </tr>
                  ) : (
                    inspections.map((item) => {
                      // Calculate Duration
                      let duration = 'N/A'
                      if (item.start_time && item.end_time) {
                        try {
                          const startParts = item.start_time.split(':').map(Number)
                          const endParts = item.end_time.split(':').map(Number)
                          if (startParts.length >= 2 && endParts.length >= 2) {
                            const startMinutes = startParts[0] * 60 + startParts[1]
                            const endMinutes = endParts[0] * 60 + endParts[1]
                            let diff = endMinutes - startMinutes
                            if (diff < 0) diff += 24 * 60
                            const hours = Math.floor(diff / 60)
                            const mins = diff % 60
                            duration = hours > 0 ? `${hours}h ${mins}m` : `${mins} min`
                          }
                        } catch (e) { }
                      }

                      return (
                        <tr
                          key={item.id}
                          onClick={() => handleRowClick(item)}
                          className="hover:bg-blue-50/50 cursor-pointer transition-colors group"
                        >
                          <td className="p-4 font-bold text-gray-900">{item.store_name}</td>
                          <td className="p-4 text-gray-600 text-xs font-semibold">{item.supervisor_name}</td>
                          <td className="p-4 text-center text-gray-500 text-xs font-semibold">{formatDateLA(item.inspection_date)}</td>
                          <td className="p-4 text-center">
                            <span className={`px-2 py-1 rounded text-[10px] font-black uppercase ${item.shift === 'AM' ? 'bg-yellow-100 text-yellow-700' : 'bg-blue-100 text-blue-700'}`}>
                              {item.shift}
                            </span>
                          </td>
                          <td className="p-4 text-center">
                            <span className="text-xs font-bold text-gray-500 bg-gray-100 px-2 py-1 rounded-full">{duration}</span>
                          </td>
                          <td className="p-4 text-center">
                            <span className={`text-base font-black ${item.overall_score >= 87 ? 'text-green-600' : 'text-red-500'}`}>
                              {item.overall_score}%
                            </span>
                          </td>
                          <td className="p-4 text-center">
                            <span className={`px-2 py-1 rounded-full text-[10px] font-black uppercase border ${getStatusColor(item.estatus_admin || 'pendiente')}`}>
                              {getStatusLabel(item.estatus_admin || 'pendiente')}
                            </span>
                          </td>
                          <td className="p-4 text-center">
                            {(item.photos && item.photos.length > 0) ? (
                              <span className="inline-flex items-center justify-center w-8 h-8 bg-blue-50 text-blue-600 rounded-full text-xs font-bold" title={`${item.photos.length} fotos`}>
                                📷
                              </span>
                            ) : (
                              <span className="text-gray-300">-</span>
                            )}
                          </td>
                          <td className="p-4 text-center">
                            <button className="text-gray-400 hover:text-blue-600 font-bold text-xs underline opacity-0 group-hover:opacity-100 transition-opacity">
                              Ver Detalle
                            </button>
                          </td>
                        </tr>
                      )
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* MOBILE CARDS VIEW (VISIBLE ONLY ON MOBILE) */}
          <div className="lg:hidden space-y-4">
            {inspections.map((item) => (
              <div
                key={item.id}
                onClick={() => handleRowClick(item)}
                className="bg-white rounded-2xl p-5 shadow-sm border border-gray-200 active:scale-[0.98] transition-transform"
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex flex-col">
                    <h3 className="text-base font-black text-gray-900 leading-tight">{item.store_name}</h3>
                    <span className="text-xs font-bold text-gray-500 mt-1">{formatDateLA(item.inspection_date)}</span>
                  </div>
                  <span className={`text-xl font-black ${item.overall_score >= 87 ? 'text-green-600' : 'text-red-500'}`}>
                    {item.overall_score}%
                  </span>
                </div>

                <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-50">
                  <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-1 rounded-md text-[10px] font-black uppercase tracking-wide border ${getStatusColor(item.estatus_admin || 'pendiente')}`}>
                      {getStatusLabel(item.estatus_admin || 'pendiente')}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${item.shift === 'AM' ? 'bg-yellow-50 text-yellow-700' : 'bg-blue-50 text-blue-700'}`}>
                      {item.shift}
                    </span>
                  </div>

                  {item.photos && item.photos.length > 0 && (
                    <div className="flex items-center gap-1 text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-full">
                      <span>📷</span>
                      <span>{item.photos.length}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {inspections.length === 0 && !loading && (
              <div className="text-center text-gray-400 py-10 font-bold">No hay inspecciones.</div>
            )}
          </div>

          <div className="h-16"></div> {/* Bottom Spacer */}
        </div>

      </div>

      {/* Review Modal */}
      {
        selectedInspection && user && (
          <ChecklistReviewModal
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            checklist={selectedInspection}
            currentUser={{
              id: user.id || 0,
              name: user.name || user.email || 'Usuario',
              email: user.email || '',
              role: user.role || 'viewer'
            }}
            onUpdate={fetchData}
          />
        )
      }
    </div>
  )
}

export default function InspeccionesPage() {
  return (
    <ProtectedRoute>
      <InspeccionesContent />
    </ProtectedRoute>
  )
}