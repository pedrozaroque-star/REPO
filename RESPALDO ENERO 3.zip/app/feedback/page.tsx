'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { getSupabaseClient } from '@/lib/supabase' // ✅ Importación necesaria
import ProtectedRoute, { useAuth } from '@/components/ProtectedRoute'

import FeedbackReviewModal from '@/components/FeedbackReviewModal'

function FeedbackContent() {
  const router = useRouter()
  const { user } = useAuth()

  // -- STATE DEFINITIONS --
  const [stats, setStats] = useState({
    total: 0,
    promoters: 0,
    passives: 0,
    detractors: 0,
    nps: 0,
    avgService: 0,
    avgQuality: 0,
    avgCleanliness: 0,
    avgSpeed: 0
  })
  const [feedbacks, setFeedbacks] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [storeFilter, setStoreFilter] = useState('all')
  const [stores, setStores] = useState<any[]>([])

  // Modal State
  const [selectedFeedback, setSelectedFeedback] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  // 🚨 DETECTOR DE CONFLICTO DE IDENTIDAD (Moved up to avoid Hook Error)
  const [tokenIdentity, setTokenIdentity] = useState<any>(null)

  // -- EFFECTS --

  useEffect(() => {
    if (user) fetchData()
  }, [storeFilter, user])

  // Identity Check Effect
  useEffect(() => {
    const fetchIdentity = async () => {
      const token = localStorage.getItem('teg_token')
      if (!token) return

      // 🔍 Decodificar el JWT para saber QUÉ usuario representa
      try {
        const payload = JSON.parse(atob(token.split('.')[1]))
        const jwtEmail = payload.email

        console.log('🔑 JWT Email:', jwtEmail)

        const supabase = await getSupabaseClient()

        // ✅ CONSULTA CORREGIDA: Buscar el usuario ESPECÍFICO del JWT
        const { data } = await supabase
          .from('users')
          .select('email, role')
          .eq('email', jwtEmail)  // 🎯 CRUCIAL: Filtrar por el email del JWT
          .single()

        if (data) {
          console.log('🕵️‍♂️ Usuario del Token:', data)
          setTokenIdentity(data)
        }
      } catch (err) {
        console.error('❌ Error decodificando JWT:', err)
      }
    }
    fetchIdentity()
  }, []) // Empty dependency array = run once on mount

  // Log Conflict Effect
  useEffect(() => {
    if (user && tokenIdentity && tokenIdentity.email !== user.email) {
      console.error('🚨 CONFLICTO CRÍTICO DE IDENTIDAD DETECTADO')
    }
  }, [user, tokenIdentity])

  // -- HELPER FUNCTIONS --

  const fetchData = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem('teg_token')

      if (!token) {
        console.warn('⚠️ No se encontró token para RLS')
        setLoading(false)
        return
      }

      const supabase = await getSupabaseClient()

      console.log('🔑 Token inyectado en cliente nuevo. Probando RPC get_my_claims...')
      const { data: claimsData, error: claimsError } = await supabase.rpc('get_my_claims')
      console.log('🕵️‍♂️ RAW JWT CLAIMS:', { claimsData, claimsError })


      // Obtener tiendas
      const { data: storesData } = await supabase.from('stores').select('*')
      setStores(storesData || [])

      // Obtener feedbacks
      let query = supabase
        .from('customer_feedback')
        .select('*, stores(name,code,city,state)')
        .order('submission_date', { ascending: false })

      if (storeFilter !== 'all') {
        query = query.eq('store_id', storeFilter)
      }

      const { data: feedbackData, error } = await query

      console.log('🔍 FETCH DEBUG:', {
        feedbackData,
        error,
        userRole: user?.role,  // DEBUG ROLE
        userId: user?.id       // DEBUG ID
      })

      if (error) throw error

      setFeedbacks(feedbackData || [])

      // Calcular estadísticas
      if (feedbackData && feedbackData.length > 0) {
        const promoters = feedbackData.filter((f: any) => f.nps_category === 'promoter').length
        const passives = feedbackData.filter((f: any) => f.nps_category === 'passive').length
        const detractors = feedbackData.filter((f: any) => f.nps_category === 'detractor').length
        const nps = Math.round(((promoters - detractors) / feedbackData.length) * 100)

        const avgService = feedbackData.reduce((sum: number, f: any) => sum + (f.service_rating || 0), 0) / feedbackData.length
        const avgQuality = feedbackData.reduce((sum: number, f: any) => sum + (f.food_quality_rating || 0), 0) / feedbackData.length
        const avgCleanliness = feedbackData.reduce((sum: number, f: any) => sum + (f.cleanliness_rating || 0), 0) / feedbackData.length
        const avgSpeed = feedbackData.reduce((sum: number, f: any) => sum + (f.speed_rating || 0), 0) / feedbackData.length

        setStats({
          total: feedbackData.length,
          promoters,
          passives,
          detractors,
          nps,
          avgService: Math.round(avgService * 10) / 10,
          avgQuality: Math.round(avgQuality * 10) / 10,
          avgCleanliness: Math.round(avgCleanliness * 10) / 10,
          avgSpeed: Math.round(avgSpeed * 10) / 10
        })
      }
    } catch (err) {
      console.error('Error fetching data:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleRowClick = (feedback: any) => {
    setSelectedFeedback(feedback)
    setIsModalOpen(true)
  }

  const getNPSColor = (nps: number) => {
    if (nps >= 50) return 'text-green-600'
    if (nps >= 0) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getCategoryBadge = (category: string) => {
    const colors: any = {
      promoter: 'bg-green-100 text-green-800 border-green-200',
      passive: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      detractor: 'bg-red-100 text-red-800 border-red-200'
    }
    return colors[category] || 'bg-gray-100 text-gray-800 border-gray-200'
  }

  // Permission Logic: Only Admin can review/edit
  const isAdmin = user?.role === 'admin'

  const handleForceLogout = () => {
    localStorage.clear()
    window.location.href = '/login'
  }

  // -- RENDER --
  if (loading) return <div className="flex h-screen items-center justify-center">Cargando feedback...</div>

  return (
    <div className="flex bg-transparent h-screen overflow-hidden">
      <div className="flex-1 flex flex-col h-full w-full relative">

        {/* 🚨 BANNER DE DEBUG DE EMERGENCIA - IMPRESO SOBRE TODO */}
        {tokenIdentity && user && tokenIdentity.email !== user.email && (
          <div className="absolute inset-0 z-50 bg-gray-900/95 flex items-center justify-center backdrop-blur-sm">
            <div className="bg-red-600 text-white p-8 rounded-2xl shadow-2xl border-4 border-yellow-400 max-w-2xl w-full mx-4 animate-pulse">
              <div className="flex items-start gap-6">
                <span className="text-6xl">🕵️‍♂️🛑</span>
                <div className="flex-1">
                  <h2 className="text-3xl font-black uppercase tracking-wider mb-4">
                    CONFLICTO DE IDENTIDAD DETECTADO
                  </h2>
                  <p className="mb-6 text-red-100 font-medium text-lg">
                    Tu navegador está "embrujado". Crees que eres <b>{user.role}</b> pero tu llave es de <b>{tokenIdentity.role}</b>.
                    <br />
                    Esto impide que veas los datos.
                  </p>
                  <div className="grid grid-cols-2 gap-4 bg-black/20 p-4 rounded-xl mb-6 font-mono text-sm border border-red-500">
                    <div>
                      <p className="text-red-300 text-xs uppercase mb-1">Tu Navegador dice:</p>
                      <p className="text-xl font-bold text-white truncate" title={user.email}>{user.email}</p>
                      <span className="inline-block bg-green-500 text-black text-xs px-2 py-0.5 rounded font-bold mt-1 uppercase">{user.role}</span>
                    </div>
                    <div>
                      <p className="text-red-300 text-xs uppercase mb-1">La Base de Datos ve:</p>
                      <p className="text-xl font-bold text-yellow-300 truncate" title={tokenIdentity.email}>{tokenIdentity.email}</p>
                      <span className="inline-block bg-red-800 text-white text-xs px-2 py-0.5 rounded font-bold mt-1 uppercase">{tokenIdentity.role}</span>
                    </div>
                  </div>
                  <button
                    onClick={handleForceLogout}
                    className="w-full bg-white text-red-700 font-black py-4 px-6 rounded-xl shadow-lg hover:scale-105 transition-transform uppercase tracking-widest text-lg border-b-4 border-gray-300 hover:border-gray-400 active:border-b-0 active:translate-y-1"
                  >
                    🚀 Reparar Sesión (Reset Total)
                  </button>
                  <p className="text-center text-red-200 text-xs mt-3 uppercase tracking-widest opacity-70">
                    Al hacer clic volverás al login
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* FIXED HEADER */}
        <div className="flex-none p-8 pb-0 z-10 bg-transparent">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Feedback de Clientes</h1>
              <p className="text-gray-600 mt-2">Encuestas de satisfacción y NPS.</p>
            </div>
            {/* Solo Admin podría, por ejemplo, exportar o configurar, pero dejaremos el botón de 'Nuevo' por si acaso manual */}
            <button
              onClick={() => router.push('/feedback/nuevo')}
              className="bg-gray-900 hover:bg-black text-white px-6 py-3 rounded-xl font-bold shadow-lg transition-all flex items-center gap-2"
            >
              + Nuevo Feedback
            </button>
          </div>

          {/* STATS CARDS */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">

            {/* NEW: Total Feedback Card */}
            <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-gray-800">
              <p className="text-xs font-medium text-gray-600">Total Encuestas</p>
              <p className="text-2xl font-bold mt-1 text-gray-900">{stats.total}</p>
            </div>

            <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-indigo-600">
              <p className="text-xs font-medium text-gray-600">NPS Score</p>
              <p className={`text-2xl font-bold mt-1 ${getNPSColor(stats.nps)}`}>{stats.nps}</p>
            </div>
            <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-green-600">
              <p className="text-xs font-medium text-gray-600">Servicio</p>
              <div className="flex items-center gap-1 mt-1">
                <span className="text-2xl font-bold text-gray-900">{stats.avgService}</span>
                <span className="text-yellow-500 text-sm">⭐</span>
              </div>
            </div>
            <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-red-600">
              <p className="text-xs font-medium text-gray-600">Calidad</p>
              <div className="flex items-center gap-1 mt-1">
                <span className="text-2xl font-bold text-gray-900">{stats.avgQuality}</span>
                <span className="text-yellow-500 text-sm">⭐</span>
              </div>
            </div>
            <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-purple-600">
              <p className="text-xs font-medium text-gray-600">Limpieza</p>
              <div className="flex items-center gap-1 mt-1">
                <span className="text-2xl font-bold text-gray-900">{stats.avgCleanliness}</span>
                <span className="text-yellow-500 text-sm">⭐</span>
              </div>
            </div>
            <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-yellow-600">
              <p className="text-xs font-medium text-gray-600">Rapidez</p>
              <div className="flex items-center gap-1 mt-1">
                <span className="text-2xl font-bold text-gray-900">{stats.avgSpeed}</span>
                <span className="text-yellow-500 text-sm">⭐</span>
              </div>
            </div>
          </div>

          {/* FILTERS */}
          <div className="bg-white rounded-xl shadow-md p-4 mb-4">
            <div className="flex items-center gap-4">
              <div>
                <label className="text-xs font-medium text-gray-700 block mb-1">Sucursal</label>
                <select
                  value={storeFilter}
                  onChange={(e) => setStoreFilter(e.target.value)}
                  className="w-full md:w-64 px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                >
                  <option value="all">🏢 Todas las Tiendas</option>
                  {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* SCROLLABLE TABLE */}
        <div className="flex-1 overflow-y-auto p-8 pt-0">
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse relative">
                <thead className="bg-gray-50 border-b border-gray-200 sticky top-0 z-10">
                  <tr className="text-xs font-bold text-gray-700 uppercase tracking-wider">
                    <th className="px-6 py-3">Fecha</th>
                    <th className="px-6 py-3">Sucursal</th>
                    <th className="px-6 py-3">Cliente</th>
                    <th className="px-6 py-3 text-center">NPS</th>
                    {/* Combined Rating Column for Cleaner Look */}
                    <th className="px-6 py-3 text-center">Calif. Gral</th>
                    <th className="px-6 py-3 text-center">Evidencia</th>
                    <th className="px-6 py-3 text-center">Comentario</th>
                    <th className="px-6 py-3 text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {feedbacks.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-gray-500 italic">No hay feedbacks registrados.</td>
                    </tr>
                  ) : (
                    feedbacks.map((item) => (
                      <tr
                        key={item.id}
                        onClick={() => handleRowClick(item)}
                        className="hover:bg-gray-50 cursor-pointer transition-colors group"
                      >
                        <td className="px-6 py-4 text-sm text-gray-500 whitespace-nowrap">
                          <div className="font-medium text-gray-900">{new Date(item.submission_date).toLocaleDateString('es-MX')}</div>
                          <div className="text-xs">{new Date(item.submission_date).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })}</div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="font-bold text-gray-900">{item.stores?.name}</span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm font-medium text-gray-900">{item.customer_name || 'Anónimo'}</div>
                          {item.customer_email && <div className="text-xs text-gray-500 truncate max-w-[150px]">{item.customer_email}</div>}
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span className={`px-2 py-1 rounded text-xs font-bold border ${getCategoryBadge(item.nps_category)}`}>
                            {item.nps_score}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          {/* Average Rating Stars */}
                          <div className="flex justify-center text-yellow-400 text-sm">
                            {'⭐'.repeat(Math.round((item.service_rating + item.food_quality_rating + item.cleanliness_rating + item.speed_rating) / 4))}
                          </div>
                          <div className="text-[10px] text-gray-400 mt-1">Promedio</div>
                        </td>
                        <td className="px-6 py-4 text-center">
                          {(item.photo_urls && item.photo_urls.length > 0) ? (
                            <span className="inline-flex items-center justify-center p-2 bg-blue-50 text-blue-600 rounded-full">
                              📷
                            </span>
                          ) : (
                            <span className="text-gray-300">-</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-center">
                          {item.comments ? (
                            <div className="text-xs text-gray-600 italic truncate max-w-[200px]" title={item.comments}>
                              "{item.comments}"
                            </div>
                          ) : (
                            <span className="text-gray-300 text-xs">-</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-center">
                          {isAdmin ? (
                            <button className="text-indigo-600 hover:text-indigo-900 font-bold text-xs bg-indigo-50 px-3 py-1 rounded hover:bg-indigo-100 transition-colors">
                              Revisar
                            </button>
                          ) : (
                            <button className="text-gray-400 hover:text-indigo-600 font-bold text-xs underline decoration-2 underline-offset-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              Ver Detalle
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedFeedback && user && (
        <FeedbackReviewModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          feedback={selectedFeedback}
          currentUser={user}
          onUpdate={fetchData}
        />
      )}
    </div>
  )
}

export default function FeedbackPage() {
  return (
    <ProtectedRoute>
      <FeedbackContent />
    </ProtectedRoute>
  )
}