'use client'

import { useEffect, useState, useMemo, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import ProtectedRoute, { useAuth } from '@/components/ProtectedRoute'
import ChecklistReviewModal from '@/components/ChecklistReviewModal'
import { canEditChecklist, getStatusColor, getStatusLabel, formatDateLA, isOverdue } from '@/lib/checklistPermissions'
import { getSupabaseClient } from '@/lib/supabase'

function ChecklistsContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { user } = useAuth()
  const [checklists, setChecklists] = useState<any[]>([])
  const [stats, setStats] = useState({
    total: 0,
    daily: 0,
    temperaturas: 0,
    sobrante: 0,
    recorrido: 0,
    cierre: 0,
    apertura: 0
  })
  const [loading, setLoading] = useState(true)
  const [typeFilter, setTypeFilter] = useState('all')
  const [storeFilter, setStoreFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [stores, setStores] = useState<any[]>([])
  const [showReviewModal, setShowReviewModal] = useState(false)
  const [selectedChecklist, setSelectedChecklist] = useState<any>(null)

  useEffect(() => {
    if (user) {
      fetchStores()
    }
  }, [user])

  useEffect(() => {
    if (user && stores.length > 0) {
      fetchData()
    }
  }, [typeFilter, storeFilter, statusFilter, user, stores])

  // 🔗 EFECTO: Abrir modal si viene ID en la URL (Notificaciones)
  useEffect(() => {
    const checkUrlForModal = async () => {
      const id = searchParams.get('id')
      if (id) {
        // 1. Buscar en la lista ya cargada (comparando como string)
        // 1. Buscar en la lista ya cargada (comparando como string)
        const found = checklists.find(c => c.id.toString() === id)

        if (found) {
          setSelectedChecklist(found)
          setShowReviewModal(true)
        } else {
          // 2. Si no está (ej. filtro activo o muy viejo), buscarlo individualmente
          try {
            const supabase = await getSupabaseClient()
            const { data, error } = await supabase
              .from('assistant_checklists')
              .select('*, stores(name, code), users!user_id(full_name)')
              .eq('id', id)
              .single()

            if (data && !error) {
              // Estandarizar objeto para el Modal (igual que fetchData)
              const formatted = {
                ...data,
                store_name: (data as any).stores?.name || 'N/A'
              }
              setSelectedChecklist(formatted)
              setShowReviewModal(true)
              // Opcional: limpiar URL para no reabrir al recargar
              // router.replace('/checklists', { scroll: false }) 
            }
          } catch (e) {
            console.error('Error fetching deep link checklist', e)
          }
        }
      }


      // 🔄 AUTO-OPEN LATEST (Fallback para notificaciones rotas)
      const autoOpen = searchParams.get('auto_open')
      if (autoOpen === 'latest') {
        if (!user) return

        try {
          const supabase = await getSupabaseClient()
          const { data, error } = await supabase
            .from('assistant_checklists')
            .select('*, stores(name, code), users!user_id(full_name)')
            .eq('user_id', user.id) // Mis checklists
            .order('fecha_revision_manager', { ascending: false }) // Último revisado
            .limit(1)
            .single()

          if (data && !error) {
            const formatted = {
              ...data,
              store_name: (data as any).stores?.name || 'N/A'
            }
            setSelectedChecklist(formatted)
            setShowReviewModal(true)
          }
        } catch (e) {
          console.error('Error auto-opening latest:', e)
        }
      }
    }
    checkUrlForModal()
  }, [searchParams, checklists, loading])

  const fetchStores = async () => {
    try {
      const supabase = await getSupabaseClient()
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      // 🔄 CLIENTE MEMORIZADO (Para evitar warnings)
      const res = await supabase.from('stores').select('*')
      const data = res.data
      let loadedStores = Array.isArray(data) ? data : []

      const userScope = (user as any)?.store_scope
      if (user?.role === 'asistente' && Array.isArray(userScope) && userScope.length > 0) {
        loadedStores = loadedStores.filter(s => userScope.includes(s.code) || userScope.includes(s.name))
      }

      setStores(loadedStores)
    } catch (err) {
      console.error('Error tiendas:', err)
    }
  }

  const fetchData = async () => {
    try {
      const supabase = await getSupabaseClient()

      // Construcción de Query con Cliente Supabase
      let query = supabase
        .from('assistant_checklists')
        .select('*, stores(name, code), users!user_id(full_name)')
        .order('checklist_date', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(100)

      if (typeFilter !== 'all') query = query.eq('checklist_type', typeFilter)
      if (storeFilter !== 'all') query = query.eq('store_id', storeFilter)

      const userScope = (user as any)?.store_scope

      // 🔒 FILTRO PARA ASISTENTES - Solo su tienda Y sus checklists
      if (user?.role === 'asistente') {
        let allowedStoreIds: any[] = []
        if (Array.isArray(userScope) && userScope.length > 0) {
          allowedStoreIds = stores
            .filter(s => userScope.includes(s.code) || userScope.includes(s.name))
            .map(s => s.id)
        }
        if (allowedStoreIds.length > 0) {
          query = query.in('store_id', allowedStoreIds)
        } else {
          query = query.eq('store_id', 0)
        }

        // SOLO sus propios checklists
        query = query.eq('user_id', user.id)
      }
      // 🔒 FILTRO PARA MANAGERS - Solo su tienda asignada
      else if (user?.role === 'manager' && (user as any)?.store_id) {
        query = query.eq('store_id', (user as any).store_id)
      }

      if (typeFilter !== 'all') {
        query = query.eq('checklist_type', typeFilter)
      }

      const { data: checkData, error } = await query

      if (error) throw error

      const formattedData = Array.isArray(checkData) ? checkData.map(item => ({
        ...item,
        store_name: item.stores?.name || 'N/A'
      })) : []

      // 🔍 Filtrado Frontend por Status (más rápido que backend dinámico por ahora)
      const filteredData = statusFilter === 'all'
        ? formattedData
        : formattedData.filter(item => (item.estatus_manager || 'pendiente') === statusFilter)

      setChecklists(filteredData)

      // Stats
      let statsQuery = supabase.from('assistant_checklists').select('checklist_type')

      if (user?.role === 'asistente' && Array.isArray(userScope) && userScope.length > 0) {
        const allowedStoreIds = stores
          .filter(s => userScope.includes(s.code) || userScope.includes(s.name))
          .map(s => s.id)

        if (allowedStoreIds.length > 0) {
          statsQuery = statsQuery.in('store_id', allowedStoreIds)
        }
        statsQuery = statsQuery.eq('user_id', user.id)
      }

      const { data: allChecks, error: errStats } = await statsQuery
      if (errStats) throw errStats
      const allChecksArray = Array.isArray(allChecks) ? allChecks : []

      setStats({
        total: allChecksArray.length,
        daily: allChecksArray.filter(c => c.checklist_type === 'daily').length,
        temperaturas: allChecksArray.filter(c => c.checklist_type === 'temperaturas').length,
        sobrante: allChecksArray.filter(c => c.checklist_type === 'sobrante').length,
        recorrido: allChecksArray.filter(c => c.checklist_type === 'recorrido').length,
        cierre: allChecksArray.filter(c => c.checklist_type === 'cierre').length,
        apertura: allChecksArray.filter(c => c.checklist_type === 'apertura').length
      })

      setLoading(false)
    } catch (err) {
      console.error('Error:', err)
      setLoading(false)
    }
  }

  const checklistTypes = [
    { value: 'daily', label: 'Daily Checklist', icon: '📝', color: 'border-blue-600' },
    { value: 'temperaturas', label: 'Temperaturas', icon: '🌡️', color: 'border-red-600' },
    { value: 'sobrante', label: 'Producto Sobrante', icon: '📦', color: 'border-yellow-600' },
    { value: 'recorrido', label: 'Recorrido', icon: '🚶', color: 'border-green-600' },
    { value: 'cierre', label: 'Cierre', icon: '🌙', color: 'border-purple-600' },
    { value: 'apertura', label: 'Apertura', icon: '🌅', color: 'border-orange-600' }
  ]

  const getTypeInfo = (type: string) => {
    return checklistTypes.find(t => t.value === type) || checklistTypes[0]
  }

  const getStatusBadge = (item: any) => {
    let status = item.estatus_manager || 'pendiente'

    // Override: Si Supervisor/Admin ya aprobó, mostrar ese estado
    let extraLabel = ''
    if (item.estatus_admin && item.estatus_admin !== 'pendiente') {
      status = item.estatus_admin
      extraLabel = ' (Sup)'
    }

    const colorClass = getStatusColor(status)
    const label = getStatusLabel(status) + extraLabel

    return (
      <span className={`px-2 py-1 rounded text-xs font-semibold border ${colorClass}`}>
        {label}
      </span>
    )
  }

  const canReview = () => {
    const role = user?.role?.toLowerCase()
    return role === 'manager' || role === 'admin'
  }

  const handleEdit = (item: any) => {
    if (!user) return

    const editCheck = canEditChecklist(item.created_at, user.role, item.user_id, user.id, item.estatus_manager)

    if (!editCheck.canEdit) {
      alert(editCheck.reason)
      return
    }

    router.push(`/checklists/editar/${item.checklist_type}/${item.id}`)
  }

  const canUserEdit = (item: any) => {
    if (!user) return false
    const editCheck = canEditChecklist(item.created_at, user.role, item.user_id, user.id, item.estatus_manager)
    return editCheck.canEdit
  }

  const handleRowClick = (item: any) => {
    // Only open modal if not clicking edit button
    setSelectedChecklist(item)
    setShowReviewModal(true)
  }

  if (loading) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="text-6xl mb-4">📋</div>
            <p className="text-gray-600">Cargando checklists...</p>
          </div>
        </div>
      </div>
    )
  }

  if (!user) return null

  return (
    <div className="flex bg-transparent h-screen overflow-hidden">
      <main className="flex-1 flex flex-col h-full w-full relative">
        {/* HEADER FIXED SECTION */}
        <div className="flex-none p-8 pb-0 z-10 bg-transparent">
          <div className="max-w-7xl mx-auto">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-gray-900">Checklists de Asistente</h1>
              <p className="text-gray-600 mt-2">Gestión de checklists diarios y controles</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-6">
              <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-indigo-600">
                <p className="text-xs font-medium text-gray-600">Total</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stats.total}</p>
              </div>
              <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-blue-600">
                <p className="text-xs font-medium text-gray-600">📝 Daily</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stats.daily}</p>
              </div>
              <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-red-600">
                <p className="text-xs font-medium text-gray-600">🌡️ Temps</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stats.temperaturas}</p>
              </div>
              <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-yellow-600">
                <p className="text-xs font-medium text-gray-600">📦 Sobrante</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stats.sobrante}</p>
              </div>
              <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-green-600">
                <p className="text-xs font-medium text-gray-600">🚶 Recorrido</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stats.recorrido}</p>
              </div>
              <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-purple-600">
                <p className="text-xs font-medium text-gray-600">🌙 Cierre</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stats.cierre}</p>
              </div>
              <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-orange-600">
                <p className="text-xs font-medium text-gray-600">🌅 Apertura</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stats.apertura}</p>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-4 mb-4">
              <div className="flex flex-wrap gap-4 items-center justify-between">
                <div className="flex flex-wrap gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Tipo de checklist</label>
                    <select
                      value={typeFilter}
                      onChange={(e) => setTypeFilter(e.target.value)}
                      className="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900 focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                      <option value="all">Todos los tipos</option>
                      {checklistTypes.map(type => (
                        <option key={type.value} value={type.value}>{type.icon} {type.label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Sucursal</label>
                    <select
                      value={storeFilter}
                      onChange={(e) => setStoreFilter(e.target.value)}
                      className="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900 focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                      <option value="all">Todas las sucursales</option>
                      {stores.map(store => (
                        <option key={store.id} value={store.id}>{store.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {/* FILTROS DE ESTADO */}
                  <div className="flex bg-white p-1 rounded-lg border border-gray-200 shadow-sm">
                    <button
                      onClick={() => setStatusFilter('all')}
                      className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${statusFilter === 'all' ? 'bg-gray-800 text-white shadow' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'}`}
                    >
                      Todos
                    </button>
                    <button
                      onClick={() => setStatusFilter('pendiente')}
                      className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${statusFilter === 'pendiente' ? 'bg-yellow-100 text-yellow-700 shadow border border-yellow-200' : 'text-gray-500 hover:text-yellow-700 hover:bg-yellow-50'}`}
                    >
                      Pendientes
                    </button>
                    <button
                      onClick={() => setStatusFilter('aprobado')}
                      className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${statusFilter === 'aprobado' ? 'bg-green-100 text-green-700 shadow border border-green-200' : 'text-gray-500 hover:text-green-700 hover:bg-green-50'}`}
                    >
                      Aprobados
                    </button>
                    <button
                      onClick={() => setStatusFilter('rechazado')}
                      className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${statusFilter === 'rechazado' ? 'bg-red-100 text-red-700 shadow border border-red-200' : 'text-gray-500 hover:text-red-700 hover:bg-red-50'}`}
                    >
                      Rechazados
                    </button>
                  </div>

                  <button
                    onClick={() => router.push('/checklists/crear')}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg text-sm font-semibold transition-all shadow-md flex items-center gap-2">
                    <span>+</span> Nuevo
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* SCROLLABLE TABLE SECTION - FIXED STICKY HEADER */}
        <div className="flex-1 flex flex-col min-h-0 px-8 pb-8">
          <div className="max-w-7xl mx-auto w-full h-full flex flex-col">
            <div className="bg-white rounded-xl shadow-md flex flex-col h-full overflow-hidden">
              {/* Tabla original aquí... */}
              <div className="overflow-auto flex-1">
                <table className="w-full relative">
                  {/* ... (Contenido de tabla sin cambios importantes, solo copiando la lógica) ... */}
                  {/* HEADER STICKY */}
                  <thead className="bg-gray-50 border-b border-gray-200 sticky top-0 z-10 shadow-sm">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Fecha</th>
                      <th className="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Tipo</th>
                      <th className="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Sucursal</th>
                      <th className="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Turno</th>
                      <th className="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Usuario</th>
                      <th className="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Score</th>
                      <th className="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Estado</th>
                      <th className="px-6 py-3 text-center text-xs font-bold text-gray-700 uppercase tracking-wider">Revisión</th>
                      <th className="px-6 py-3 text-center text-xs font-bold text-gray-700 uppercase tracking-wider">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {checklists.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="px-6 py-8 text-center text-gray-500">
                          No hay checklists registrados
                        </td>
                      </tr>
                    ) : (
                      checklists.map((item) => {
                        const typeInfo = getTypeInfo(item.checklist_type)
                        const isItemOverdue = isOverdue(item.created_at, item.estatus_admin || item.estatus_manager)
                        const canEdit = canUserEdit(item)

                        return (
                          <tr
                            key={item.id}
                            onClick={() => handleRowClick(item)}
                            className={`cursor-pointer transition-colors group ${isItemOverdue ? 'bg-red-50 hover:bg-red-100' : 'hover:bg-gray-50'}`}
                          >
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-bold text-gray-900">{formatDateLA(item.checklist_date || item.created_at)}</div>
                              <div className="text-xs text-gray-500">{item.start_time} - {item.end_time}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="text-sm font-medium text-gray-900 flex items-center gap-2">
                                <span className="text-lg">{typeInfo.icon}</span>
                                {typeInfo.label}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {item.store_name}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-center">
                              <span className={`px-2 py-1 rounded text-xs font-bold ${item.shift === 'AM' ? 'bg-yellow-100 text-yellow-700' : 'bg-blue-100 text-blue-700'}`}>
                                {item.shift}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {item.users?.full_name || 'N/A'}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <span className={`text-lg font-bold ${item.score >= 87 ? 'text-green-600' : item.score >= 70 ? 'text-orange-600' : 'text-red-600'}`}>{item.score}%</span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              {getStatusBadge(item)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <div className="flex flex-col gap-1 items-start justify-center text-xs pl-4">
                                <div className={`flex items-center gap-1 ${item.estatus_manager === 'aprobado' ? 'text-green-600 font-bold' : 'text-gray-400'}`}>
                                  Manager: {item.estatus_manager === 'aprobado' ? '✔️' : '✗'}
                                </div>
                                <div className={`flex items-center gap-1 ${item.estatus_supervisor === 'aprobado' ? 'text-green-600 font-bold' : 'text-gray-400'}`}>
                                  Supervisor: {item.estatus_supervisor === 'aprobado' ? '✔️' : '✗'}
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              {canEdit && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    handleEdit(item)
                                  }}
                                  className="text-blue-600 hover:text-blue-800 font-semibold text-sm bg-blue-50 px-3 py-1 rounded hover:bg-blue-100 transition-colors">
                                  ✏️ Editar
                                </button>
                              )}
                            </td>
                          </tr>
                        )
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </main >

      {showReviewModal && user && selectedChecklist && (
        <ChecklistReviewModal
          isOpen={showReviewModal}
          onClose={() => setShowReviewModal(false)}
          checklist={selectedChecklist}
          currentUser={{
            id: user.id,
            name: user.name || user.email,
            email: user.email,
            role: user.role
          }}
          onUpdate={() => {
            setShowReviewModal(false)
            fetchData()
          }}
        />
      )
      }
    </div >
  )
}

export default function ChecklistsPage() {
  return (
    <ProtectedRoute>
      <Suspense fallback={<div className="p-8 text-center">Cargando check...</div>}>
        <ChecklistsContent />
      </Suspense>
    </ProtectedRoute>
  )
}