'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import ProtectedRoute, { useAuth } from '@/components/ProtectedRoute'
import ChecklistReviewModal from '@/components/ChecklistReviewModal'
import { getSupabaseClient } from '@/lib/supabase'
import { getStatusColor, getStatusLabel, formatDateLA, canEditChecklist } from '@/lib/checklistPermissions'

function InspeccionesContent() {
  const router = useRouter()
  const { user } = useAuth()
  const [inspections, setInspections] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [storeFilter, setStoreFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [stores, setStores] = useState<any[]>([])

  // Modal State
  const [selectedInspection, setSelectedInspection] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const [errorMsg, setErrorMsg] = useState<string | null>(null)

  useEffect(() => {
    if (user) fetchData()
  }, [storeFilter, statusFilter, user])

  const fetchData = async () => {
    try {
      setLoading(true)
      setErrorMsg(null)

      const supabase = await getSupabaseClient()

      // Asegurar que el cliente reconozca el token antes de la primera petición RLS
      const token = localStorage.getItem('teg_token')
      if (token) {
        await supabase.auth.setSession({ access_token: token, refresh_token: '' })
      }

      // 1. Obtener tiendas y usuarios para mapeo manual
      const { data: storesList, error: storesListError } = await supabase.from('stores').select('*').order('name', { ascending: true })
      if (storesListError) console.error('❌ Error fetching stores list:', storesListError);

      const { data: usersList, error: usersListError } = await supabase.from('users').select('id, full_name')
      if (usersListError) console.error('❌ Error fetching users list:', usersListError);

      setStores(storesList || [])


      // 2. Obtener inspecciones básicas (Sin Joins complejos que puedan fallar por RLS o FKs)

      let query = supabase
        .from('supervisor_inspections')
        .select('*')
        .order('inspection_date', { ascending: false })
        .limit(100)

      if (storeFilter !== 'all') {
        query = query.eq('store_id', storeFilter)
      } else if (user?.role === 'manager' || user?.role === 'gerente') {
        // [FIX] Managers solo ven SU tienda
        if (user.store_id) query = query.eq('store_id', user.store_id)
      } else {

      }

      const { data: rawData, error: rawError } = await query

      if (rawError) {
        console.error('❌ Error de consulta de inspecciones:', rawError)
        throw rawError
      }



      // 3. Mapeo manual de datos
      const mappedData = (rawData || []).map(item => {
        const store = (storesList || []).find(s => s.id === item.store_id)
        const user = (usersList || []).find(u => u.id === item.inspector_id)

        return {
          ...item,
          store_name: store?.name || 'N/A',
          supervisor_name: user?.full_name || item.supervisor_name || 'Desconocido',
          checklist_type: 'supervisor',
          checklist_date: item.inspection_date,
          score: item.overall_score,
          photo_urls: item.photos || []
        }
      })

      // 4. Filtrar por estado si aplica
      const finalData = statusFilter !== 'all'
        ? mappedData.filter(item => (item.estatus_admin || 'pendiente') === statusFilter)
        : mappedData

      setInspections(finalData)
    } catch (error: any) {
      console.error('Error fetching data:', error)

      // Manejo específico de error de sesión (JWT Inválido)
      if (error?.code === 'PGRST301' || error?.message?.includes('JWT')) {
        setErrorMsg('Tu sesión ha expirado. Redirigiendo al login...')
        setTimeout(() => {
          localStorage.removeItem('teg_token')
          localStorage.removeItem('teg_user')
          window.location.href = '/login'
        }, 2000)
        return
      }

      setErrorMsg(error.message || 'Error al cargar inspecciones')
    } finally {
      setLoading(false)
    }
  }

  const handleRowClick = (inspection: any) => {
    setSelectedInspection(inspection)
    setIsModalOpen(true)
  }

  // --- RENDER ---
  if (loading) return <div className="flex h-screen items-center justify-center">Cargando inspecciones...</div>

  return (
    <div className="flex bg-transparent h-screen overflow-hidden">
      <div className="flex-1 flex flex-col h-full w-full relative">
        {/* HEADER FIXED SECTION */}
        <div className="flex-none p-8 pb-0 z-10 bg-transparent">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Inspecciones de Supervisor</h1>
              <p className="text-gray-600 mt-2">Auditoría y control de calidad operativa.</p>
            </div>
            <button
              onClick={() => router.push('/inspecciones/nueva')}
              className="bg-gray-900 hover:bg-black text-white px-6 py-3 rounded-xl font-bold shadow-lg transition-all flex items-center gap-2"
            >
              + Nueva Inspección
            </button>
          </div>

          {/* STATS CARDS (Copied design/logic) */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-indigo-600">
              <p className="text-xs font-medium text-gray-600">Total Inspecciones</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{inspections.length}</p>
            </div>
            <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-green-600">
              <p className="text-xs font-medium text-gray-600">Avg. Score</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {inspections.length > 0
                  ? Math.round(inspections.reduce((acc, curr) => acc + (curr.overall_score || 0), 0) / inspections.length) + '%'
                  : 'N/A'}
              </p>
            </div>
            <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-orange-600">
              <p className="text-xs font-medium text-gray-600">Pendientes</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {inspections.filter(i => (i.estatus_admin || 'pendiente') === 'pendiente').length}
              </p>
            </div>
            <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-blue-600">
              <p className="text-xs font-medium text-gray-600">Aprobados</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {inspections.filter(i => i.estatus_admin === 'aprobado').length}
              </p>
            </div>
          </div>

          {/* FILTROS Y CONTROLES */}
          <div className="flex bg-white p-1 rounded-lg border border-gray-200 shadow-sm w-fit mb-4">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${statusFilter === 'all' ? 'bg-gray-800 text-white shadow' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'}`}
            >
              Todos
            </button>
            <button
              onClick={() => setStatusFilter('pendiente')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${statusFilter === 'pendiente' ? 'bg-yellow-100 text-yellow-700 shadow border border-yellow-200' : 'text-gray-500 hover:text-yellow-700 hover:bg-yellow-50'}`}
            >
              Pendientes
            </button>
            <button
              onClick={() => setStatusFilter('aprobado')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${statusFilter === 'aprobado' ? 'bg-green-100 text-green-700 shadow border border-green-200' : 'text-gray-500 hover:text-green-700 hover:bg-green-50'}`}
            >
              Aprobados
            </button>
            <button
              onClick={() => setStatusFilter('rechazado')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${statusFilter === 'rechazado' ? 'bg-red-100 text-red-700 shadow border border-red-200' : 'text-gray-500 hover:text-red-700 hover:bg-red-50'}`}
            >
              Rechazados
            </button>
          </div>
        </div>

        {/* SCROLLABLE TABLE SECTION - CORREGIDO PARA STICKY HEADER */}
        <div className="flex-1 flex flex-col min-h-0 px-8 pb-8">
          <div className="bg-white rounded-xl shadow-md flex flex-col h-full overflow-hidden">
            <div className="overflow-auto flex-1">
              <table className="w-full text-left border-collapse relative">
                <thead className="bg-gray-50 border-b border-gray-200 sticky top-0 z-10 shadow-sm">
                  <tr className="text-xs uppercase text-gray-500">
                    <th className="p-4 font-bold bg-gray-50">Tienda</th>
                    <th className="p-4 font-bold bg-gray-50">Supervisor</th>
                    <th className="p-4 font-bold text-center bg-gray-50">Fecha</th>
                    <th className="p-4 font-bold text-center bg-gray-50">Turno</th>
                    <th className="p-4 font-bold text-center bg-gray-50">Calif. Global</th>
                    <th className="p-4 font-bold text-center bg-gray-50">Estado</th>
                    <th className="p-4 font-bold text-center bg-gray-50">Evidencia</th>
                    <th className="p-4 font-bold text-center bg-gray-50">Acciones</th>
                  </tr>
                </thead>
                <tbody className="text-sm divide-y divide-gray-100">
                  {errorMsg ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-red-500 font-bold">
                        {errorMsg}
                      </td>
                    </tr>
                  ) : inspections.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-gray-400 italic">No se encontraron inspecciones.</td>
                    </tr>
                  ) : (
                    inspections.map((item) => (
                      <tr
                        key={item.id}
                        onClick={() => handleRowClick(item)}
                        className="hover:bg-gray-50 cursor-pointer transition-colors group"
                      >
                        <td className="p-4 font-bold text-gray-900">{item.store_name}</td>
                        <td className="p-4 text-gray-600">{item.supervisor_name}</td>
                        <td className="p-4 text-center text-gray-500">{formatDateLA(item.inspection_date)}</td>
                        <td className="p-4 text-center">
                          <span className={`px-2 py-1 rounded text-xs font-bold ${item.shift === 'AM' ? 'bg-yellow-100 text-yellow-700' : 'bg-blue-100 text-blue-700'}`}>
                            {item.shift}
                          </span>
                        </td>
                        <td className="p-4 text-center">
                          <span className={`text-lg font-black ${item.overall_score >= 87 ? 'text-green-600' : item.overall_score >= 70 ? 'text-yellow-600' : 'text-red-600'}`}>
                            {item.overall_score}%
                          </span>
                        </td>
                        <td className="p-4 text-center">
                          <span className={`px-2 py-1 rounded-full text-xs font-bold border ${getStatusColor(item.estatus_admin || 'pendiente')}`}>
                            {getStatusLabel(item.estatus_admin || 'pendiente')}
                          </span>
                        </td>
                        <td className="p-4 text-center">
                          {(item.photos && item.photos.length > 0) ? (
                            <span className="inline-flex items-center justify-center p-2 bg-blue-50 text-blue-600 rounded-full" title={`${item.photos.length} fotos`}>
                              📷
                            </span>
                          ) : (
                            <span className="text-gray-300">-</span>
                          )}
                        </td>
                        <td className="p-4 text-center flex items-center justify-center gap-2">
                          {/* EDIT BUTTON */}
                          {canEditChecklist(item.inspection_date, user?.role || '', item.inspector_id, user?.id || '', item.estatus_admin).canEdit && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation()
                                router.push(`/inspecciones/editar/${item.id}`)
                              }}
                              className="text-blue-600 hover:text-blue-800 p-2 rounded-full hover:bg-blue-50 transition-colors"
                              title="Editar Inspección"
                            >
                              ✏️
                            </button>
                          )}

                          <button className="text-gray-400 hover:text-indigo-600 font-bold text-xs underline decoration-2 underline-offset-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            Ver Detalle
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Review Modal */}
      {
        selectedInspection && user && (
          <ChecklistReviewModal
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            checklist={selectedInspection}
            currentUser={{
              id: user.id || 0,
              name: user.name || user.email || 'Usuario',
              email: user.email || '',
              role: user.role || 'viewer'
            }}
            onUpdate={fetchData}
          />
        )
      }
    </div>
  )
}

export default function InspeccionesPage() {
  return (
    <ProtectedRoute>
      <InspeccionesContent />
    </ProtectedRoute>
  )
}