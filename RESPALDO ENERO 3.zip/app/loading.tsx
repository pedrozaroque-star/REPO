import SurpriseLoader from '@/components/SurpriseLoader'

export default function Loading() {
  return <SurpriseLoader />
}
