'use client'

import { useState, useEffect } from 'react'
import { formatDateLA, formatTimeLA, getSafeLADateISO } from '@/lib/checklistPermissions'
import { getQuestionText as getManagerQuestionText, MANAGER_QUESTIONS } from '@/lib/managerQuestions'
import { getAssistantQuestionText, getChecklistTitle } from '@/lib/assistantQuestions'
import { getSupervisorQuestionText, SUPERVISOR_QUESTIONS } from '@/lib/supervisorQuestions'
import { getSupabaseClient } from '@/lib/supabase'
import {
    ClipboardCheck,
    Clock,
    MapPin,
    User,
    X,
    Camera,
    MessageSquare,
    CheckCircle,
    AlertCircle,
    FileText,
    AlertTriangle,
    XCircle,
    PieChart,
    BarChart3
} from 'lucide-react'

interface ChecklistReviewModalProps {
    isOpen: boolean
    onClose: () => void
    checklist: any
    currentUser: { id: string | number, role: string, name: string, email: string }
    onUpdate: () => void
}

const STATUS_CONFIG: any = {
    'pendiente': { color: 'bg-yellow-100 text-yellow-800 border-yellow-200', icon: Clock, label: 'Pendiente' },
    'aprobado': { color: 'bg-green-100 text-green-800 border-green-200', icon: CheckCircle, label: 'Aprobado' },
    'rechazado': { color: 'bg-red-100 text-red-800 border-red-200', icon: AlertCircle, label: 'Rechazado' },
    'cerrado': { color: 'bg-purple-100 text-purple-800 border-purple-200', icon: ClipboardCheck, label: 'Cerrado' },
}

export default function ChecklistReviewModal({ isOpen, onClose, checklist, currentUser, onUpdate }: ChecklistReviewModalProps) {
    const [activeTab, setActiveTab] = useState<'details' | 'photos' | 'review'>('review') // Default to Review for efficiency
    const [reviewComment, setReviewComment] = useState('')
    const [saving, setSaving] = useState(false)
    const [loading, setLoading] = useState(false)

    // 🔄 USAR CLIENTE SINGLETON
    const supabase = getSupabaseClient()

    // Helper para transformar URLs de Google Drive en imágenes visibles
    const getEmbeddableImageUrl = (url: string) => {
        if (!url) return ''
        if (url.includes('lh3.googleusercontent.com')) return url

        try {
            let id = ''
            const idMatch = url.match(/[?&]id=([a-zA-Z0-9_-]+)/)
            if (idMatch) {
                id = idMatch[1]
            } else if (url.includes('/file/d/')) {
                const parts = url.split('/file/d/')
                if (parts.length > 1) {
                    id = parts[1].split('/')[0]
                }
            }

            if (id) {
                return `https://lh3.googleusercontent.com/d/${id}`
            }
        } catch (e) {
            console.error('Error parseando URL de Drive:', e)
        }
        return url
    }

    // Calculate duration
    const getDuration = () => {
        if (!checklist.start_time || !checklist.end_time) return 'N/A'

        try {
            // Assume format HH:MM or HH:MM:SS
            const startParts = checklist.start_time.split(':').map(Number)
            const endParts = checklist.end_time.split(':').map(Number)

            if (startParts.length < 2 || endParts.length < 2) return `${checklist.start_time} - ${checklist.end_time}`

            const startMinutes = startParts[0] * 60 + startParts[1]
            const endMinutes = endParts[0] * 60 + endParts[1]

            let diff = endMinutes - startMinutes
            if (diff < 0) diff += 24 * 60; // Handle midnight crossing

            const hours = Math.floor(diff / 60)
            const mins = diff % 60

            if (hours > 0) return `${hours}h ${mins}m`
            return `${mins} min`
        } catch (e) {
            return `${checklist.start_time} - ${checklist.end_time}`
        }
    }

    // Determine permissions
    const type = checklist.checklist_type || 'daily'
    const role = currentUser.role.toLowerCase()
    const status = (checklist.estatus_manager || 'pendiente').toLowerCase()
    const supervisorStatus = (checklist.estatus_supervisor || 'pendiente').toLowerCase()
    const isOwner = String(checklist.user_id) === String(currentUser.id)

    const canApprove =
        (type !== 'manager' && (
            (['manager', 'admin'].includes(role) && status !== 'aprobado') ||
            (role === 'supervisor' && status === 'aprobado' && (!checklist.estatus_admin || checklist.estatus_admin === 'pendiente'))
        )) ||
        (type === 'manager' && (role === 'supervisor' || role === 'admin') && supervisorStatus !== 'aprobado')

    const canReject =
        (type !== 'manager' && (
            (['manager', 'admin'].includes(role) && status !== 'aprobado' && status !== 'rechazado') ||
            (role === 'supervisor' && status === 'aprobado')
        )) ||
        (type === 'manager' && (role === 'supervisor' || role === 'admin') && supervisorStatus !== 'aprobado' && supervisorStatus !== 'rechazado')

    const canClose = role === 'asistente' && isOwner && status === 'rechazado'
    const canSupervisorFinalApprove = role === 'supervisor' && type !== 'manager' && (status === 'cerrado' || status === 'aprobado')

    const handleStatusChange = async (newStatus: string) => {
        if ((newStatus === 'rechazado' || newStatus === 'cerrado') && !reviewComment.trim()) {
            alert('Por favor agrega un comentario para justificar esta acción.')
            return
        }

        const tableName = type === 'supervisor' ? 'supervisor_inspections' :
            type === 'manager' ? 'manager_checklists' :
                'assistant_checklists'

        setSaving(true)
        try {
            const supabase = await getSupabaseClient()
            const updates: any = {}

            // 1. Determinar columnas de estatus según la tabla
            if (tableName === 'assistant_checklists') {
                updates.estatus_manager = newStatus
                // Solo si el rol coincide con lo que el esquema permite
                if (role === 'manager') {
                    updates.reviso_manager = currentUser.name || currentUser.email
                    updates.fecha_revision_manager = new Date().toISOString()
                    updates.comentarios_manager = reviewComment
                } else if (role === 'supervisor' || role === 'admin') {
                    // El Supervisor/Admin firma en las columnas _admin para el Visto Bueno Final
                    updates.estatus_admin = newStatus
                    updates.reviso_admin = currentUser.name || currentUser.email
                    updates.fecha_revision_admin = new Date().toISOString()
                    updates.comentarios_admin = reviewComment
                }
            } else if (tableName === 'supervisor_inspections') {
                // supervisor_inspections solo tiene columnas _admin
                updates.estatus_admin = newStatus
                updates.reviso_admin = currentUser.name || currentUser.email
                updates.fecha_revision_admin = new Date().toISOString()
                updates.comentarios_admin = reviewComment
            } else if (tableName === 'manager_checklists') {
                const suffix = role === 'admin' ? 'admin' : 'supervisor'
                updates[`estatus_${suffix}`] = newStatus
                updates[`reviso_${suffix}`] = currentUser.name || currentUser.email
                updates[`fecha_revision_${suffix}`] = new Date().toISOString()
                updates[`comentarios_${suffix}`] = reviewComment
            }

            // Assistant closing specific logic
            if (role === 'asistente' && tableName === 'assistant_checklists') {
                updates.estatus_manager = 'cerrado' // Force status
                updates.comments = checklist.comments ? `${checklist.comments}\n[${formatDateLA(new Date())}] Asistente: ${reviewComment}` : reviewComment
            }

            const { error } = await supabase
                .from(tableName)
                .update(updates)
                .eq('id', checklist.id)

            if (error) throw error

            // ⚠️ Notificación MANUAL para Rechazo de Manager Checklist (por Supervisor)
            if (newStatus === 'rechazado' && tableName === 'manager_checklists') {
                await supabase.from('notifications').insert({
                    user_id: checklist.user_id,
                    title: 'Checklist de Manager RECHAZADO',
                    message: `Tu checklist ha sido rechazado por ${currentUser.name || 'Supervisor'}.`,
                    link: '/checklists-manager',
                    resource_id: checklist.id,
                    type: 'alert'
                })
            }

            // 🔔 SISTEMA DE NOTIFICACIONES (Ahora manejado por Triggers de BD)
            // Ya no es necesario insertar manualmente aquí para evitar duplicados.


            alert(`Checklist actualizado a: ${newStatus.toUpperCase()}`)
            onUpdate()
            onClose()
        } catch (e: any) {
            console.error(e)
            alert('Error al actualizar: ' + e.message)
        } finally {
            setSaving(false)
        }
    }

    if (!isOpen || !checklist) return null

    const renderStatusBadge = (s: string) => {
        const config = STATUS_CONFIG[s.toLowerCase()] || STATUS_CONFIG['pendiente']
        const Icon = config.icon
        return (
            <span className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold border ${config.color}`}>
                <Icon size={14} />
                {config.label.toUpperCase()}
            </span>
        )
    }

    // Determine title based on type (manager, supervisor inspection, or assistant types)
    let checklistTitle = getChecklistTitle(type)
    if (type === 'manager') checklistTitle = 'Checklist de Manager'
    else if (checklist.overall_score !== undefined) checklistTitle = 'Inspección de Supervisor'

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9999] flex items-center justify-center p-4 animate-in fade-in duration-200">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden">

                {/* Header */}
                <div className="bg-white border-b p-6 flex justify-between items-start">
                    <div>
                        <div className="flex items-center gap-3 mb-2">
                            <span className="px-2 py-0.5 rounded text-xs font-bold bg-indigo-100 text-indigo-700 border border-indigo-200">
                                {checklistTitle.toUpperCase()}
                            </span>
                            <h2 className="text-2xl font-bold text-gray-900">{checklist.store_name}</h2>
                            {renderStatusBadge(checklist.estatus_manager || 'pendiente')}
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                            <span className="flex items-center gap-1"><User size={16} /> {checklist.users?.full_name || checklist.user_id}</span>
                            <span className="flex items-center gap-1"><Clock size={16} /> {formatDateLA(checklist.checklist_date)}</span>
                            <span className="flex items-center gap-1 bg-gray-100 px-2 py-0.5 rounded-md font-medium text-gray-700" title="Turno">
                                ☀️ {checklist.shift || 'N/A'}
                            </span>
                            <span className="flex items-center gap-1 bg-gray-100 px-2 py-0.5 rounded-md font-medium text-gray-700" title="Hora Inicio - Hora Fin">
                                🕒 {checklist.start_time} - {checklist.end_time}
                            </span>
                            <span className="flex items-center gap-1 bg-indigo-50 px-2 py-0.5 rounded-md font-medium text-indigo-700 border border-indigo-100" title="Duración Total">
                                ⏱️ Total: {getDuration()}
                            </span>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                        <X size={24} className="text-gray-500" />
                    </button>
                </div>

                {/* Tabs */}
                <div className="flex border-b bg-gray-50/50">
                    <button
                        onClick={() => setActiveTab('review')}
                        className={`flex-1 py-4 font-semibold text-sm flex items-center justify-center gap-2 border-b-2 transition-colors ${activeTab === 'review' ? 'border-indigo-600 text-indigo-600 bg-indigo-50/50' : 'border-transparent text-gray-600 hover:bg-gray-100'}`}
                    >
                        <ClipboardCheck size={18} /> Revisión y Flujo
                    </button>
                    <button
                        onClick={() => setActiveTab('details')}
                        className={`flex-1 py-4 font-semibold text-sm flex items-center justify-center gap-2 border-b-2 transition-colors ${activeTab === 'details' ? 'border-indigo-600 text-indigo-600 bg-indigo-50/50' : 'border-transparent text-gray-600 hover:bg-gray-100'}`}
                    >
                        <FileText size={18} /> Respuestas
                    </button>
                    <button
                        onClick={() => setActiveTab('photos')}
                        className={`flex-1 py-4 font-semibold text-sm flex items-center justify-center gap-2 border-b-2 transition-colors ${activeTab === 'photos' ? 'border-indigo-600 text-indigo-600 bg-indigo-50/50' : 'border-transparent text-gray-600 hover:bg-gray-100'}`}
                    >
                        <Camera size={18} /> Evidencias
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto bg-gray-50 p-6">

                    {/* TAB: REVIEW */}
                    {activeTab === 'review' && (
                        <div className="max-w-3xl mx-auto space-y-6">

                            {/* Score Card */}
                            <div className="bg-white p-6 rounded-xl border shadow-sm flex items-center justify-between">
                                <div>
                                    <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">Calificación del Checklist</p>
                                    <h3 className="text-3xl font-black text-gray-900 mt-1">{checklist.score}%</h3>
                                </div>
                                <div className={`h-16 w-16 rounded-full flex items-center justify-center text-2xl font-bold ${checklist.score >= 80 ? 'bg-green-100 text-green-600' : checklist.score >= 60 ? 'bg-orange-100 text-orange-600' : 'bg-red-100 text-red-600'}`}>
                                    {checklist.score >= 80 ? 'A' : checklist.score >= 60 ? 'B' : 'F'}
                                </div>
                            </div>

                            {/* Assistant Comments Section - Explicit Request */}
                            {checklist.comments && (
                                <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                                    <h3 className="font-bold text-blue-900 mb-2 flex items-center gap-2">
                                        <MessageSquare size={18} /> Observaciones del Asistente
                                    </h3>
                                    <p className="text-blue-800 text-sm italic">"{checklist.comments}"</p>
                                </div>
                            )}

                            {/* Timeline / History */}
                            <div className="bg-white p-6 rounded-xl border shadow-sm">
                                <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2"><Clock size={18} /> Historial de Revisiones</h3>
                                <div className="space-y-4">
                                    {/* Entry for Manager/Admin review if exists */}
                                    {/* Entry for Manager review */}
                                    {checklist.reviso_manager && (
                                        <div className="flex gap-3">
                                            <div className="mt-1 flex flex-col items-center">
                                                <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
                                                <div className="w-0.5 flex-1 bg-gray-200 my-1"></div>
                                            </div>
                                            <div className="pb-4">
                                                <p className="text-sm font-semibold text-gray-900">Revisión Gerencial</p>
                                                <p className="text-xs text-gray-500">{formatDateLA(checklist.fecha_revision_manager)} por {checklist.reviso_manager}</p>
                                                {checklist.comentarios_manager && (
                                                    <div className="mt-2 bg-gray-50 p-3 rounded-lg text-sm text-gray-700 italic border border-gray-100">
                                                        "{checklist.comentarios_manager}"
                                                    </div>
                                                )}
                                                <div className="mt-1">
                                                    {checklist.estatus_manager === 'aprobado' ? (
                                                        <span className="text-xs font-bold text-green-600">✅ APROBADO</span>
                                                    ) : checklist.estatus_manager === 'rechazado' ? (
                                                        <span className="text-xs font-bold text-red-600">❌ RECHAZADO</span>
                                                    ) : null}
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* Entry for Supervisor/Admin review */}
                                    {checklist.reviso_admin && (
                                        <div className="flex gap-3">
                                            <div className="mt-1 flex flex-col items-center">
                                                <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                                                <div className="w-0.5 flex-1 bg-gray-200 my-1"></div>
                                            </div>
                                            <div className="pb-4">
                                                <p className="text-sm font-semibold text-gray-900">Aprobación Final (Supervisor)</p>
                                                <p className="text-xs text-gray-500">{formatDateLA(checklist.fecha_revision_admin)} por {checklist.reviso_admin}</p>
                                                {checklist.comentarios_admin && (
                                                    <div className="mt-2 bg-purple-50 p-3 rounded-lg text-sm text-purple-900 italic border border-purple-100">
                                                        "{checklist.comentarios_admin}"
                                                    </div>
                                                )}
                                                <div className="mt-1">
                                                    {checklist.estatus_admin === 'aprobado' ? (
                                                        <span className="text-xs font-bold text-green-600">✅ APROBADO FINAL</span>
                                                    ) : checklist.estatus_admin === 'rechazado' ? (
                                                        <span className="text-xs font-bold text-red-600">❌ RECHAZADO FINAL</span>
                                                    ) : null}
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* Entry for User Comment/Close */}
                                    {checklist.comments && (
                                        <div className="flex gap-3">
                                            <div className="mt-1 flex flex-col items-center">
                                                <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                                            </div>
                                            <div>
                                                <p className="text-sm font-semibold text-gray-900">Comentarios del Usuario / Corrección</p>
                                                <div className="mt-1 bg-blue-50 p-3 rounded-lg text-sm text-blue-900 border border-blue-100">
                                                    {checklist.comments}
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Action Area */}
                            <div className="bg-white p-6 rounded-xl border-2 border-indigo-100 shadow-sm">
                                <h3 className="font-bold text-gray-800 mb-2 flex items-center gap-2">
                                    <MessageSquare size={18} className="text-indigo-600" /> Acciones de Revisión
                                </h3>

                                <div className="mb-4">
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Comentarios / Observaciones</label>
                                    <textarea
                                        value={reviewComment}
                                        onChange={(e) => setReviewComment(e.target.value)}
                                        placeholder="Escribe tus observaciones aquí..."
                                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none resize-none h-24 text-sm text-gray-900"
                                    />
                                </div>

                                <div className="flex gap-3 flex-wrap">
                                    {/* Buttons for Manager/Supervisor */}
                                    {(canApprove || canSupervisorFinalApprove) && (
                                        <button
                                            onClick={() => handleStatusChange('aprobado')}
                                            disabled={saving}
                                            className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all flex justify-center items-center gap-2"
                                        >
                                            <CheckCircle size={18} /> {canSupervisorFinalApprove ? 'Aprobar Cierre (Final)' : 'Aprobar'}
                                        </button>
                                    )}

                                    {canReject && (
                                        <button
                                            onClick={() => handleStatusChange('rechazado')}
                                            disabled={saving}
                                            className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all flex justify-center items-center gap-2"
                                        >
                                            <AlertCircle size={18} /> Rechazar
                                        </button>
                                    )}

                                    {/* Buttons for Assistant */}
                                    {canClose && (
                                        <button
                                            onClick={() => handleStatusChange('cerrado')}
                                            disabled={saving}
                                            className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2.5 rounded-lg font-bold shadow-md transition-all flex justify-center items-center gap-2"
                                        >
                                            <ClipboardCheck size={18} /> Marcar como Corregido (Cerrar)
                                        </button>
                                    )}

                                    {/* Read-only / No Action state */}
                                    {!canApprove && !canReject && !canClose && !canSupervisorFinalApprove && (
                                        <div className="w-full text-center p-2 bg-gray-50 rounded-lg text-sm text-gray-500 italic">
                                            No hay acciones disponibles para tu rol en el estado actual.
                                        </div>
                                    )}
                                </div>
                            </div>

                        </div>
                    )}

                    {/* TAB: DETAILS (Simple JSON dump for now, to ensure reliability) */}
                    {activeTab === 'details' && (
                        <div className="bg-white p-6 rounded-xl border shadow-sm">
                            <p className="text-gray-500 text-center italic mb-4">
                                {Object.keys(checklist.answers || {}).length} Respuestas Capturadas
                            </p>
                            <div className="space-y-4">
                                <div className="space-y-4">
                                    {type === 'manager' ? (
                                        <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
                                            {/* 🖤 PREMIUM DARK DASHBOARD */}
                                            {(() => {
                                                // Calculate Global Stats dynamically
                                                let totalQuestions = 0
                                                let totalPassed = 0
                                                let totalFailed = 0
                                                let totalNA = 0

                                                MANAGER_QUESTIONS.sections.forEach((s, sIdx) => {
                                                    s.questions.forEach((_, qIdx) => {
                                                        const keys2Try = [`s${sIdx}_${qIdx}`, `S${sIdx} ${qIdx}`, `S${sIdx}_${qIdx}`, `s${sIdx} ${qIdx}`]
                                                        let valStr = 'N/A'
                                                        for (const k of keys2Try) {
                                                            if (checklist.answers && checklist.answers[k] !== undefined) {
                                                                valStr = String(checklist.answers[k]).toUpperCase()
                                                                break
                                                            }
                                                        }
                                                        if (valStr === 'SI') totalPassed++
                                                        else if (valStr === 'NO') totalFailed++
                                                        else totalNA++
                                                        totalQuestions++
                                                    })
                                                })

                                                const validQuestions = totalPassed + totalFailed
                                                const globalScore = validQuestions > 0 ? Math.round((totalPassed / validQuestions) * 100) : 0
                                                const finalScore = isNaN(globalScore) ? 0 : globalScore

                                                return (
                                                    <div className="bg-slate-900 rounded-2xl p-6 shadow-2xl text-white relative overflow-hidden">
                                                        {/* Decorative Background Elements */}
                                                        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob"></div>
                                                        <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-2000"></div>

                                                        <div className="relative z-10 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                                                            <div className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-xl backdrop-blur-sm border border-white/10">
                                                                <div className={`text-5xl font-black mb-2 bg-gradient-to-r ${finalScore >= 80 ? 'from-green-400 to-emerald-500' : finalScore >= 60 ? 'from-orange-400 to-amber-500' : 'from-red-400 to-rose-500'} bg-clip-text text-transparent`}>
                                                                    {finalScore}%
                                                                </div>
                                                                <div className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em]">Score Global</div>
                                                            </div>

                                                            <div className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-xl backdrop-blur-sm border border-white/10">
                                                                <div className="text-4xl font-bold text-emerald-400 mb-2 flex items-center gap-2">
                                                                    <CheckCircle size={32} /> {totalPassed}
                                                                </div>
                                                                <div className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em]">Aprobados</div>
                                                            </div>

                                                            <div className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-xl backdrop-blur-sm border border-white/10">
                                                                <div className="text-4xl font-bold text-rose-400 mb-2 flex items-center gap-2">
                                                                    <AlertCircle size={32} /> {totalFailed}
                                                                </div>
                                                                <div className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em]">Fallos</div>
                                                            </div>

                                                            <div className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-xl backdrop-blur-sm border border-white/10">
                                                                <div className="text-4xl font-bold text-blue-300 mb-2 flex items-center gap-2">
                                                                    <PieChart size={32} /> {totalQuestions}
                                                                </div>
                                                                <div className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em]">Items</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                )
                                            })()}

                                            {/* SECTIONS GRID */}
                                            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                                                {MANAGER_QUESTIONS.sections.map((section, sIdx) => {
                                                    // Calculate questions in this section
                                                    const sectionItems = section.questions.map((qText, qIdx) => {
                                                        const keys2Try = [`s${sIdx}_${qIdx}`, `S${sIdx} ${qIdx}`, `S${sIdx}_${qIdx}`, `s${sIdx} ${qIdx}`]
                                                        let val = null
                                                        for (const k of keys2Try) {
                                                            if (checklist.answers && checklist.answers[k] !== undefined) {
                                                                val = checklist.answers[k]
                                                                break
                                                            }
                                                        }
                                                        return { text: qText, value: val }
                                                    })

                                                    const answeredCount = sectionItems.filter(i => i.value).length
                                                    const passedCount = sectionItems.filter(i => String(i.value).toUpperCase() === 'SI').length
                                                    const validCount = sectionItems.filter(i => {
                                                        const v = String(i.value).toUpperCase()
                                                        return v === 'SI' || v === 'NO'
                                                    }).length
                                                    const score = validCount > 0 ? Math.round((passedCount / validCount) * 100) : 0

                                                    return (
                                                        <div key={section.id} className="bg-white group border border-gray-100 hover:border-gray-300 shadow-sm rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300">
                                                            <div className="p-5 border-b bg-gray-50/30">
                                                                <div className="flex justify-between items-center mb-4">
                                                                    <h3 className="font-bold text-lg text-gray-900 flex items-center gap-2">
                                                                        <span className="w-1.5 h-6 rounded-full bg-slate-800"></span>
                                                                        {section.title}
                                                                    </h3>
                                                                    <div className={`px-4 py-1.5 rounded-full font-black text-sm tracking-tight ${score >= 87 ? 'bg-green-100 text-green-800' : score >= 70 ? 'bg-orange-100 text-orange-800' : 'bg-red-100 text-red-800'}`}>
                                                                        {score}% CUMPLIMIENTO
                                                                    </div>
                                                                </div>
                                                                {/* Progress Bar */}
                                                                <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                                                                    <div className={`h-2 rounded-full transition-all duration-1000 ease-out ${score >= 87 ? 'bg-green-500' : score >= 70 ? 'bg-orange-500' : 'bg-red-500'}`} style={{ width: `${score}%` }}></div>
                                                                </div>
                                                            </div>

                                                            <div className="divide-y divide-gray-50 max-h-[350px] overflow-y-auto custom-scrollbar bg-white">
                                                                {sectionItems.map((item, idx) => {
                                                                    const valStr = String(item.value || 'N/A').toUpperCase()
                                                                    const isPass = valStr === 'SI'
                                                                    const isFail = valStr === 'NO'

                                                                    return (
                                                                        <div key={idx} className={`px-5 py-3.5 flex items-center justify-between gap-4 transition-colors ${isFail ? 'bg-red-50/40' : 'hover:bg-gray-50'}`}>
                                                                            <div className="flex gap-3 items-center">
                                                                                <div className="flex-shrink-0">
                                                                                    {isPass ? <div className="p-1 bg-green-100 rounded-full text-green-600"><CheckCircle size={14} /></div> :
                                                                                        isFail ? <div className="p-1 bg-red-100 rounded-full text-red-600"><XCircle size={14} /></div> :
                                                                                            <div className="p-1 bg-gray-100 rounded-full text-gray-400"><AlertTriangle size={14} /></div>}
                                                                                </div>
                                                                                <span className={`text-sm leading-snug ${isFail ? 'font-semibold text-red-900' : 'text-gray-600'}`}>{item.text}</span>
                                                                            </div>
                                                                            <div className="flex-shrink-0">
                                                                                {isPass ? (
                                                                                    <span className="text-[10px] font-bold text-green-600 tracking-wider">OK</span>
                                                                                ) : isFail ? (
                                                                                    <span className="text-[10px] font-bold text-red-600 bg-red-50 px-2 py-1 rounded border border-red-100 tracking-wider">FALLO</span>
                                                                                ) : (
                                                                                    <span className="text-[10px] font-bold text-gray-300 tracking-wider">-</span>
                                                                                )}
                                                                            </div>
                                                                        </div>
                                                                    )
                                                                })}
                                                            </div>
                                                        </div>
                                                    )
                                                })}
                                            </div>
                                        </div>

                                    ) : checklist.overall_score !== undefined ? (
                                        // LOGIC FOR SUPERVISOR INSPECTIONS (Nested Structure)
                                        Object.entries(checklist.answers || {}).map(([areaKey, areaData]: [string, any]) => {
                                            const sectionInfo = (SUPERVISOR_QUESTIONS as any)[areaKey] || { label: areaKey, color: 'gray' }
                                            const items = areaData.items || {}
                                            return (
                                                <div key={areaKey} className="border rounded-lg overflow-hidden">
                                                    <div className={`px-4 py-2 flex justify-between font-bold uppercase text-xs bg-gray-100 text-gray-700`}>
                                                        <span>{sectionInfo.label}</span>
                                                        <span className="bg-white px-2 rounded shadow-sm">{areaData.score}%</span>
                                                    </div>
                                                    <div className="divide-y text-sm text-gray-700">
                                                        {Object.entries(items).map(([itemKey, itemVal]: [string, any]) => (
                                                            <div key={itemKey} className="px-4 py-2 flex justify-between items-center hover:bg-gray-50">
                                                                <span className="truncate pr-2 flex-1">{itemVal.label}</span>
                                                                <span className={`font-bold text-[10px] px-2 py-0.5 rounded ${itemVal.score === 100 ? 'bg-green-100 text-green-700' : itemVal.score === 60 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`}>
                                                                    {itemVal.score === 100 ? 'CUMPLE' : itemVal.score === 60 ? 'PARCIAL' : 'FALLA'}
                                                                </span>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            )
                                        })
                                    ) : (
                                        // LOGIC FOR ASSISTANT/MANAGER (Flat Structure)
                                        Object.entries(checklist.answers || {}).map(([key, val]: [string, any]) => {
                                            const valueStr = typeof val === 'object' ? (val.value || JSON.stringify(val)) : String(val)
                                            // skip metadata keys
                                            if (key.includes('_score')) return null

                                            // Resolved Question Text
                                            const questionText = type === 'manager'
                                                ? getManagerQuestionText(key)
                                                : getAssistantQuestionText(type, key)

                                            return (
                                                <div key={key} className="flex justify-between border-b pb-2 last:border-0 hover:bg-gray-50 p-2 rounded transition-colors">
                                                    <span className="font-medium text-gray-700 text-sm">{questionText}</span>
                                                    <span className={`px-2 py-0.5 rounded text-xs font-bold ${valueStr.toUpperCase() === 'SI' ? 'bg-green-100 text-green-700' : valueStr.toUpperCase() === 'NO' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'}`}>
                                                        {valueStr}
                                                    </span>
                                                </div>
                                            )
                                        })
                                    )}
                                </div>
                            </div>
                        </div>
                    )}

                    {/* TAB: PHOTOS */}
                    {activeTab === 'photos' && (
                        <div className="bg-white p-6 rounded-xl border shadow-sm">
                            {(!checklist.photo_urls || checklist.photo_urls.length === 0) ? (
                                <div className="text-center py-10 text-gray-400">
                                    <Camera size={48} className="mx-auto mb-2 opacity-50" />
                                    <p>No hay evidencias fotográficas.</p>
                                </div>
                            ) : (
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                    {checklist.photo_urls.map((url: string, i: number) => (
                                        <a key={i} href={url} target="_blank" rel="noopener noreferrer" className="block aspect-square rounded-lg overflow-hidden border hover:ring-2 ring-indigo-500 transition-all group relative">
                                            <img
                                                src={getEmbeddableImageUrl(url)}
                                                alt={`Evidencia ${i}`}
                                                referrerPolicy="no-referrer"
                                                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                                            />
                                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
                                        </a>
                                    ))}
                                </div>
                            )}
                        </div>
                    )}

                </div>
            </div>
        </div >
    )
}
