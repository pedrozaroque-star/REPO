'use client'

import { useEffect, useState } from 'react'
import Sidebar from '@/components/Sidebar'
import UserModal from '@/components/UserModal' 
import { supabase } from '@/lib/supabase'     

export default function UsuariosPage() {
  const [users, setUsers] = useState<any[]>([])
  const [stores, setStores] = useState<any[]>([]) 
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [roleFilter, setRoleFilter] = useState('all')
  
  // Estado Modal
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<any>(null) // Para saber a quién editamos

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      const { data: usersData } = await supabase.from('users').select('*').order('full_name')
      const { data: storesData } = await supabase.from('stores').select('id, name').order('name')

      setUsers(usersData || [])
      setStores(storesData || [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  // --- GUARDAR (CREAR O EDITAR) ---
  const handleSaveUser = async (formData: any, isEdit: boolean) => {
    try {
      if (isEdit) {
        // 1. EDITAR DATOS (Tabla Pública)
        const { error } = await supabase
          .from('users')
          .update({
            full_name: formData.full_name,
            role: formData.role,
            store_id: formData.store_id ? parseInt(formData.store_id) : null
          })
          .eq('id', formData.id) // Aquí usamos el ID numérico, esto está bien para la tabla pública

        if (error) throw error

        // 2. CAMBIAR PASSWORD (Si escribieron algo) - CORREGIDO
        if (formData.password) {
          // Usamos la nueva función que acepta EMAIL
          const { error: rpcError } = await supabase.rpc('admin_reset_password_by_email', {
            target_email: formData.email, // <--- CAMBIO CLAVE: Enviamos email, no ID
            new_password: formData.password
          })
          
          if (rpcError) throw rpcError
          alert('✅ Datos y contraseña actualizados')
        } else {
            alert('✅ Usuario actualizado')
        }

      } else {
        // CREAR NUEVO (Esto se queda igual, ya funcionaba con la corrección anterior)
        const { data, error } = await supabase.rpc('create_new_user', {
            email: formData.email,
            password: formData.password,
            full_name: formData.full_name,
            role: formData.role,
            store_id: formData.store_id ? parseInt(formData.store_id) : null
        })

        if (error) throw error
        alert('✅ Usuario creado! Ya puede iniciar sesión.')
      }

      fetchData()
      setIsModalOpen(false)
      setEditingUser(null)

    } catch (err: any) {
      console.error('Error:', err)
      alert('❌ Error: ' + err.message)
    }
  }

  // --- ABRIR MODAL PARA EDITAR ---
  const openEdit = (user: any) => {
    setEditingUser(user)
    setIsModalOpen(true)
  }

  const openNew = () => {
    setEditingUser(null)
    setIsModalOpen(true)
  }

  // --- FILTROS Y ESTILOS ---
  const roleColors: any = {
    admin: 'bg-red-100 text-red-800', supervisor: 'bg-purple-100 text-purple-800',
    manager: 'bg-blue-100 text-blue-800', user: 'bg-green-100 text-green-800', asistente: 'bg-green-100 text-green-800'
  }

  const filteredUsers = users.filter(user => {
    const term = searchTerm.toLowerCase()
    const matchesSearch = user.full_name?.toLowerCase().includes(term) || user.email?.toLowerCase().includes(term)
    const userRole = user.role === 'user' ? 'asistente' : user.role
    const filterRole = roleFilter === 'user' ? 'asistente' : roleFilter
    return matchesSearch && (roleFilter === 'all' || userRole === filterRole)
  })

  return (
    <div className="flex min-h-screen bg-gray-50 font-sans">
      <Sidebar />
      <main className="flex-1 p-8 md:ml-64">
        
        {/* HEADER */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
            <div>
              <h1 className="text-3xl font-black text-gray-900 tracking-tight">Equipo</h1>
              <p className="text-gray-500 font-medium">Administra el acceso al sistema</p>
            </div>
            <button 
              onClick={openNew}
              className="bg-gray-900 hover:bg-black text-white px-6 py-3 rounded-xl font-bold shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all flex items-center gap-2"
            >
              <span className="text-xl leading-none">+</span> Nuevo Usuario
            </button>
        </div>

        {/* FILTROS */}
        <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm mb-6 flex flex-col md:flex-row gap-4 sticky top-4 z-10">
            <input
              type="text"
              placeholder="🔍 Buscar por nombre o email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-gray-900 font-bold focus:ring-2 focus:ring-blue-500 outline-none"
            />
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-gray-900 font-bold focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="all">Todos los Roles</option>
              <option value="admin">👑 Admin</option>
              <option value="supervisor">👔 Supervisor</option>
              <option value="manager">📊 Manager</option>
              <option value="asistente">👤 Asistente</option>
            </select>
        </div>

        {/* GRID DE USUARIOS */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredUsers.map((user) => (
              <div key={user.id} className="bg-white rounded-2xl shadow-sm border border-gray-200 hover:shadow-md transition-all p-6 group relative">
                
                {/* Botón Editar Flotante */}
                <button 
                    onClick={() => openEdit(user)}
                    className="absolute top-4 right-4 text-gray-300 hover:text-blue-600 p-2 hover:bg-blue-50 rounded-lg transition-all"
                    title="Editar Usuario"
                >
                    ✏️
                </button>

                <div className="flex items-center gap-4 mb-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl font-bold text-white shadow-sm
                      ${user.role === 'admin' ? 'bg-red-500' : 
                        user.role === 'supervisor' ? 'bg-purple-500' :
                        user.role === 'manager' ? 'bg-blue-500' : 'bg-green-500'}`}
                    >
                      {user.full_name.substring(0,1).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900 text-lg leading-tight">{user.full_name}</h3>
                      <p className="text-xs text-gray-400 font-mono mt-0.5 truncate max-w-[160px]">{user.email}</p>
                    </div>
                </div>

                <div className="flex gap-2 mb-4">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wide ${roleColors[user.role] || roleColors.asistente}`}>
                        {user.role === 'user' ? 'Asistente' : user.role}
                    </span>
                    <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wide bg-gray-100 text-gray-500">
                        {stores.find(s => s.id === user.store_id)?.name || 'Sin Tienda'}
                    </span>
                </div>
              </div>
            ))}
        </div>

        <UserModal 
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSave={handleSaveUser}
          stores={stores}
          initialData={editingUser}
        />
      </main>
    </div>
  )
}