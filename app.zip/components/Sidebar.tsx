'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import NotificationBell from './NotificationBell'
import { useState } from 'react'
import { useAuth } from './ProtectedRoute'

export default function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { user } = useAuth()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const handleLogout = () => {
    localStorage.removeItem('teg_user')
    router.push('/')
  }

  const menuItems = [
    { name: 'Dashboard', path: '/dashboard', icon: '📊', roles: ['manager', 'supervisor', 'admin'] },
    { name: 'Tiendas', path: '/tiendas', icon: '🏪', roles: ['admin'] },
    { name: 'Usuarios', path: '/usuarios', icon: '👥', roles: ['admin'] },
    { name: 'Inspecciones', path: '/inspecciones', icon: '📋', roles: ['supervisor', 'admin'] },
    { name: 'Checklists Manager', path: '/checklists-manager', icon: '👔', roles: ['manager', 'supervisor', 'admin'] },
    { name: 'Checklists', path: '/checklists', icon: '✅', roles: ['asistente', 'manager', 'supervisor', 'admin'] },
    { name: 'Feedback Clientes', path: '/feedback', icon: '💬', roles: ['asistente', 'manager', 'supervisor', 'admin'] },
    { name: 'Reportes', path: '/reportes', icon: '📈', roles: ['manager', 'supervisor', 'admin'] },
    { name: 'Estadísticas', path: '/estadisticas', icon: '📉', roles: ['manager', 'supervisor', 'admin'] }
  ]

  const filteredMenuItems = menuItems.filter((item) => {
    if (!item.roles || item.roles.length === 0) return true
    if (!user?.role) return false
    return item.roles.includes(user.role.toLowerCase())
  })

  return (
    <>
      {/* Sidebar para Desktop */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex flex-col flex-grow bg-gradient-to-b from-indigo-700 to-indigo-900 pt-5 pb-4 overflow-y-auto">
          {/* Logo */}
          <div className="flex items-center flex-shrink-0 px-4 mb-8">
            <h1 className="text-2xl font-bold text-white">🌮 Tacos Gavilan</h1>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-2 space-y-1">
            {filteredMenuItems.map((item) => {
              const isActive = pathname === item.path
              return (
                <Link
                  key={item.name}
                  href={item.path}
                  className={`
                    group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all
                    ${isActive 
                      ? 'bg-indigo-800 text-white shadow-lg' 
                      : 'text-indigo-100 hover:bg-indigo-600 hover:text-white'
                    }
                  `}
                >
                  <span className="mr-3 text-xl">{item.icon}</span>
                  {item.name}
                </Link>
              )
            })}
          </nav>

          {/* User Info & Logout */}
          <div className="flex-shrink-0 flex border-t border-indigo-800 p-4">
            <div className="flex-shrink-0 w-full">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold">
                      {user?.name?.[0] || user?.email?.[0] || '?'}
                    </div>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-white">
                      {user?.name || user?.email}
                    </p>
                    <p className="text-xs text-indigo-300">
                      {user?.role || 'Usuario'}
                    </p>
                  </div>
                </div>
                <NotificationBell />
              </div>
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-500 transition-all"
              >
                🚪 Cerrar Sesión
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu Button */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-40 bg-indigo-700 px-4 py-3 flex items-center justify-between">
        <h1 className="text-xl font-bold text-white">🌮 Tacos Gavilan</h1>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="text-white p-2"
        >
          {mobileMenuOpen ? '✕' : '☰'}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-30 bg-black bg-opacity-50" onClick={() => setMobileMenuOpen(false)}>
          <div className="fixed inset-y-0 left-0 w-64 bg-gradient-to-b from-indigo-700 to-indigo-900 overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="pt-16 pb-4">
              <nav className="px-2 space-y-1">
                {filteredMenuItems.map((item) => {
                  const isActive = pathname === item.path
                  return (
                    <Link
                      key={item.name}
                      href={item.path}
                      onClick={() => setMobileMenuOpen(false)}
                      className={`
                        group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all
                        ${isActive 
                          ? 'bg-indigo-800 text-white shadow-lg' 
                          : 'text-indigo-100 hover:bg-indigo-600 hover:text-white'
                        }
                      `}
                    >
                      <span className="mr-3 text-xl">{item.icon}</span>
                      {item.name}
                    </Link>
                  )
                })}
              </nav>

              <div className="mt-6 px-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="h-10 w-10 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold">
                        {user?.name?.[0] || user?.email?.[0] || '?'}
                      </div>
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-white">
                        {user?.name || user?.email}
                      </p>
                      <p className="text-xs text-indigo-300">
                        {user?.role || 'Usuario'}
                      </p>
                    </div>
                  </div>
                  <NotificationBell />
                </div>
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-500 transition-all"
                >
                  🚪 Cerrar Sesión
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}