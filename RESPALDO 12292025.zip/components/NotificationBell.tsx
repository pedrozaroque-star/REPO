'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { config } from '@/lib/config'

interface Notification {
  id: number
  title: string
  message: string
  link: string
  created_at: string
  read: boolean
  type: 'alert' | 'info' | 'success' | 'warning'
}

export default function NotificationBell() {
  const router = useRouter()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [isOpen, setIsOpen] = useState(false)
  const [showAnimation, setShowAnimation] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const hasShownAnimation = useRef(false)

  // 🔊 Función para reproducir sonido de campana
  const playBellSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      
      // Crear tres tonos para simular una campana real
      const frequencies = [800, 1000, 1200]
      const duration = 0.5
      
      frequencies.forEach((freq, index) => {
        const oscillator = audioContext.createOscillator()
        const gainNode = audioContext.createGain()
        
        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)
        
        oscillator.frequency.value = freq
        oscillator.type = 'sine'
        
        // Envolvente ADSR para sonido más natural
        const now = audioContext.currentTime
        gainNode.gain.setValueAtTime(0, now)
        gainNode.gain.linearRampToValueAtTime(0.3 / (index + 1), now + 0.01)
        gainNode.gain.exponentialRampToValueAtTime(0.01, now + duration)
        
        oscillator.start(now)
        oscillator.stop(now + duration)
      })

      // Segundo "ding" más suave
      setTimeout(() => {
        const oscillator2 = audioContext.createOscillator()
        const gainNode2 = audioContext.createGain()
        
        oscillator2.connect(gainNode2)
        gainNode2.connect(audioContext.destination)
        
        oscillator2.frequency.value = 1000
        oscillator2.type = 'sine'
        
        const now = audioContext.currentTime
        gainNode2.gain.setValueAtTime(0, now)
        gainNode2.gain.linearRampToValueAtTime(0.2, now + 0.01)
        gainNode2.gain.exponentialRampToValueAtTime(0.01, now + 0.3)
        
        oscillator2.start(now)
        oscillator2.stop(now + 0.3)
      }, 200)

    } catch (error) {
      console.error('Error al reproducir sonido:', error)
    }
  }

  useEffect(() => {
    fetchNotifications()
    const interval = setInterval(fetchNotifications, 30000)
    return () => clearInterval(interval)
  }, [])

  const fetchNotifications = async () => {
    try {
      const userStr = localStorage.getItem('teg_user')
      if (!userStr) return

      const user = JSON.parse(userStr)
      
      const url = config.supabase.url
      const key = config.supabase.anonKey
      
      if (!url || !key) {
        console.error('⚠️ Configuración de Supabase no disponible')
        return
      }

      const res = await fetch(
        `${url}/rest/v1/notifications?user_id=eq.${user.id}&order=created_at.desc&limit=20`,
        {
          headers: {
            'apikey': key,
            'Authorization': `Bearer ${key}`
          }
        }
      )

      if (res.ok) {
        const data = await res.json()
        const unread = data.filter((n: Notification) => !n.read).length
        
        setNotifications(data)
        setUnreadCount(unread)

        // 🎬 MOSTRAR ANIMACIÓN + SONIDO
        if (unread > 0 && !hasShownAnimation.current) {
          hasShownAnimation.current = true
          setShowAnimation(true)
          
          // 🔊 Reproducir sonido de campana
          playBellSound()
          
          // Ocultar animación después de 3 segundos
          setTimeout(() => {
            setShowAnimation(false)
          }, 3000)
        }
      }
    } catch (error) {
      console.error('Error al cargar notificaciones:', error)
    }
  }

  const markAsRead = async () => {
    if (unreadCount === 0) return

    try {
      const unreadIds = notifications.filter(n => !n.read).map(n => n.id)

      if (unreadIds.length > 0) {
        await fetch(
          `${config.supabase.url}/rest/v1/notifications?id=in.(${unreadIds.join(',')})`,
          {
            method: 'PATCH',
            headers: {
              'apikey': config.supabase.anonKey,
              'Authorization': `Bearer ${config.supabase.anonKey}`,
              'Content-Type': 'application/json',
              'Prefer': 'return=minimal'
            },
            body: JSON.stringify({ read: true })
          }
        )

        setNotifications(prev => prev.map(n => ({ ...n, read: true })))
        setUnreadCount(0)
      }
    } catch (error) {
      console.error('Error:', error)
    }
  }

  const toggleDropdown = () => {
    if (!isOpen) {
      setIsOpen(true)
      markAsRead()
    } else {
      setIsOpen(false)
    }
  }

  const handleNotificationClick = (notification: Notification) => {
    if (notification.link) {
      router.push(notification.link)
      setIsOpen(false)
    }
  }

  const getIcon = (type: string) => {
    switch (type) {
      case 'alert': return '🚨';
      case 'success': return '✅';
      case 'warning': return '⚠️';
      default: return 'ℹ️';
    }
  }

  return (
    <>
      {/* 🎬 ANIMACIÓN ESPECTACULAR DE ENTRADA */}
      {showAnimation && (
        <div className="fixed inset-0 z-[9999] pointer-events-none flex items-center justify-center">
          <div className="bell-entrance-animation">
            <div className="text-[20rem] animate-shake">
              🔔
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="bg-red-600 text-white rounded-full w-32 h-32 flex items-center justify-center text-6xl font-bold animate-pulse border-8 border-white shadow-2xl">
                {unreadCount}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CAMPANA NORMAL EN SIDEBAR */}
      <div className="relative" ref={dropdownRef}>
        <button
          onClick={toggleDropdown}
          className="relative p-2 text-gray-400 hover:text-white transition-colors rounded-full hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-red-500"
        >
          <span className="text-2xl">🔔</span>
          
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-red-100 transform translate-x-1/4 -translate-y-1/4 bg-red-600 rounded-full border-2 border-gray-900 animate-pulse">
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </button>

        {isOpen && (
          <>
            <div 
              className="fixed inset-0 z-40 bg-black/20 backdrop-blur-sm md:bg-transparent md:backdrop-blur-none" 
              onClick={() => setIsOpen(false)}
            />

            <div className="fixed z-50 bottom-0 left-0 right-0 mx-4 mb-4 max-h-[70vh] flex flex-col md:left-64 md:bottom-20 md:w-96 md:mx-0 bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden ring-1 ring-black ring-opacity-5 animate-in slide-in-from-bottom-2 fade-in duration-200">
              
              <div className="px-4 py-3 bg-gray-50 border-b border-gray-100 flex justify-between items-center">
                <h3 className="text-sm font-semibold text-gray-700">Notificaciones</h3>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="text-gray-400 hover:text-gray-600 md:hidden"
                >
                  ✕
                </button>
              </div>

              <div className="overflow-y-auto overscroll-contain max-h-[60vh] md:max-h-96">
                {notifications.length === 0 ? (
                  <div className="px-4 py-8 text-center text-gray-500">
                    <p className="text-3xl mb-2">🔕</p>
                    <p className="text-sm">No tienes notificaciones nuevas</p>
                  </div>
                ) : (
                  <div className="divide-y divide-gray-100">
                    {notifications.map((notification) => (
                      <div 
                        key={notification.id}
                        onClick={() => handleNotificationClick(notification)}
                        className={`px-4 py-3 hover:bg-gray-50 transition-colors cursor-pointer ${!notification.read ? 'bg-blue-50/50' : ''}`}
                      >
                        <div className="flex items-start gap-3">
                          <span className="text-xl mt-1 select-none">
                            {getIcon(notification.type)}
                          </span>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">
                              {notification.title}
                            </p>
                            <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">
                              {notification.message}
                            </p>
                            <p className="text-[10px] text-gray-400 mt-1">
                              {new Date(notification.created_at).toLocaleString('es-MX', {
                                day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'
                              })}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              <div className="bg-gray-50 px-4 py-2 border-t border-gray-100 text-center">
                <button 
                  onClick={() => setIsOpen(false)}
                  className="text-xs text-blue-600 font-medium hover:text-blue-800"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      <style jsx>{`
        .bell-entrance-animation {
          animation: bellEntrance 3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
          position: relative;
        }

        @keyframes bellEntrance {
          0% {
            transform: scale(0) rotate(-180deg);
            opacity: 0;
          }
          40% {
            transform: scale(1.2) rotate(10deg);
            opacity: 1;
          }
          60% {
            transform: scale(1) rotate(-5deg);
          }
          80% {
            transform: scale(1) rotate(0deg);
          }
          100% {
            transform: scale(0.1) translateX(-600px) translateY(300px);
            opacity: 0;
          }
        }

        @keyframes shake {
          0%, 100% { transform: rotate(0deg); }
          10%, 30%, 50%, 70%, 90% { transform: rotate(-10deg); }
          20%, 40%, 60%, 80% { transform: rotate(10deg); }
        }

        .animate-shake {
          animation: shake 0.5s infinite;
        }

        @media (max-width: 768px) {
          @keyframes bellEntrance {
            0% {
              transform: scale(0) rotate(-180deg);
              opacity: 0;
            }
            40% {
              transform: scale(1.2) rotate(10deg);
              opacity: 1;
            }
            60% {
              transform: scale(1) rotate(-5deg);
            }
            80% {
              transform: scale(1) rotate(0deg);
            }
            100% {
              transform: scale(0.1) translateX(-150px) translateY(300px);
              opacity: 0;
            }
          }
        }
      `}</style>
    </>
  )
}